<?php
if (!defined('ABSPATH')) { exit; }
/** Immutable observations plus a deterministic current view. */
class Vorkei_Ico_Atlas_Profile {
 const GROUPS=['registration','activities','people','ownership','financials','metrics','tax','accounts','debts','proceedings','public_sector','subsidies','licenses','intellectual_property','contacts','history'];
 public static function blank(string $ico): array {
  $p=['schema_version'=>'2.1','ico'=>$ico,'fields'=>[],'observations'=>[],'groups'=>[],'checks'=>[],'conflicts'=>[]];
  foreach(self::GROUPS as $g) {$p['groups'][$g]=['availability_status'=>'not_checked','records'=>[]];} return $p;
 }
 /** JSON numbers drop leading zeroes. Only an integer is padded back to 8 digits; a shorter string is not an IČO. */
 public static function same_ico($value,string $expected): bool {
  if(!preg_match('/^[0-9]{8}$/D',$expected)) {return false;}
  if(is_int($value)) {
   if($value<0||$value>99999999) {return false;}
   $value=str_pad((string)$value,8,'0',STR_PAD_LEFT);
  } elseif(is_string($value)) {
   $value=preg_replace('/\s+/u','',$value);
   if(!is_string($value)) {return false;}
  } else {return false;}
  return $value===$expected;
 }
 public static function valid(array $p,string $ico): bool {
  if(($p['ico']??null)!==$ico||!is_array($p['fields']??null)||!is_array($p['groups']??null)) {return false;}
  foreach($p['fields'] as $e) {if(!is_array($e)||!array_key_exists('value',$e)||!is_string($e['source_url']??null)) {return false;}}
  foreach($p['groups'] as $g) {if(!is_array($g)||!is_array($g['records']??null)) {return false;}}
  return true;
 }
 public static function evidence($value,string $source,string $url,string $id='',?string $asof=null,string $status='observed'): array {
  return ['value'=>$value,'source'=>$source,'source_url'=>esc_url_raw($url,['https']),'source_record_id'=>$id,'retrieved_at'=>gmdate('c'),'source_updated_at'=>$asof,'valid_as_of'=>null,'valid_from'=>null,'valid_to'=>null,'match_method'=>'exact_ico','kind'=>'reported','availability_status'=>$status];
 }
 private static function migrate(array $e): array {
  if(!array_key_exists('source_updated_at',$e) && ($e['source']??'')==='RÚZ') {$e['source_updated_at']=$e['valid_as_of']??null;$e['valid_as_of']=null;}
  if(is_array($e['value']??null) && $e['value']===[]) {$e['availability_status']='not_checked';}
  $e += ['kind'=>'reported','match_method'=>'exact_ico','retrieved_at'=>null,'source_updated_at'=>null,'valid_as_of'=>null,'valid_from'=>null,'valid_to'=>null,'availability_status'=>'observed'];
  return $e;
 }
 private static function fingerprint(array $e): string {
  $copy=$e; unset($copy['retrieved_at'],$copy['availability_status'],$copy['selection_reason']);
  return self::canonical_hash($copy);
 }
 /** Object key order is transport formatting; list order and scalar types are data. */
 public static function canonical_hash($value): string {return hash('sha256',wp_json_encode(self::canonical($value),JSON_PRESERVE_ZERO_FRACTION));}
 private static function canonical($value) {
  if(is_array($value)) {if(!array_is_list($value)) {ksort($value,SORT_STRING);}foreach($value as $key=>$item) {$value[$key]=self::canonical($item);}}
  return $value;
 }
 /** Collapse equal content while retaining distinct retrieval evidence and legacy IDs. */
 public static function deduplicate_records(array $records): array {
  $unique=[];
  foreach($records as $record) {
   $content=$record['value']??null;
   if(($record['kind']??'')==='calculated'||!array_key_exists('value',$record)) {$content=$record;unset($content['retrieved_at'],$content['evidence_history'],$content['selection_reason']);}
   $key=($record['source']??'').':'.($record['source_record_id']??'').':'.self::canonical_hash([$content,$record['valid_from']??null,$record['valid_to']??null,$record['valid_as_of']??null,$record['match_method']??'exact_ico',$record['kind']??'reported']);
   if(!isset($unique[$key])) {$unique[$key]=$record;continue;}
   $previous=$unique[$key];$proofs=[];
   foreach([$previous,$record] as $entry) {
    $proof=$entry;unset($proof['value'],$proof['decoded_tables'],$proof['normalized_facts'],$proof['comparative_facts'],$proof['financial_issues'],$proof['report_identity'],$proof['evidence_history'],$proof['superseded'],$proof['superseded_by'],$proof['normalizer'],$proof['report_version_aliases']);
    foreach(array_merge($entry['evidence_history']??[],[$proof]) as $item) {$proofs[self::canonical_hash($item)]=$item;}
   }
   $at=static fn($entry)=>is_string($entry['retrieved_at']??null)?(strtotime($entry['retrieved_at'])?:0):0;
   $chosen=$at($record)>=$at($previous)?$record:$previous;
   $aliases=array_merge($previous['report_version_aliases']??[],$record['report_version_aliases']??[]);
   $currentVersion=self::canonical_hash($record['value']??null);
   foreach([$previous,$record] as $entry) {if(is_string($entry['report_identity']['report_version']??null)&&$entry['report_identity']['report_version']!==$currentVersion) {$aliases[]=$entry['report_identity']['report_version'];}}
   if($aliases) {$chosen['report_version_aliases']=array_values(array_unique($aliases));}
   if(count($proofs)>1) {$chosen['evidence_history']=array_values($proofs);}
   $unique[$key]=$chosen;
  }
  return array_values($unique);
 }
 public static function field(array &$p,string $key,$value,string $source,string $url,string $id='',?string $asof=null): void {
  if($value===null||$value==='') {return;}
  self::observe($p,$key,self::evidence($value,$source,$url,$id,$asof));
 }
 public static function observe(array &$p,string $key,array $e): void {
  $e=self::migrate($e);
  if(in_array($key,['active','status'],true)&&self::source_key($e)==='registry') {$e['availability_status']='unconfirmed';$e['kind']='candidate';$e['match_method']='upstream_declared';}
  $observations=$p['observations'][$key]??[];
  if(isset($p['fields'][$key])) {$observations[] = self::migrate($p['fields'][$key]);}
  $observations[]=$e;$unique=[];
  foreach($observations as $v) {if(is_array($v)&&array_key_exists('value',$v)) {$unique[self::fingerprint($v)]=$v;}}
  $p['observations'][$key]=array_values($unique);
  self::select($p,$key);
 }
 private static function source_key(array $e): string {
  $host=strtolower((string)parse_url($e['source_url']??'',PHP_URL_HOST));
  if(in_array($host,['orsr.sk','www.orsr.sk','sluzby.orsr.sk'],true)) {return 'orsr';}
  if($host==='api.statistics.sk'||$host==='rpo.statistics.sk') {return 'rpo';}
  if(str_ends_with($host,'.financnasprava.sk')||$host==='financnasprava.sk') {return 'fs';}
  if($host==='www.registeruz.sk'||$host==='registeruz.sk') {return 'ruz';}
  return 'registry';
 }
 private static function select(array &$p,string $key): void {
  $rows=$p['observations'][$key]??[];$best=null;$score=-PHP_INT_MAX;
  foreach($rows as $e) {
   $src=self::source_key($e);$checkKey=$src==='fs'?(str_starts_with($key,'vat_')?'fs_vat':($key==='dic'?'fs_dic':'fs')):$src;$status=$p['checks'][$checkKey]['availability_status']??$p['checks'][$src]['availability_status']??'observed';
   $usable=($e['availability_status']??'observed')==='observed';
   $ended=!empty($e['valid_to'])&&$e['valid_to']<gmdate('Y-m-d');
   $stale=in_array($status,['source_unavailable','invalid_response','requires_access','not_found','stale','conflict','partial','unsupported','not_configured'],true);
   $rank=['orsr'=>100,'rpo'=>90,'ruz'=>50,'registry'=>20,'fs'=>70][$src];
   if(in_array($key,['dic','vat_id','vat_registration_type','vat_registered_on','vat_payer_since','vat_payer_from','vat_registered','vat_payer','vat_registry_match','vat_registration_changed_on'],true)&&$src==='fs') {$rank=120;}
   $current=($usable?1000:0)+($ended?-2000:0)+($stale?-500:0)+$rank;
   $date=$e['valid_from']??$e['source_updated_at']??'';
   $bestdate=$best['valid_from']??$best['source_updated_at']??'';
   if($best===null||$current>$score||($current===$score&&strcmp($date,$bestdate)>0)||($current===$score&&$date===$bestdate&&strcmp($e['retrieved_at']??'',$best['retrieved_at']??'')>=0)) {
    $best=$e;$score=$current;if($stale&&$usable) {$best['availability_status']='stale';}
   }
  }
  if($best!==null) {$best['selection_reason']='Aktuálna hodnota podľa zdroja, účinnosti a dostupnosti';$p['fields'][$key]=$best;}
 }
 private static function comparable(string $key,$value): string {
  if(!is_string($value)) {return wp_json_encode($value);}
  if($key==='name') {return self::lower(preg_replace('/[\s.,]+/u','',$value));}
  if($key==='address') {
   $text=self::lower($value);$text=str_replace(['slovenská republika','slovensko'],'',$text);
   $text=preg_replace('/(\d{3})\s+(\d{2})(?!\d)/u','$1$2',$text);
   $tokens=preg_split('/[\s,]+/u',trim($text),-1,PREG_SPLIT_NO_EMPTY);sort($tokens);return implode(' ',$tokens);
  }
  return $value;
 }
 /** Without mbstring keep non-ASCII differences, rather than invent equivalence. */
 private static function lower(string $text): string {return function_exists('mb_strtolower')?mb_strtolower($text,'UTF-8'):strtolower($text);}
 public static function merge(array $old,array $new): array {
  $p=array_replace(self::blank((string)($new['ico']??$old['ico']??'')),$old);
  $p['schema_version']='2.1';$p['checks']=array_replace($old['checks']??[],$new['checks']??[]);
  // A transport failure is a failed attempt, not a new finding. Keep the last
  // completed check so an outage cannot turn a known registration into false.
  foreach($new['checks']??[] as $name=>$incoming) {
   if(!is_array($incoming)) {continue;}
   $previous=$old['checks'][$name]??null;
   if(!is_array($previous)) {continue;}
   $in=(string)($incoming['availability_status']??'');
   $prev=(string)($previous['availability_status']??'');
   if(in_array($in,['source_unavailable','invalid_response'],true)&&in_array($prev,['observed','not_found','conflict','partial'],true)) {
    $kept=$previous;
    $kept['last_attempt_status']=$in;
    $kept['last_attempt_at']=$incoming['checked_at']??gmdate('c');
    if(array_key_exists('error',$incoming)) {$kept['last_attempt_error']=$incoming['error'];}
    $p['checks'][$name]=$kept;
   }
  }
  foreach([$old,$new] as $part) {
   foreach($part['observations']??[] as $k=>$values) {foreach($values as $e) {self::observe($p,$k,$e);}}
   foreach($part['fields']??[] as $k=>$e) {self::observe($p,$k,$e);}
  }
  foreach($new['groups']??[] as $k=>$g) {
   $previous=$p['groups'][$k]??['records'=>[]];
   $records=self::deduplicate_records(array_map([self::class,'migrate'],array_merge($previous['records']??[],$g['records']??[])));
   if(empty($g['records'])&&($g['availability_status']??'not_checked')==='not_checked'&&!empty($previous['records'])) {unset($g['availability_status']);}
   $p['groups'][$k]=array_replace($previous,$g);$p['groups'][$k]['records']=$records;
   if(!empty($previous['records'])&&empty($g['records'])&&in_array($g['availability_status']??'',['not_found','source_unavailable','requires_access'],true)) {
    $p['groups'][$k]['last_attempt_status']=$g['availability_status'];$p['groups'][$k]['availability_status']='stale';
   }
  }
  $conflicts=array_merge($old['conflicts']??[],$new['conflicts']??[]);
  foreach($p['observations'] as $key=>$values) {
   $distinct=[];
   foreach($values as $e) {
    if(!empty($e['valid_to'])||($e['availability_status']??'observed')!=='observed') {continue;}
    $distinct[self::comparable($key,$e['value'])]=true;
   }
   if(count($distinct)>1) {$conflicts[]=['field'=>$key,'kind'=>'different_source_observations','selected_source'=>$p['fields'][$key]['source']??'','resolution'=>'retain_all_observations'];}
  }
  $p['conflicts']=array_values(array_unique($conflicts,SORT_REGULAR));
  // The FS scan can contain contradictory values without selecting a new scalar.
  // Keep the old evidence, but never turn it back into current proof on storage/read merges.
  foreach(['fs_dic','fs_vat'] as $check) {
   foreach($p['checks'][$check]['conflicting_fields']??[] as $field) {
    if(isset($p['fields'][$field])) {
     $p['fields'][$field]['availability_status']='conflict';
     $p['fields'][$field]['selection_reason']='Uchovaná predchádzajúca hodnota; aktuálne riadky FS si odporujú a nepotvrdzujú jediný výber.';
    }
   }
  }
  return self::refresh_group_states($p);
 }
 /** Availability of retained data is distinct from completion of the latest source scan. */
 public static function refresh_group_states(array $p): array {
  $p['groups']=$p['groups']??[];
  foreach($p['groups'] as $key=>&$group) {
   if(self::has_data($group)&&($group['availability_status']??'not_checked')==='not_checked') {
    $group['availability_status']=in_array($group['last_attempt_status']??'',['source_unavailable','requires_access','not_found'],true)?'stale':'observed';
   }
  }unset($group);
  $check=$p['checks']['ruz']??null;
  if(is_array($check)) {
   $pending=!empty($check['pending']);$status=$check['availability_status']??'not_checked';$error=$check['error']??null;
   foreach(['financials','metrics'] as $key) {
    if(!isset($p['groups'][$key])) {continue;}
    $group=&$p['groups'][$key];
    $group['sync']=['status'=>$status,'complete'=>$status==='observed'&&!$pending&&!$error,'pending'=>$pending,'remaining_tasks'=>$check['remaining_tasks']??null,'completed_tasks'=>$check['completed_tasks']??null,'last_attempt_at'=>$check['checked_at']??null,'last_successful_retrieval_at'=>$check['retrieved_at']??null,'error'=>$error];
    if(self::has_data($group)) {
     if($status==='conflict') {$group['availability_status']='conflict';}
     elseif($pending) {$group['availability_status']='partial';}
     elseif($error||in_array($status,['source_unavailable','invalid_response','requires_access','not_found','not_configured','unsupported','stale'],true)) {$group['availability_status']='stale';}
     elseif($status==='observed') {$group['availability_status']='observed';}
     if($status!=='not_checked') {$group['last_attempt_status']=$status;}
    }unset($group);
   }
  }
  return $p;
 }
 private static function has_data(array $group): bool {
  foreach($group['records']??[] as $record) {
   $value=$record['value']??null;
   if(in_array($record['availability_status']??'observed',['observed','stale','partial','conflict'],true)&&$value!==null&&$value!==''&&$value!==[]) {return true;}
  }
  return false;
 }
 /** Direct registry identity is not a claim of legal or economic activity. */
 public static function identity_verification(array $p): array {
  if(!preg_match('/^[0-9]{8}$/D',(string)($p['ico']??''))) {return ['status'=>'unconfirmed','scope'=>'identity_only','reason'=>'IČO nemá platný formát.'];}
  $candidates=array_merge($p['observations']['name']??[],isset($p['fields']['name'])?[$p['fields']['name']]:[]);$best=null;$bestAt=-1;
  foreach($candidates as $e) {
   $source=self::source_key($e);$check=$p['checks'][$source]??[];
   if(!in_array($source,['rpo','orsr'],true)||parse_url($e['source_url']??'',PHP_URL_SCHEME)!=='https'||($check['availability_status']??'')!=='observed'||($e['availability_status']??'')!=='observed'||($e['match_method']??'')!=='exact_ico'||($e['kind']??'reported')!=='reported'||!is_string($e['value']??null)||trim($e['value'])==='') {continue;}
   if(!empty($e['valid_to'])&&$e['valid_to']<gmdate('Y-m-d')||!empty($e['valid_from'])&&$e['valid_from']>gmdate('Y-m-d')) {continue;}
   if(isset($check['record_id'])&&(string)$check['record_id']!==(string)($e['source_record_id']??'')) {continue;}
   $at=is_string($e['retrieved_at']??null)?strtotime($e['retrieved_at']):false;
   if($at===false||$at>time()+60) {continue;}
   if($at>=$bestAt) {$best=$e;$bestAt=$at;}
  }
  if(!$best) {return ['status'=>'unconfirmed','scope'=>'identity_only','reason'=>'Presná identita nebola potvrdená dostupným priamym overením registra.'];}
  return ['status'=>'verified','scope'=>'identity_only','matched_ico'=>$p['ico'],'matched_name'=>$best['value']]+array_intersect_key($best,array_flip(['source','source_url','source_record_id','retrieved_at','source_updated_at','match_method','kind','valid_from','valid_to']));
 }
 /** One projection for storage, dashboard and both export formats. */
 public static function summarize(array $p): array {
  $p=self::refresh_group_states($p);
  $v=static fn($k)=>$p['fields'][$k]['value']??null;
  $found=is_string($v('name'))&&$v('name')!=='';
  $legal=$p['fields']['registration_status']??null;$source=$legal?self::source_key($legal):'';
  $fresh=$legal && ($legal['availability_status']??'observed')==='observed'&&in_array($source,['rpo','orsr'],true);
  $registered=$fresh&&in_array($legal['value'],['registered','registered_without_termination'],true);
  $ended=$fresh&&in_array($legal['value'],['terminated','dissolved'],true);
  if(($p['checks']['fs_vat']['availability_status']??'')==='not_found') {
   foreach(['vat_id','vat_registered_on','vat_payer_from','vat_registration_type'] as $field) {if(isset($p['fields'][$field])) {$p['fields'][$field]['availability_status']='stale';}}
  }
  $identity=self::identity_verification($p);
  $status=$registered?'Evidovaná spoločnosť bez zobrazeného výmazu':($ended?'Zdroj uvádza zánik spoločnosti':'Právny stav aktuálne nepotvrdený');
  if($identity['status']==='verified'&&!$registered&&!$ended) {$status='Identita overená v '.($identity['source']??'registri').'; právny stav aktuálne nepotvrdený';}
  $address=$v('address');
  if(is_array($address)) {$address=implode(', ',array_filter([$address['street']??'',trim(($address['postal_code']??'').' '.($address['city']??'')),$address['country']??'']));}
  return ['schema_version'=>'2.1','ico'=>$p['ico'],'found'=>$found,'identity_verified'=>$identity['status']==='verified','identity_verification'=>$identity,'legal_status_verified'=>(bool)($registered||$ended),'economic_activity_status'=>'not_assessed','name'=>$v('name'),'legal_form'=>$v('legal_form'),'address'=>$address,'dic'=>$v('dic'),'vat_id'=>(($p['checks']['fs_vat']['availability_status']??'')==='not_found'?null:$v('vat_id')),'founded_on'=>$v('founded_on'),'dissolved_on'=>$v('dissolved_on'),'active'=>$registered?true:($ended?false:null),'verified'=>(bool)($registered||$ended),'verification_status'=>$registered?'verified_registered':($ended?'verified_risky':'unconfirmed'),'status'=>$status,'is_risky'=>$ended,'risk_reason'=>$ended?$status:null,'verified_at'=>($registered||$ended)?str_replace('T',' ',substr($legal['retrieved_at']??'',0,19)):null,'profile'=>$p,'pending'=>!empty($p['checks']['ruz']['pending'])&&empty($p['checks']['ruz']['error']),'source'=>'Pozri pôvod jednotlivých údajov'];
 }
}
