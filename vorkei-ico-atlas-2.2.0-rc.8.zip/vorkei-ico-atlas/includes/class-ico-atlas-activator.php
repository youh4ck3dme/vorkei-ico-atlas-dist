<?php
/**
 * Plugin Activator for VORKEI IČO ATLAS.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Vorkei_Ico_Atlas_Activator {

	public static function maybe_upgrade(): void {
		if (get_option('vorkei_ico_schema_version') !== '2.1.1') {
            try {self::activate();}
            catch (RuntimeException $e) {
                update_option('vorkei_ico_migration_error',$e->getMessage(),false);
                add_action('admin_notices',static function() {echo '<div class="notice notice-error"><p>'.esc_html((string)get_option('vorkei_ico_migration_error','')).'</p></div>';});
            }
        }
	}

	public static function activate(): void {
		self::create_entities_table();
		self::ensure_cct_columns();
		self::set_default_options();
		global $wpdb;
        $cols=(array)$wpdb->get_col('DESCRIBE '.$wpdb->prefix.'vorkei_ico_entities');
        $required=['id','ico','name','legal_form','address','company_status','is_active','is_risky','risk_reason','verified_at','profile_json','founded_on','dissolved_on','verification_status','last_attempt_at','last_success_at','created_at'];
        if(array_diff($required,$cols)) {throw new RuntimeException('IČO Atlas: migrácia tabuľky profilov nebola dokončená.');}
        $unique=[];
        foreach((array)$wpdb->get_results('SHOW INDEX FROM '.$wpdb->prefix.'vorkei_ico_entities',ARRAY_A) as $index) {
            if((int)($index['Non_unique']??1)===0) {$unique[(string)$index['Key_name']][(int)$index['Seq_in_index']]=(string)$index['Column_name'];}
        }
        if(($unique['PRIMARY']??[])!==[1=>'id']||($unique['uq_ico']??[])!==[1=>'ico']) {throw new RuntimeException('IČO Atlas: chýba ochrana jedinečnosti profilov.');}
        update_option('vorkei_ico_schema_version','2.1.1');
        delete_option('vorkei_ico_migration_error');
	}

	public static function set_default_options(): void {
		if ( false === get_option( 'vorkei_ico_api_url' ) ) {
			update_option( 'vorkei_ico_api_url', 'https://ico-api.vorkei.com/api/company/proxy-search?ico=' );
		}
		if ( false === get_option( 'vorkei_ico_auto_enrich' ) ) {
			update_option( 'vorkei_ico_auto_enrich', 'yes' );
		}
		if ( false === get_option( 'vorkei_ico_cache_ttl' ) ) {
			update_option( 'vorkei_ico_cache_ttl', 86400 ); // 24 hours
		}
		if ( false === get_option( 'vorkei_ico_alter_cct' ) ) {
			update_option( 'vorkei_ico_alter_cct', 'no' );
		}
	}

	public static function create_entities_table(): void {
		global $wpdb;

		$table_name      = $wpdb->prefix . 'vorkei_ico_entities';
		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE {$table_name} (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			ico VARCHAR(16) NOT NULL,
			name VARCHAR(255) NULL,
			legal_form VARCHAR(128) NULL,
			address TEXT NULL,
			company_status VARCHAR(64) NULL,
			is_active TINYINT(1) DEFAULT 0,
			is_risky TINYINT(1) DEFAULT 0,
			risk_reason TEXT NULL,
			verified_at DATETIME NULL,
			profile_json LONGTEXT NULL,
            founded_on DATE NULL,
            dissolved_on DATE NULL,
            verification_status VARCHAR(40) NULL,
            last_attempt_at DATETIME NULL,
            last_success_at DATETIME NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id),
			UNIQUE KEY uq_ico (ico),
			KEY idx_active (is_active),
			KEY idx_risky (is_risky),
			KEY idx_verified (verified_at)
		) {$charset_collate};";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );
	}

	public static function ensure_cct_columns(): void {
		if ( get_option( 'vorkei_ico_alter_cct', 'no' ) !== 'yes' ) {
			return;
		}
		global $wpdb;

		$tables = [
			$wpdb->prefix . 'jet_cct_customers',
			$wpdb->prefix . 'jet_cct_contractors',
			$wpdb->prefix . 'jet_cct_clients',
		];

		$columns_to_add = [
			'ico'            => 'VARCHAR(16) NULL',
			'legal_form'     => 'VARCHAR(128) NULL',
			'address'        => 'TEXT NULL',
			'company_status' => 'VARCHAR(64) NULL',
			'is_active'      => 'TINYINT(1) DEFAULT 0',
			'is_risky'       => 'TINYINT(1) DEFAULT 0',
			'risk_reason'    => 'TEXT NULL',
			'verified_at'    => 'DATETIME NULL',
		];

		foreach ( $tables as $table ) {
			if ( ! preg_match( '/^[A-Za-z0-9_]+$/D', $table ) ) {
				continue;
			}
			$table_exists = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) ) === $table;
			if ( ! $table_exists ) {
				continue;
			}

			$existing_columns = (array) $wpdb->get_col( "DESCRIBE {$table}" );

			foreach ( $columns_to_add as $col_name => $col_definition ) {
				if ( ! preg_match( '/^[A-Za-z0-9_]+$/D', $col_name ) || in_array( $col_name, $existing_columns, true ) ) {
					continue;
				}
				$wpdb->query( "ALTER TABLE `{$table}` ADD COLUMN `{$col_name}` {$col_definition}" );
			}
		}
	}
}
