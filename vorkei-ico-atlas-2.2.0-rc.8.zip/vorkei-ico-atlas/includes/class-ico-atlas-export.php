<?php
if (!defined('ABSPATH')) { exit; }

/** A referenced view of existing evidence, not another financial calculation. */
class Vorkei_Ico_Atlas_Export {
 const SCHEMA='atlas-compact/1.0';
 private $history=false;
 private $catalog=[];
 private $reports=[];
 private $facts=[];
 private $metrics=[];
 private $emitting=[];

 public static function compact(array $summaries,bool $history=false): array {
  $items=[];
  foreach ($summaries as $summary) {
   if (!is_array($summary)) { throw new InvalidArgumentException('A compact export item must be a summary array.'); }
   $builder=new self(); $builder->history=$history; $items[]=$builder->item($summary);
  }
  return self::canonical(['schema_version'=>self::SCHEMA,'view'=>'normalized_financial_evidence',
   'history_included'=>$history,'full_json_archive'=>['format'=>'json','available'=>true,
    'description'=>'Úplný pôvodný JSON export obsahuje aj zdrojové finančné výkazy a šablóny.'],
   'count'=>count($items),'items'=>$items]);
 }

 private function item(array $summary): array {
  $profile=is_array($summary['profile']??null)?$summary['profile']:[];
  $financialGroup=$profile['groups']['financials']??[];
  $financialRecords=is_array($financialGroup['records']??null)?$financialGroup['records']:[];
  $reportRefs=[]; $omitted=0; $templates=0;
  // Register every version before matching a metric input or a conflict observation.
  foreach ($financialRecords as $record) {
   if (!is_array($record)) { continue; }
   if (self::is_template($record['value']??null)) { $templates++; continue; }
   $ref=$this->catalog_report($record);
   if (!$this->history && !empty($this->catalog[$ref]['meta']['superseded'])) { $omitted++; continue; }
   $reportRefs[$ref]=true;
  }
  foreach (array_keys($reportRefs) as $ref) { $this->emit_report($ref,'report'); }
  foreach ($financialRecords as $record) {
   if (!is_array($record) || self::is_template($record['value']??null)) { continue; }
   $ref=$this->catalog_report($record);
   if (!isset($reportRefs[$ref])) { continue; }
   foreach (['normalized_facts'=>'current','comparative_facts'=>'comparative'] as $key=>$scope) {
    foreach (is_array($record[$key]??null)?$record[$key]:[] as $code=>$fact) {
     if (is_array($fact)) { $this->fact($fact,$ref,$scope,(string)$code,'report'); }
    }
   }
  }
  $metricGroup=$profile['groups']['metrics']??[]; $metricRefs=[];
  foreach ($metricGroup['records']??[] as $record) {
   if (!is_array($record)) { continue; }
   foreach ($this->metric_records($record) as $metric) {
    $ref=$this->metric($metric);
    if ($ref!==null) { $metricRefs[$ref]=true; }
   }
  }
  if (isset($profile['groups']['financials']) && is_array($profile['groups']['financials'])) {
   unset($profile['groups']['financials']['records']);
   $profile['groups']['financials']['report_refs']=array_keys($reportRefs);
   $profile['groups']['financials']['omitted_superseded_count']=$omitted;
   $profile['groups']['financials']['omitted_template_count']=$templates;
  }
  if (isset($profile['groups']['metrics']) && is_array($profile['groups']['metrics'])) {
   unset($profile['groups']['metrics']['records']);
   $profile['groups']['metrics']['metric_refs']=array_keys($metricRefs);
  }
  if (array_key_exists('profile',$summary) && is_array($summary['profile'])) { $summary['profile']=$profile; }
  // Financial observations embedded in conflicts remain evidence, with resolvable refs.
  $summary=$this->rewrite($summary,'conflict_evidence');
  $summary['financials']=['reports'=>(object)$this->reports,'facts'=>(object)$this->facts,'metrics'=>(object)$this->metrics];
  return $summary;
 }

 private function catalog_report(array $record): string {
  $raw=is_array($record['value']??null)?$record['value']:null;
  $identity=is_array($record['report_identity']??null)?$record['report_identity']:[];
  $facts=array_merge(array_values(is_array($record['normalized_facts']??null)?$record['normalized_facts']:[]),
   array_values(is_array($record['comparative_facts']??null)?$record['comparative_facts']:[]));
  $sample=[];
  foreach ($facts as $fact) { if (is_array($fact)) { $sample=$fact; break; } }
  $reportId=$identity['report_id']??$sample['report_id']??$raw['id']??null;
  $type=!empty($record['compact_evidence_stub'])?'evidence_stub':($raw!==null && isset($raw['idUctovnychVykazov'])?'statement':($raw!==null && isset($raw['idSablony'])?'financial_report':'financial_evidence'));
  $legacyVersions=[];
  foreach ([$identity['report_version']??null,$record['report_version']??null] as $version) {
   if (is_string($version) && $version!=='') { $legacyVersions[$version]=true; }
  }
  // A fact's unknown version cannot authorize itself as an alias of this raw report.
  // Legacy records without their own version may use one unanimous fact token.
  if (!$legacyVersions) {
   $factVersions=[];
   foreach ($facts as $fact) { if (is_array($fact) && is_string($fact['report_version']??null) && $fact['report_version']!=='') { $factVersions[$fact['report_version']]=true; } }
   if (count($factVersions)===1) { $legacyVersions=$factVersions; }
  }
  foreach (is_array($record['report_version_aliases']??null)?$record['report_version_aliases']:[] as $alias) {
   if (is_string($alias) && $alias!=='') { $legacyVersions[$alias]=true; }
  }
  $version=$raw!==null?self::hash($raw):self::hash(['identity'=>$identity,
   'dimensions'=>array_intersect_key($sample,array_flip(['source','source_url','source_record_id','source_updated_at','currency','unit','template_id','template_url','consolidated']))]);
  if ($raw===null && !$identity) { $version=self::hash(self::without($record,['normalized_facts','comparative_facts','decoded_tables','retrieved_at'])); }
  $meta=self::without($record,['value','normalized_facts','comparative_facts','decoded_tables','report_identity','superseded_by','compact_evidence_stub','report_version_aliases']);
  if (array_key_exists('superseded_by',$record)) { $meta['source_superseded_by']=$record['superseded_by']; }
  $meta['record_type']=$type; $meta['report_id']=$reportId; $meta['report_version']=$version;
  $meta['version_basis']=$raw!==null?'canonical_raw_record':'canonical_evidence_metadata';
  foreach (['source','source_url','source_record_id','retrieved_at','source_updated_at','valid_as_of','valid_from','valid_to','match_method','availability_status'] as $key) {
   if (!array_key_exists($key,$meta) && array_key_exists($key,$sample)) { $meta[$key]=$sample[$key]; }
  }
  foreach (['statement_id','entity_name','ico','consolidated'] as $key) {
   if (array_key_exists($key,$identity)) { $meta[$key]=$identity[$key]; }
   elseif (array_key_exists($key,$sample)) { $meta[$key]=$sample[$key]; }
  }
  if ($raw!==null) {
   if (array_key_exists('idUctovnejZavierky',$raw)) { $meta['statement_id']=$raw['idUctovnejZavierky']; }
   if (array_key_exists('idUJ',$raw)) { $meta['entity_id']=$raw['idUJ']; }
   if (array_key_exists('idSablony',$raw)) { $meta['template_id']=$raw['idSablony']; }
   $title=is_array($raw['obsah']['titulnaStrana']??null)?$raw['obsah']['titulnaStrana']:[];
   $meta['current_period']=self::period($title['obdobieOd']??$raw['obdobieOd']??null,$title['obdobieDo']??$raw['obdobieDo']??null);
   $meta['comparative_period']=self::period($title['predchadzajuceObdobieOd']??null,$title['predchadzajuceObdobieDo']??null);
   foreach (['nazovUctovnejJednotky'=>'entity_name','ico'=>'ico'] as $from=>$to) { if (array_key_exists($from,$title)) { $meta[$to]=$title[$from]; } }
   $filing=[];
   foreach (['datumZostaveniaK','datumPodania','datumZostavenia','datumSchvalenia','typ','pristupnostDat','zdrojDat'] as $key) {
    if (array_key_exists($key,$raw)) { $filing[$key]=$raw[$key]; }
   }
   if ($filing) { $meta['filing']=$filing; }
   if (isset($raw['prilohy'])) { $meta['attachments']=$raw['prilohy']; }
  }
  foreach (['template_id','template_url','currency','unit','consolidated','unit_basis','unit_source_url'] as $dimension) {
   $values=[]; $present=false;
   foreach ($facts as $fact) {
    if (!is_array($fact) || !array_key_exists($dimension,$fact)) { continue; }
    $present=true; $values[self::hash($fact[$dimension])]=$fact[$dimension];
   }
   if ($present) { $meta[$dimension]=count($values)===1?reset($values):null; }
   elseif (!array_key_exists($dimension,$meta)) { $meta[$dimension]=null; }
  }
  $meta['superseded']=(bool)($record['superseded']??$sample['superseded']??false);
  $ref='r_'.self::hash(['source'=>$meta['source']??null,'source_url'=>$meta['source_url']??null,
   'source_record_id'=>$meta['source_record_id']??null,'report_id'=>$reportId,'report_version'=>$version,'record_type'=>$type]);
  if (isset($this->catalog[$ref])) {
   $legacyVersions+=array_fill_keys($this->catalog[$ref]['aliases'],true);
   if ((strtotime((string)($meta['retrieved_at']??''))?:0)<(strtotime((string)($this->catalog[$ref]['meta']['retrieved_at']??''))?:0)) { $meta=$this->catalog[$ref]['meta']; }
  }
  $legacyVersions[$version]=true;
  $aliases=array_keys($legacyVersions); sort($aliases,SORT_STRING);
  $meta['source_report_versions']=$aliases;
  $this->catalog[$ref]=['meta'=>$meta,'aliases'=>$aliases];
  return $ref;
 }

 private function emit_report(string $ref,string $role): void {
  if (isset($this->reports[$ref]) && ($this->reports[$ref]['view_role']??'')==='report') { return; }
  $meta=$this->catalog[$ref]['meta'];
  if ($role!=='report') {
   $allowed=['record_type','report_id','report_version','version_basis','source_report_versions','statement_id','entity_id','entity_name','ico',
    'source','source_url','source_record_id','retrieved_at','source_updated_at','valid_as_of','valid_from','valid_to','match_method','kind','availability_status',
    'template_id','template_url','currency','unit','consolidated','unit_basis','unit_source_url','superseded'];
   $extra=self::without($meta,array_merge($allowed,['attachments','filing','financial_issues','current_period','comparative_period']));
   $meta=array_intersect_key($meta,array_flip($allowed));
   if ($extra) { $meta['evidence_metadata']=$extra; }
   $meta['record_type']='evidence_stub';
  }
  // A placeholder also lets fact links resolve while provenance is rewritten.
  $meta['view_role']=$role; $this->reports[$ref]=$meta; $this->emitting[$ref]=true;
  $meta=$this->rewrite($meta,$role==='report'?'provenance_evidence':$role);
  unset($this->emitting[$ref]); $this->reports[$ref]=$meta;
 }

 private function report_reference(array $record,string $role): array {
  $ref=$this->catalog_report($record);
  if (!empty($this->emitting[$ref])) {
   // A copied upstream envelope can describe this very report. Keep its proof
   // as a separate metadata-only leaf, rather than linking a report to itself.
   $meta=$this->catalog[$ref]['meta'];
   $allowed=['report_id','report_version','source_report_versions','statement_id','entity_id','entity_name','ico','source','source_url',
    'source_record_id','retrieved_at','source_updated_at','valid_as_of','valid_from','valid_to','match_method','kind','availability_status',
    'template_id','template_url','currency','unit','consolidated','unit_basis','unit_source_url','superseded'];
   $stub=array_intersect_key($meta,array_flip($allowed));
   $stub['record_type']='evidence_stub'; $stub['view_role']='provenance_evidence';
   $stub['evidence_metadata']=self::metadata_only(self::without($record,['value','normalized_facts','comparative_facts','decoded_tables','report_identity']));
   $stubRef='r_'.self::hash($stub); $this->reports[$stubRef]=$stub; return ['report_ref'=>$stubRef];
  }
  $this->emit_report($ref,$role); return ['report_ref'=>$ref];
 }

 /** Keep proof metadata without copying its archived raw financial payload. */
 private static function metadata_only($value) {
  if (is_object($value)) {
   $map=get_object_vars($value);
   if (self::is_report($map) || self::is_template($map)) { return self::metadata_only(self::raw_array($value)); }
   $out=new stdClass(); foreach ($map as $key=>$item) { $out->$key=self::metadata_only($item); } return $out;
  }
  if (!is_array($value)) { return $value; }
  if (self::is_template($value)) { return ['template_id'=>$value['id']??null,'omitted_payload'=>'raw_financial_template']; }
  if (self::is_report($value)) { return ['report_id'=>$value['id']??null,'report_version'=>self::hash($value),'omitted_payload'=>'raw_financial_report']; }
  $out=[];
  foreach ($value as $key=>$item) {
   if (in_array($key,['normalized_facts','comparative_facts','decoded_tables'],true)) { continue; }
   if ($key==='value' && (self::is_report($item) || self::is_template($item))) { $out['payload_metadata']=self::metadata_only($item); }
   else { $out[$key]=self::metadata_only($item); }
  }
  return $out;
 }

 /** Legacy report_version hashes are aliases; never silently choose another version. */
 private function resolve_report(array $fact,?string $fallback=null): ?string {
  $matches=[];
  foreach ($this->catalog as $ref=>$entry) {
   $meta=$entry['meta']; $score=0;
   if (array_key_exists('report_id',$fact) && $fact['report_id']!==null) {
    if ((string)$fact['report_id']!==(string)($meta['report_id']??'')) { continue; } $score+=10;
   }
   if (!empty($fact['report_version'])) {
    if (!in_array((string)$fact['report_version'],$entry['aliases'],true)) { continue; } $score+=100;
   }
   foreach (['source_url','source_record_id'] as $key) {
    if (!empty($fact[$key])) { if ($fact[$key]!==($meta[$key]??null)) { continue 2; } $score+=10; }
   }
   if (($meta['record_type']??'')==='evidence_stub') {
    foreach (['currency','unit','consolidated','template_id'] as $key) {
     if (array_key_exists($key,$fact) && array_key_exists($key,$meta) && $fact[$key]!==$meta[$key]) { continue 2; }
    }
   }
   if ($fallback===$ref) { $score+=1; }
   if ($score>0) { $matches[$ref]=$score; }
  }
  if (!$matches) { return $fallback!==null && empty($fact['report_version'])?$fallback:null; }
  arsort($matches,SORT_NUMERIC); $best=array_key_first($matches);
  $ties=array_keys($matches,reset($matches),true);
  return count($ties)===1?$best:($fallback!==null && in_array($fallback,$ties,true)?$fallback:null);
 }

 private function stub(array $fact,string $role): string {
  $identity=[];
  foreach (['report_id','statement_id','report_version','entity_name','ico','consolidated'] as $key) { if (array_key_exists($key,$fact)) { $identity[$key]=$fact[$key]; } }
  $record=['report_identity'=>$identity,'compact_evidence_stub'=>true];
  foreach (['source','source_url','source_record_id','retrieved_at','source_updated_at','valid_as_of','valid_from','valid_to','match_method','kind','availability_status','superseded'] as $key) {
   if (array_key_exists($key,$fact)) { $record[$key]=$fact[$key]; }
  }
  $record['normalized_facts']=['evidence'=>$fact];
  $ref=$this->catalog_report($record); $this->emit_report($ref,$role); return $ref;
 }

 private function fact(array $fact,?string $fallback,string $scope,string $code,string $role): string {
  $ref=$this->resolve_report($fact,$fallback);
  if ($ref===null) { $ref=$this->stub($fact,$role==='report'?'metric_input_evidence':$role); }
  elseif (!isset($this->reports[$ref])) { $this->emit_report($ref,$role==='report'?'metric_input_evidence':$role); }
  $meta=$this->reports[$ref]; $body=$fact;
  foreach (['report_id','statement_id','entity_name','ico','source','source_url','source_record_id','retrieved_at','source_updated_at',
   'valid_as_of','valid_from','valid_to','template_id','template_url','currency','unit','consolidated','unit_basis','unit_source_url','superseded','kind','match_method','normalizer'] as $key) {
   if (array_key_exists($key,$body) && array_key_exists($key,$meta) && $body[$key]===$meta[$key]) { unset($body[$key]); }
  }
  // Its original alias remains in reports.source_report_versions.
  unset($body['report_version']);
  $body['report_ref']=$ref;
  if (!array_key_exists('fieldcode',$body)) { $body['fieldcode']=$code!==''?$code:null; }
  if (!array_key_exists('column',$body)) { $body['column']=$scope!==''?$scope:null; }
  $missing=[];
  foreach (['value','raw_value','row','period'] as $key) { if (!array_key_exists($key,$body)) { $body[$key]=null; $missing[]=$key; } }
  if ($missing) { $body['not_provided']=$missing; }
  $id='f_'.self::hash($body); $this->facts[$id]=$body; return $id;
 }

 private function metric_records(array $record): array {
  if (is_array($record['value']??null) && isset($record['value']['inputs'])) {
   return [array_replace(self::without($record,['value']),$record['value'])];
  }
  if (is_array($record['value']??null) && !isset($record['inputs'])) {
   $out=[];
   foreach ($record['value'] as $code=>$value) {
    if (is_array($value) && isset($value['inputs'],$value['formula'])) {
     $out[]=array_replace(self::without($record,['value']),$value,['metric_code'=>$code,'legacy_metric_key'=>$code]);
    }
   }
   if ($out) { return $out; }
  }
  return [$record];
 }

 private function metric(array $metric): ?string {
  if (!$this->history && !empty($metric['superseded'])) { return null; }
  $report=$this->resolve_report(self::without($metric,['source_record_id']));
  if (!$this->history && $report!==null && !empty($this->catalog[$report]['meta']['superseded'])) { return null; }
  $inputs=is_array($metric['inputs']??null)?$metric['inputs']:[];
  // An old metric cannot pull its superseded report back into the default view.
  foreach ($inputs as $input) {
   if (!is_array($input)) { continue; }
   $ref=$this->resolve_report($input);
   if (!$this->history && (!empty($input['superseded']) || ($ref!==null && !empty($this->catalog[$ref]['meta']['superseded'])))) { return null; }
  }
  $refs=[];
  foreach ($inputs as $key=>$input) {
   if (!is_array($input)) { $input=['value'=>$input,'raw_value'=>$input,'input_shape'=>'scalar']; }
   $refs[$key]=['fact_ref'=>$this->fact($input,null,(string)($input['column']??''),(string)$key,'metric_input_evidence')];
  }
  $body=$metric; $body['inputs']=$refs;
  // Canonical report refs replace legacy version tokens when they are available.
  if ($report!==null) {
   if (!isset($this->reports[$report])) { $this->emit_report($report,'metric_input_evidence'); }
   $body['report_ref']=$report; unset($body['report_version'],$body['report_id']);
   foreach (['source_url','retrieved_at','source_updated_at','valid_as_of','valid_from','valid_to','consolidated'] as $key) {
    if (array_key_exists($key,$body) && array_key_exists($key,$this->reports[$report]) && $body[$key]===$this->reports[$report][$key]) { unset($body[$key]); }
   }
  }
  $body=$this->rewrite($body,'metric_input_evidence');
  $identity=$body;
  if ($report!==null && is_string($identity['source_record_id']??null) && str_starts_with($identity['source_record_id'],'financial-metric:')) {
   foreach ($this->catalog[$report]['aliases'] as $alias) {
    $identity['source_record_id']=str_replace(':'.$alias.':',':'.$this->catalog[$report]['meta']['report_version'].':',$identity['source_record_id']);
   }
  }
  $id='m_'.self::hash($identity); $this->metrics[$id]=$body; return $id;
 }

 /** Only known financial payloads are replaced; other evidence is kept. */
 private function rewrite($value,string $role) {
  if (is_object($value)) {
   $map=get_object_vars($value);
   if (self::is_report($map) || self::is_template($map)) { return $this->rewrite(self::raw_array($value),$role); }
   $out=new stdClass(); foreach ($map as $key=>$item) { $out->$key=$this->rewrite($item,$role); } return $out;
  }
  if (!is_array($value)) { return $value; }
  if (isset($value['fieldcode']) && (array_key_exists('report_id',$value) || array_key_exists('source_record_id',$value)) && (array_key_exists('value',$value) || array_key_exists('raw_value',$value))) {
   return ['fact_ref'=>$this->fact($value,null,(string)($value['column']??''),(string)$value['fieldcode'],$role)];
  }
  if (self::is_template($value)) { return ['template_id'=>$value['id']??null,'omitted_payload'=>'raw_financial_template']; }
  if (self::is_report($value)) {
   return $this->report_reference(['value'=>$value],$role);
  }
  if (is_array($value['value']??null) && self::is_template($value['value'])) {
   $out=self::without($value,['value','decoded_tables']); $out['template_id']=$value['value']['id']??null; $out['omitted_payload']='raw_financial_template'; return $this->rewrite($out,$role);
  }
  if (is_array($value['value']??null) && self::is_report($value['value'])) {
   return $this->report_reference($value,$role);
  }
  $out=[];
  foreach ($value as $key=>$item) {
   if ($key==='decoded_tables') { continue; }
   $out[$key]=$this->rewrite($item,$role);
  }
  return $out;
 }

 private static function is_template($value): bool { return is_array($value) && isset($value['tabulky'],$value['nariadenieMF']) && !isset($value['obsah']); }
 /** Normalize a recognized raw payload without changing ordinary evidence objects. */
 private static function raw_array($value) {
  if (is_object($value)) { $value=get_object_vars($value); }
  if (is_array($value)) { foreach ($value as $key=>$item) { $value[$key]=self::raw_array($item); } }
  return $value;
 }
 private static function is_report($value): bool { return is_array($value) && (isset($value['idSablony'],$value['obsah']) || isset($value['idUctovnychVykazov'])); }
 private static function period($from,$to): ?array { return is_string($from)&&is_string($to)?['from'=>$from,'to'=>$to]:null; }
 private static function without(array $value,array $keys): array { return array_diff_key($value,array_flip($keys)); }
 private static function hash($value): string {
  return hash('sha256',json_encode(self::canonical($value),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION|JSON_THROW_ON_ERROR));
 }
 /** Sort map keys recursively, while keeping every list in its original order. */
 private static function canonical($value) {
  if (is_object($value)) { $map=get_object_vars($value); ksort($map,SORT_STRING); $out=new stdClass(); foreach ($map as $key=>$item) { $out->$key=self::canonical($item); } return $out; }
  if (!is_array($value)) { return $value; }
  if ($value!==[] && array_keys($value)!==range(0,count($value)-1)) { ksort($value,SORT_STRING); }
  foreach ($value as $key=>$item) { $value[$key]=self::canonical($item); }
  return $value;
 }
}
