(function () {
    'use strict';
    const config = window.vorkeiFirmaBind;
    if (!config || !config.url || !config.nonce) return;
    // Resolve Woo's export while this dependent script is executing, not in an anonymous later callback.
    const blockStores = config.blocks && window.wc ? window.wc.wcBlocksData : null;
    const states = new WeakMap();
    const text = value => typeof value === 'string' ? value : '';
    const validIco = value => /^[0-9]{8}$/.test(value);
    const vatValue = card => card.vat_status === 'in_registry' ? text(card.vat_id) : '';
    const message = card => {
        if (card.availability === 'not_found') return 'Bez nálezu v overenom registri. Údaje vyplňte ručne.';
        if (card.availability !== 'found') return 'Register je dočasne nedostupný. Údaje môžete vyplniť ručne.';
        const vat = vatValue(card);
        return 'Údaje podľa registra' + (card.retrieved_at ? ' k ' + card.retrieved_at : '') +
            (card.stale ? ' (staršia uložená kópia)' : '') + '. ' + (vat
                ? 'Register uvádza IČ DPH ' + vat + '. Do poľa sa nezapíše. Ak ho zadáte vy, VIES sa skontroluje pri odoslaní.'
                : 'Register IČ DPH neposkytol. Ak ho vyplníte, VIES sa skontroluje pri odoslaní.');
    };

    // A bounded public card is the only browser payload; no profile or snapshot is submitted.
    async function card(ico, controller) {
        const timeout = setTimeout(() => controller.abort('timeout'), 8000);
        try {
            const response = await fetch(config.url, {
                method: 'POST', credentials: 'same-origin', signal: controller.signal,
                headers: { 'Content-Type': 'application/json', 'X-Vorkei-Nonce': config.nonce, 'X-WP-Nonce': config.restNonce || '' },
                body: JSON.stringify({ ico })
            });
            if (!response.ok) throw new Error('unavailable');
            return await response.json();
        } finally { clearTimeout(timeout); }
    }

    function stateFor(form) {
        if (!states.has(form)) states.set(form, { timer: null, sequence: 0, controller: null, filled: {}, pending: false, lookupIco: '', lookupState: 'idle' });
        return states.get(form);
    }
    function mappingFor(form) {
        if (form.classList.contains('checkout')) return {
            ico: 'billing_vorkei_ico', name: 'billing_company', street: 'billing_address_1',
            postal_code: 'billing_postcode', city: 'billing_city', dic: 'billing_vorkei_dic', ic_dph: 'billing_vorkei_ic_dph'
        };
        const id = form.getAttribute('data-form-id');
        return form.classList.contains('jet-form-builder') && config.jetForms ? config.jetForms[id] : null;
    }
    function elementFor(form, field) {
        const element = field ? form.elements.namedItem(field) : null;
        return element && typeof element.value === 'string' ? element : null;
    }
    function statusFor(form, ico) {
        let status = form.querySelector('[data-vorkei-firmabind-status]');
        if (!status) {
            status = document.createElement('p');
            status.setAttribute('data-vorkei-firmabind-status', '');
            status.setAttribute('role', 'status');
            status.setAttribute('aria-live', 'polite');
            ico.insertAdjacentElement('afterend', status);
        }
        return status;
    }
    function showStatus(status, result) {
        status.textContent = message(result);
        const source = Object.values(result.sources || {}).find(entry => entry && typeof entry.source_url === 'string');
        if (!source) return;
        try {
            const url = new URL(source.source_url);
            if (url.protocol !== 'https:') return;
            const link = document.createElement('a');
            link.href = url.href;
            link.target = '_blank';
            link.rel = 'noopener noreferrer';
            link.textContent = ' Zdroj';
            status.appendChild(link);
        } catch (error) { /* A malformed source URL cannot affect form submission. */ }
    }
    function fillForm(form, mapping, result, state) {
        const values = { name: result.name, street: result.street, postal_code: result.postal_code,
            city: result.city, dic: result.dic };
        state.pending = true;
        try {
            Object.keys(values).forEach(key => {
                const field = elementFor(form, mapping[key]);
                if (!field) return;
                const current = field.value;
                // Preserve values the customer has edited; the server records any divergence.
                if (current !== '' && current !== state.filled[key]) return;
                const value = text(values[key]);
                if (!value && !Object.prototype.hasOwnProperty.call(state.filled, key)) return;
                field.value = value;
                state.filled[key] = value;
                field.dispatchEvent(new Event('input', { bubbles: true }));
                field.dispatchEvent(new Event('change', { bubbles: true }));
            });
        } finally { state.pending = false; }
        if (window.jQuery && form.classList.contains('checkout')) window.jQuery(document.body).trigger('update_checkout');
    }
    function onFormInput(event) {
        const target = event.target;
        if (!target || !target.form) return;
        const form = target.form;
        const mapping = mappingFor(form);
        if (!mapping || target.name !== mapping.ico) return;
        const state = stateFor(form);
        if (state.pending) return;
        const ico = target.value.trim();
        if (ico === state.lookupIco && (state.lookupState === 'pending' || state.lookupState === 'complete')) return;
        clearTimeout(state.timer);
        if (state.controller) state.controller.abort();
        const sequence = ++state.sequence;
        state.lookupIco = ico;
        target.setCustomValidity(ico && !validIco(ico) ? 'IČO musí obsahovať presne 8 číslic.' : '');
        const status = statusFor(form, target);
        if (!ico) { state.lookupState = 'idle'; status.textContent = ''; return; }
        if (!validIco(ico)) { state.lookupState = 'invalid'; status.textContent = 'IČO musí obsahovať presne 8 číslic.'; return; }
        state.lookupState = 'pending';
        status.textContent = 'Získavam údaje firmy…';
        state.timer = setTimeout(async function () {
            state.controller = new AbortController();
            try {
                const result = await card(ico, state.controller);
                if (sequence !== state.sequence || target.value.trim() !== ico) return;
                state.lookupState = result.availability === 'found' || result.availability === 'not_found' ? 'complete' : 'failed';
                if (result.availability === 'found') fillForm(form, mapping, result, state);
                showStatus(status, result);
            } catch (error) {
                if (sequence === state.sequence) {
                    state.lookupState = 'failed';
                    status.textContent = 'Overenie je dočasne nedostupné. Údaje môžete vyplniť ručne.';
                }
            }
        }, event.type === 'change' ? 0 : 450);
    }
    document.addEventListener('input', onFormInput);
    document.addEventListener('change', onFormInput);

    function initBlocks() {
        const data = window.wp && window.wp.data;
        const stores = blockStores;
        if (!data || !stores || !stores.checkoutStore || !stores.cartStore) return;
        const checkout = data.select(stores.checkoutStore);
        const checkoutDispatch = data.dispatch(stores.checkoutStore);
        const cart = data.select(stores.cartStore);
        const cartDispatch = data.dispatch(stores.cartStore);
        // Public Woo APIs are feature-detected; unsupported versions retain manual fields.
        if (!checkout || !checkoutDispatch || !cart || !cartDispatch || typeof checkout.getAdditionalFields !== 'function' ||
            typeof checkoutDispatch.setAdditionalFields !== 'function' ||
            typeof cart.getCustomerData !== 'function' || typeof cartDispatch.setBillingAddress !== 'function') return;
        const ids = config.blockFields || { ico: 'vorkei-firmabind/ico', dic: 'vorkei-firmabind/dic', ic_dph: 'vorkei-firmabind/ic-dph' };
        let previousIco = '', sequence = 0, timer, controller, filling = false, lookupState = 'idle';
        const filled = {};
        const retryRoot = document.querySelector('[data-vorkei-firmabind-block-status]');
        const retryButton = retryRoot && retryRoot.querySelector('[data-vorkei-firmabind-block-retry]');
        const retryMessage = retryRoot && retryRoot.querySelector('[data-vorkei-firmabind-block-message]');
        if (retryButton) retryButton.addEventListener('click', () => observe(true));
        function notify(value, retry = false) {
            if (retryRoot) retryRoot.hidden = !retry;
            if (retryMessage) retryMessage.textContent = retry ? value : '';
            // Woo's notice renderer ignores WordPress notice actions. The retry
            // control lives in our own server-rendered sibling, outside React.
            const notices = data.dispatch('core/notices');
            if (notices && typeof notices.createNotice === 'function')
                notices.createNotice('info', value, { id: 'vorkei-firmabind', context: 'wc/checkout', isDismissible: true });
        }
        function observe(force = false) {
            if (filling) return;
            const fields = checkout.getAdditionalFields() || {};
            const ico = text(fields[ids.ico]).trim();
            if (ico === previousIco && !(force === true && lookupState === 'failed')) return;
            previousIco = ico;
            clearTimeout(timer);
            if (controller) controller.abort();
            const version = ++sequence;
            if (retryRoot) retryRoot.hidden = true;
            if (!ico) { lookupState = 'idle'; return; }
            if (!validIco(ico)) { lookupState = 'invalid'; notify('IČO musí obsahovať presne 8 číslic.'); return; }
            lookupState = 'pending';
            timer = setTimeout(async function () {
                controller = new AbortController();
                try {
                    const result = await card(ico, controller);
                    if (version !== sequence) return;
                    lookupState = result.availability === 'found' || result.availability === 'not_found' ? 'complete' : 'failed';
                    if (result.availability === 'found') {
                        filling = true;
                        try {
                            const address = Object.assign({}, cart.getCustomerData().billingAddress || {});
                            const addressValues = { company: result.name, address_1: result.street, postcode: result.postal_code, city: result.city };
                            Object.keys(addressValues).forEach(key => {
                                if ((!address[key] || address[key] === filled[key]) && text(addressValues[key])) {
                                    address[key] = text(addressValues[key]); filled[key] = address[key];
                                }
                            });
                            cartDispatch.setBillingAddress(address);
                            const extra = Object.assign({}, checkout.getAdditionalFields() || {});
                            const taxes = { [ids.dic]: text(result.dic) };
                            Object.keys(taxes).forEach(key => {
                                if (!extra[key] || extra[key] === filled[key]) { extra[key] = taxes[key]; filled[key] = taxes[key]; }
                            });
                            checkoutDispatch.setAdditionalFields(extra);
                        } finally { filling = false; }
                    }
                    notify(message(result), lookupState === 'failed');
                } catch (error) {
                    if (version === sequence) {
                        lookupState = 'failed';
                        notify('Overenie je dočasne nedostupné. Údaje môžete vyplniť ručne.', true);
                    }
                }
            }, 450);
        }
        data.subscribe(observe);
        observe();
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initBlocks, { once: true });
    else initBlocks();
}());
