<?php
if (!defined('ABSPATH')) { exit; }

final class Vorkei_FirmaBind_REST {
    public static function install(): void {
        if (get_option('vorkei_firmabind_limits_version') === '1.1') { return; }
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $table = $wpdb->prefix . 'vorkei_firmabind_limits';
        dbDelta("CREATE TABLE {$table} (
            bucket varchar(64) NOT NULL,
            hits int unsigned NOT NULL DEFAULT 0,
            expires_at bigint unsigned NOT NULL,
            PRIMARY KEY  (bucket),
            KEY expires_at (expires_at)
        ) " . $wpdb->get_charset_collate() . ';');
        if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table))) !== $table) {
            throw new RuntimeException('FirmaBind: limity požiadaviek nie sú pripravené.');
        }
        $columns = (array)$wpdb->get_col("DESCRIBE {$table}");
        if (array_diff(['bucket','hits','expires_at'], $columns)) {
            throw new RuntimeException('FirmaBind: tabuľke limitov chýbajú povinné stĺpce.');
        }
        $primary = []; $expiry = [];
        foreach ((array)$wpdb->get_results("SHOW INDEX FROM {$table}", ARRAY_A) as $index) {
            if (($index['Key_name'] ?? '') === 'PRIMARY' && (int)($index['Non_unique'] ?? 1) === 0) {
                $primary[(int)$index['Seq_in_index']] = (string)$index['Column_name'];
            }
            if (($index['Key_name'] ?? '') === 'expires_at') {
                $expiry[(int)$index['Seq_in_index']] = (string)$index['Column_name'];
            }
        }
        if ($primary !== [1=>'bucket'] || $expiry !== [1=>'expires_at']) {
            throw new RuntimeException('FirmaBind: indexy limitov sa nepodarilo pripraviť.');
        }
        update_option('vorkei_firmabind_limits_version', '1.1', false);
    }

    public static function register(): void {
        register_rest_route('vorkei-firmabind/v1', '/card', [
            'methods'=>'POST', 'callback'=>[self::class,'card'],
            'permission_callback'=>[self::class,'permission'],
            'args'=>['ico'=>['required'=>true, 'type'=>'string', 'validate_callback'=>static function($v) {
                return is_string($v) && (bool)preg_match('/^[0-9]{8}$/D', $v);
            }]],
        ]);
        register_rest_route('vorkei-firmabind/v1', '/snapshots/(?P<id>[0-9]+)', [
            'methods'=>'GET', 'callback'=>[self::class,'snapshot'],
            'permission_callback'=>static fn()=>current_user_can('manage_options'),
        ]);
    }

    public static function permission($request) {
        if (!wp_verify_nonce((string)$request->get_header('X-Vorkei-Nonce'), 'vorkei_firmabind_card')) {
            return new WP_Error('firmabind_nonce', 'Obnovte stránku a skúste to znova.', ['status'=>403]);
        }
        // WordPress calls permission callbacks again while building Allow headers.
        // Permissions must be free of quota and network side effects.
        return true;
    }

    /** Shared also by server-side submissions so another form cannot bypass the proxy quota. */
    public static function budget() {
        // REMOTE_ADDR is intentional: a caller cannot bypass this using a forged forwarded header.
        $ip = (string)($_SERVER['REMOTE_ADDR'] ?? 'unknown');
        $now = time();
        $ipKey = hash_hmac('sha256', $ip . '|' . intdiv($now,60), wp_salt('nonce'));
        $dayKey = hash('sha256', 'shop|' . gmdate('Y-m-d', $now));
        $perIp = max(1,min(120,(int)get_option('vorkei_firmabind_ip_limit',12)));
        $perDay = max(1,min(100000,(int)get_option('vorkei_firmabind_daily_limit',1000)));
        if (!self::take($ipKey,$perIp, $now+120) || !self::take($dayKey,$perDay,strtotime('tomorrow UTC'))) {
            return new WP_Error('firmabind_limit', 'Limit overovania bol dosiahnutý. Údaje môžete vyplniť ručne.', ['status'=>429]);
        }
        return true;
    }

    /** Atomic conditional increment: concurrent requests cannot exceed either limit. */
    private static function take(string $bucket,int $limit,int $expires): bool {
        global $wpdb;
        $table = $wpdb->prefix . 'vorkei_firmabind_limits';
        $wpdb->query($wpdb->prepare("DELETE FROM {$table} WHERE expires_at < %d LIMIT 100",time()));
        if ($wpdb->query($wpdb->prepare("INSERT IGNORE INTO {$table} (bucket,hits,expires_at) VALUES (%s,0,%d)",$bucket,$expires)) === false) { return false; }
        return $wpdb->query($wpdb->prepare("UPDATE {$table} SET hits=hits+1 WHERE bucket=%s AND hits < %d",$bucket,$limit)) === 1;
    }

    public static function card($request) {
        try {
            $ico = (string)$request->get_param('ico');
            if (!preg_match('/^[0-9]{8}$/D',$ico)) { throw new InvalidArgumentException(); }
            $budget = self::budget();
            if (is_wp_error($budget)) { return $budget; }
            $response = new WP_REST_Response(self::public_card(Vorkei_FirmaBind_Identity::get($ico)),200);
            $response->header('Cache-Control','no-store, private');
            return $response;
        } catch (InvalidArgumentException $e) {
            return new WP_Error('firmabind_ico', 'IČO musí obsahovať presne 8 číslic.', ['status'=>422]);
        } catch (Throwable $e) {
            return new WP_Error('firmabind_unavailable', 'Overenie je dočasne nedostupné. Údaje môžete vyplniť ručne.', ['status'=>503]);
        }
    }

    /** Construct, never prune, the public response. No arbitrary nested values can pass. */
    public static function public_card(array $input): array {
        $card = [];
        $fields = ['ico','name','street','postal_code','city','dic','vat_id'];
        foreach ($fields as $key) {
            $card[$key] = is_scalar($input[$key] ?? null) ? sanitize_text_field((string)$input[$key]) : '';
        }
        $card['vat_status'] = ($input['vat_status'] ?? '') === 'in_registry' ? 'in_registry' : 'not_in_registry';
        $card['availability'] = in_array($input['availability'] ?? '', ['found','not_found','unavailable'], true) ? $input['availability'] : 'unavailable';
        $card['retrieved_at'] = is_string($input['retrieved_at'] ?? null) ? sanitize_text_field($input['retrieved_at']) : null;
        $card['stale'] = !empty($input['stale']);
        $card['sources'] = [];
        foreach ($fields as $key) {
            $entry = $input['sources'][$key] ?? null;
            if (!is_array($entry)) { continue; }
            $safe = [];
            foreach (['source','source_record_id','retrieved_at','source_updated_at','valid_as_of','availability_status','match_method','kind'] as $attr) {
                if (is_scalar($entry[$attr] ?? null)) { $safe[$attr] = sanitize_text_field((string)$entry[$attr]); }
            }
            if (is_string($entry['source_url'] ?? null)) { $safe['source_url'] = self::source_url($entry['source_url']); }
            $card['sources'][$key] = $safe;
        }
        if ($card['vat_status'] !== 'in_registry') { $card['vat_id'] = ''; }
        return $card;
    }

    private static function source_url(string $url): string {
        $parts = parse_url($url);
        $host = strtolower((string)($parts['host'] ?? ''));
        $official = in_array($host,['api.statistics.sk','rpo.statistics.sk','www.orsr.sk','orsr.sk','sluzby.orsr.sk','www.registeruz.sk','registeruz.sk'],true)
            || $host === 'financnasprava.sk' || str_ends_with($host,'.financnasprava.sk');
        if (($parts['scheme'] ?? '') !== 'https' || isset($parts['user']) || isset($parts['pass']) || !$official) { return ''; }
        $query = [];
        parse_str($parts['query'] ?? '', $original);
        foreach (['id','ID','SID','P','ico','ICO','identifier','page','column','search','showHistoricalData','zmenene-od'] as $key) {
            if (is_scalar($original[$key] ?? null)) { $query[$key] = (string)$original[$key]; }
        }
        return esc_url_raw('https://'.$host.($parts['path'] ?? '/').($query ? '?'.http_build_query($query) : ''), ['https']);
    }

    public static function snapshot($request) {
        $id = (int)$request->get_param('id');
        $row = Vorkei_FirmaBind_Snapshots::get($id);
        if (!$row) { return new WP_Error('firmabind_snapshot_missing','Snímka neexistuje.',['status'=>404]); }
        $response = new WP_REST_Response($row,200);
        $response->header('Cache-Control','no-store, private');
        $response->header('Content-Disposition','attachment; filename="firmabind-snapshot-'.$id.'.json"');
        return $response;
    }
}
