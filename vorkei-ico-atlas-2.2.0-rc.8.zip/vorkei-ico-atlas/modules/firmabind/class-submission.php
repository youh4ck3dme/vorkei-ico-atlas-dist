<?php
if (!defined('ABSPATH')) { exit; }

/** One trusted submission path for all form adapters. Browser verification data is ignored. */
final class Vorkei_FirmaBind_Submission {
    public static function process(array $input, array $context): array {
        if (isset($input['ico']) && !is_string($input['ico'])) {
            throw new InvalidArgumentException('IČO musí byť textový reťazec s ôsmimi číslicami.');
        }
        $customer = [];
        foreach (['ico','name','street','postal_code','city','dic','ic_dph','country'] as $key) {
            $value = $input[$key] ?? '';
            $customer[$key] = is_scalar($value) ? trim($key === 'ico' ? (string)$value : sanitize_text_field((string)$value)) : '';
        }
        // Never pad, coerce to an integer or silently remove embedded characters.
        if ($customer['ico'] === '') {
            return ['consumer'=>true, 'snapshot_id'=>0, 'snapshot'=>null, 'effective'=>$customer];
        }
        if (!preg_match('/^[0-9]{8}$/D', $customer['ico'])) {
            throw new InvalidArgumentException('Vyplnené slovenské IČO musí obsahovať presne 8 číslic.');
        }
        if (!in_array($context['kind'] ?? '', ['classic','blocks','jetform'], true) || empty($context['idempotency_key'])) {
            throw new InvalidArgumentException('Chýba serverový kontext podania.');
        }
        // Read only the separate identity service. No full-profile API, lock or financial queue.
        $budget = Vorkei_FirmaBind_REST::budget();
        $limited = is_wp_error($budget);
        $registry = Vorkei_FirmaBind_REST::public_card($limited ? [
            'ico'=>$customer['ico'], 'availability'=>'unavailable', 'vat_status'=>'not_in_registry',
        ] : Vorkei_FirmaBind_Identity::get($customer['ico']));
        $customerVat = $customer['ic_dph'];
        $vies = $limited ? ['status'=>'not_checked','vat_id'=>$customerVat,'checked_at'=>null,'name'=>'','address'=>'','source_url'=>Vorkei_FirmaBind_Vies::URL,'reason'=>'rate_limited'] : Vorkei_FirmaBind_Vies::check($customerVat);
        $binding = Vorkei_FirmaBind_Vies::binding($registry, $vies, $customerVat);
        $effective = $customer;
        $differences = [];
        $compared = [];
        $selection = array_fill_keys(array_keys($customer), 'customer');
        foreach (['name','street','postal_code','city','dic'] as $field) {
            $source = $registry[$field];
            if ($source === '' || $registry['availability'] !== 'found') { continue; }
            if ($customer[$field] !== '') { $compared[] = $field; }
            if ($customer[$field] !== '' && self::compare($customer[$field]) !== self::compare($source)) {
                $differences[$field] = ['customer'=>$customer[$field], 'registry'=>$source];
            }
            $fresh = !$registry['stale'] && ($registry['sources'][$field]['availability_status'] ?? '') === 'observed';
            // A last-known identity during an outage is evidence, not authority to replace
            // a newly entered address. It may still fill an otherwise empty field.
            if ($fresh || $customer[$field] === '') {
                $effective[$field] = $source;
                $selection[$field] = $fresh ? 'registry' : 'stale_registry_fallback';
            }
        }
        if ($customer['ic_dph'] !== '' && $registry['vat_id'] !== '' &&
            self::vat($customer['ic_dph']) !== self::vat($registry['vat_id'])) {
            $differences['ic_dph'] = ['customer'=>$customer['ic_dph'], 'registry'=>$registry['vat_id']];
        }
        if ($customer['ic_dph'] !== '' && $registry['vat_id'] !== '') { $compared[] = 'ic_dph'; }
        $snapshot = [
            'schema_version'=>'firmabind/1.0',
            'ico'=>$customer['ico'],
            'registry'=>$registry,
            'customer'=>$customer,
            'effective'=>$effective,
            'selection'=>$selection,
            'checks'=>['identity'=>['status'=>$registry['availability'],'reason'=>$limited?'rate_limited':null], 'vies'=>$vies, 'binding'=>$binding],
            'comparison'=>['status'=>$differences ? 'diverged' : ($compared ? 'consistent' : 'not_compared'), 'compared_fields'=>$compared, 'differences'=>$differences],
            'identity_policy'=>'Aktuálne doložené serverové identitné údaje majú prednosť. Staršia evidencia neprepíše ručne zadané hodnoty; zákaznícke IČ DPH zostáva jeho tvrdením.',
        ];
        $stored = Vorkei_FirmaBind_Snapshots::insert($snapshot, $context);
        return array_merge($stored, [
            'consumer'=>false, 'registry'=>$registry, 'customer'=>$customer,
            'effective'=>$effective, 'diverged'=>(bool)$differences,
        ]);
    }

    private static function compare(string $value): string {
        $value = preg_replace('/\s+/u', ' ', trim($value));
        return function_exists('mb_strtolower') ? mb_strtolower($value, 'UTF-8') : strtolower($value);
    }
    private static function vat(string $value): string { return strtoupper(preg_replace('/\s+/', '', $value)); }
}
