<?php
if (!defined('ABSPATH')) { exit; }

/** Opt-in module. With the switch off none of its frontend code or data migrations run. */
final class Vorkei_FirmaBind {
    public static function register(): void {
        // Woo fires before_woocommerce_init on plugins_loaded:-1. This file is
        // loaded with the plugin, so the declaration is in time. Boot is not.
        add_action('before_woocommerce_init', [self::class,'declare_hpos_compatibility']);
        // The parent must exist before WordPress derives the submenu callback hook.
        add_action('admin_menu', [self::class,'menu'], 20);
        add_action('admin_init', [self::class,'settings']);
        add_action('plugins_loaded', [self::class,'boot'], 20);
    }
    public static function enabled(): bool { return get_option('vorkei_firmabind_enabled','no') === 'yes'; }
    /** Must run on before_woocommerce_init, and only while the module is enabled. */
    public static function declare_hpos_compatibility(): void {
        if (!self::enabled()) { return; }
        $features = '\Automattic\WooCommerce\Utilities\FeaturesUtil';
        if (class_exists($features)) {
            $features::declare_compatibility('custom_order_tables', VORKEI_ICO_ATLAS_PATH.'vorkei-ico-atlas.php', true);
        }
    }
    public static function boot(): void {
        if (!self::enabled()) { return; }
        foreach (['identity','vies','snapshots','rest','submission','adapters'] as $file) {
            require_once __DIR__ . '/class-' . $file . '.php';
        }
        add_action('init', [self::class,'upgrade'], 5);
        add_action('rest_api_init', [Vorkei_FirmaBind_REST::class,'register']);
        add_action('vorkei_firmabind_profile_saved', [Vorkei_FirmaBind_Identity::class,'observe_profile']);
        Vorkei_FirmaBind_Adapters::register();
    }
    public static function upgrade(): void {
        try {
            Vorkei_FirmaBind_Snapshots::install();
            Vorkei_FirmaBind_REST::install();
            delete_option('vorkei_firmabind_migration_error');
        } catch (Throwable $e) {
            // Checkout must never claim an audit was saved if storage is unavailable.
            update_option('vorkei_firmabind_migration_error','Snímky FirmaBind nie sú pripravené. Skontrolujte databázu na skúšobnom webe.',false);
        }
    }
    public static function menu(): void {
        add_submenu_page('vorkei-ico-atlas','FirmaBind 2.2 — skúšobná verzia','FirmaBind 2.2','manage_options','vorkei-firmabind',[self::class,'page']);
    }
    public static function settings(): void {
        register_setting('vorkei_firmabind','vorkei_firmabind_enabled',[
            'type'=>'string','default'=>'no','sanitize_callback'=>static fn($v)=>$v === 'yes' ? 'yes':'no',
        ]);
        register_setting('vorkei_firmabind','vorkei_firmabind_ip_limit',[
            'type'=>'integer','default'=>12,'sanitize_callback'=>static fn($v)=>max(1,min(120,(int)$v)),
        ]);
        register_setting('vorkei_firmabind','vorkei_firmabind_daily_limit',[
            'type'=>'integer','default'=>1000,'sanitize_callback'=>static fn($v)=>max(1,min(100000,(int)$v)),
        ]);
        register_setting('vorkei_firmabind','vorkei_firmabind_jetform_mappings',[
            'type'=>'array','default'=>[],'sanitize_callback'=>[self::class,'sanitize_mappings'],
        ]);
    }
    public static function sanitize_mappings($raw): array {
        if (is_string($raw)) { $raw = json_decode($raw,true); }
        if (!is_array($raw)) {
            add_settings_error('vorkei_firmabind','mapping','Mapovanie musí byť platný objekt JSON. Pôvodné mapovanie zostalo zachované.');
            return (array)get_option('vorkei_firmabind_jetform_mappings',[]);
        }
        $out = [];
        foreach ($raw as $id=>$mapping) {
            if (!ctype_digit((string)$id) || (int)$id<1 || !is_array($mapping)) { continue; }
            foreach (['ico','name','street','postal_code','city','dic','ic_dph','country'] as $field) {
                if (isset($mapping[$field]) && is_string($mapping[$field]) && preg_match('/^[a-zA-Z][a-zA-Z0-9_-]{0,127}$/D',$mapping[$field])) {
                    $out[(int)$id][$field] = $mapping[$field];
                }
            }
            if (empty($out[(int)$id]['ico']) || count(array_unique($out[(int)$id])) !== count($out[(int)$id])) { unset($out[(int)$id]); }
        }
        return $out;
    }
    public static function page(): void {
        if (!current_user_can('manage_options')) { return; }
        echo '<div class="wrap"><h1>FirmaBind 2.2 — skúšobná verzia</h1>';
        echo '<p>Predvolene vypnutý modul pre identitu firmy a nemennú snímku podania. Pred použitím na predajnom webe overte klasickú objednávku, blokovú objednávku a podanie JetFormBuilder s HPOS.</p>';
        if ($error = get_option('vorkei_firmabind_migration_error')) {
            echo '<div class="notice notice-error"><p>'.esc_html($error).'</p></div>';
        }
        echo '<form method="post" action="options.php">';
        settings_fields('vorkei_firmabind');
        echo '<input type="hidden" name="vorkei_firmabind_enabled" value="no">';
        echo '<p><label><input type="checkbox" name="vorkei_firmabind_enabled" value="yes" '.checked(self::enabled(),true,false).'> Zapnúť FirmaBind na tomto webe</label></p>';
        echo '<p><label>Počet kontrol na jednu IP za minútu <input type="number" min="1" max="120" name="vorkei_firmabind_ip_limit" value="'.esc_attr((string)get_option('vorkei_firmabind_ip_limit',12)).'"></label></p>';
        echo '<p><label>Denný strop webu <input type="number" min="1" max="100000" name="vorkei_firmabind_daily_limit" value="'.esc_attr((string)get_option('vorkei_firmabind_daily_limit',1000)).'"></label></p>';
        echo '<p>Limity chránia verejnú kartu aj serverové kontroly podaní. Po ich dosiahnutí môže zákazník pokračovať s ručnými údajmi a neoverenou snímkou.</p>';
        echo '<h2>JetFormBuilder</h2><p>Zapojenie je výslovné: nastavte mapovanie podľa ID formulára a pridajte akciu Call Hook s názvom <code>vorkei_firmabind</code> pred odoslanie alebo uloženie ďalších akcií. Príklad mapovania: <code>{"123":{"ico":"firma_ico","name":"firma_nazov","street":"ulica","postal_code":"psc","city":"mesto","dic":"dic","ic_dph":"ic_dph"}}</code>.</p>';
        echo '<textarea name="vorkei_firmabind_jetform_mappings" rows="8" cols="90" aria-label="Mapovanie JetFormBuilder">'.esc_textarea(wp_json_encode(get_option('vorkei_firmabind_jetform_mappings',[]),JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)).'</textarea>';
        submit_button('Uložiť nastavenia');
        echo '</form><h2>Export snímky</h2><p>Administrátor môže stiahnuť úplný JSON cez <code>/wp-json/vorkei-firmabind/v1/snapshots/ID</code> s prihlásením a REST nonce. ID snímky sa uloží k objednávke alebo k výsledku JetForm akcie. Záznam obsahuje zdroje, údaje zákazníka, výsledky kontrol aj kontrolný odtlačok.</p></div>';
    }
}
Vorkei_FirmaBind::register();
