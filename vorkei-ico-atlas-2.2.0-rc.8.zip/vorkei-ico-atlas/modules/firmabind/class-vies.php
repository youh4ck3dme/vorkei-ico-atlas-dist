<?php
if (!defined('ABSPATH')) {exit;}

/** VIES validity and the separate proof of a VAT-to-IČO relationship. */
class Vorkei_FirmaBind_Vies {
 const URL='https://ec.europa.eu/taxation_customs/vies/services/checkVatService';
 const NS='urn:ec.europa.eu:taxud:vies:services:checkVat:types';

 public static function check(string $vat_id): array {
  $vat_id=self::normalize($vat_id);$out=self::result($vat_id,'not_checked');
  if(!self::supported($vat_id)) {return $out;}
  $key='vorkei_firmabind_vies_'.hash('sha256',$vat_id);$cached=get_transient($key);
  if(is_array($cached)&&($cached['vat_id']??null)===$vat_id&&in_array($cached['status']??'',['valid','invalid','unavailable'],true)&&($cached['source_url']??'')===self::URL) {
   $at=is_string($cached['checked_at']??null)?strtotime($cached['checked_at']):false;
   $life=$cached['status']==='unavailable'?30:($cached['status']==='invalid'?300:3600);
   if($at!==false&&$at>=time()-$life&&$at<=time()+60&&gmdate('Y-m-d',$at)===gmdate('Y-m-d')) {
    $safe=array_replace($out,array_intersect_key($cached,$out));foreach(['name','address'] as $field) {if(!is_string($safe[$field])) {$safe[$field]='';}}return $safe;
   }
  }
  $country=substr($vat_id,0,2);$number=substr($vat_id,2);
  $xml='<?xml version="1.0" encoding="UTF-8"?><soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"><soap:Body><checkVat xmlns="'.self::NS.'"><countryCode>'.$country.'</countryCode><vatNumber>'.$number.'</vatNumber></checkVat></soap:Body></soap:Envelope>';
  $r=wp_safe_remote_post(self::URL,['timeout'=>3,'redirection'=>0,'sslverify'=>true,'limit_response_size'=>65536,'headers'=>['Content-Type'=>'text/xml; charset=utf-8','Accept'=>'text/xml','SOAPAction'=>'""'],'body'=>$xml]);
  $out=self::result($vat_id,'unavailable');$out['checked_at']=gmdate('c');
  if(!is_wp_error($r)&&(int)wp_remote_retrieve_response_code($r)===200) {
   $parsed=self::parse(wp_remote_retrieve_body($r),$country,$number);
   if($parsed!==null) {$out['status']=$parsed['valid']?'valid':'invalid';$out['name']=$parsed['name'];$out['address']=$parsed['address'];}
  }
  $untilMidnight=max(1,86400-(time()%86400));$ttl=$out['status']==='unavailable'?30:($out['status']==='invalid'?300:3600);
  set_transient($key,$out,min($ttl,$untilMidnight));return $out;
 }

 public static function binding(array $identity,array $check,string $customerVat): array {
  $customerVat=self::normalize($customerVat);$known=self::normalize((string)($identity['vat_id']??''));
  $proof=$identity['sources']['vat_id']??[];
  $evidence=['ico'=>(string)($identity['ico']??''),'customer_vat_id'=>$customerVat,'registry_vat_id'=>$known,'vies'=>array_intersect_key($check,array_flip(['status','vat_id','checked_at','source_url']))];
  $out=['status'=>'withheld','reason'=>'Presná väzba IČO a IČ DPH nebola doložená.','evidence'=>$evidence];
  if($customerVat==='') {$out['reason']='Zákazník IČ DPH nevyplnil. Registerové číslo sa za jeho tvrdenie nepovažuje.';return $out;}
  if(($identity['availability']??'')!=='found'||!empty($identity['stale'])) {$out['reason']='Identita firmy nie je aktuálne potvrdená.';return $out;}
  $checked=is_string($check['checked_at']??null)?strtotime($check['checked_at']):false;
  $freshCheck=$checked!==false&&$checked>=time()-3600&&$checked<=time()+60&&gmdate('Y-m-d',$checked)===gmdate('Y-m-d');
  if(!self::supported($customerVat)||($check['status']??'')!=='valid'||($check['source_url']??'')!==self::URL||!$freshCheck||self::normalize((string)($check['vat_id']??''))!==$customerVat) {$out['reason']='VIES nepotvrdil platnosť presne zadaného IČ DPH.';return $out;}
  $host=strtolower((string)parse_url($proof['source_url']??'',PHP_URL_HOST));$at=is_string($proof['retrieved_at']??null)?strtotime($proof['retrieved_at']):false;
  $official=parse_url($proof['source_url']??'',PHP_URL_SCHEME)==='https'&&($host==='financnasprava.sk'||str_ends_with($host,'.financnasprava.sk'));
  $exact=$official&&($proof['availability_status']??'')==='observed'&&($proof['match_method']??'')==='exact_ico'&&preg_match('/^[0-9]{8}$/D',(string)($identity['ico']??''))&&$at!==false&&$at>=time()-3600&&$at<=time()+60;
  if(!$exact||$known==='') {return $out;}
  $out['evidence']['registry']=array_intersect_key($proof,array_flip(['source','source_url','source_record_id','retrieved_at','availability_status','match_method','kind']));
  if($known===$customerVat) {$out['status']='matched';$out['reason']='Oficiálny záznam FS spája presné IČO s týmto IČ DPH; VIES potvrdil jeho platnosť.';}
  else {$out['status']='mismatch';$out['reason']='Oficiálny záznam FS pri tomto IČO uvádza odlišné IČ DPH.';}
  // Names, including "---", never establish this relationship by themselves.
  return $out;
 }

 private static function parse($xml,string $country,string $number): ?array {
  if(!is_string($xml)||trim($xml)===''||strlen($xml)>65536||preg_match('/<!DOCTYPE|<!ENTITY/i',$xml)||!class_exists('DOMDocument')) {return null;}
  $dom=new DOMDocument();$old=libxml_use_internal_errors(true);$ok=$dom->loadXML($xml,LIBXML_NONET|LIBXML_NOERROR|LIBXML_NOWARNING);libxml_clear_errors();libxml_use_internal_errors($old);if(!$ok) {return null;}
  $xp=new DOMXPath($dom);$xp->registerNamespace('s','http://schemas.xmlsoap.org/soap/envelope/');$xp->registerNamespace('t',self::NS);
  $rows=$xp->query('/s:Envelope/s:Body/t:checkVatResponse');if($rows->length!==1) {return null;}$row=$rows->item(0);$values=[];
  foreach(['countryCode','vatNumber','valid','name','address'] as $field) {
   $nodes=$xp->query('./t:'.$field,$row);
   if($nodes->length>1||($nodes->length!==1&&in_array($field,['countryCode','vatNumber','valid'],true))) {return null;}
   $values[$field]=$nodes->length?trim($nodes->item(0)->textContent):'';
  }
  if($values['countryCode']!==$country||$values['vatNumber']!==$number||!in_array($values['valid'],['true','false','1','0'],true)) {return null;}
  return ['valid'=>in_array($values['valid'],['true','1'],true),'name'=>$values['name'],'address'=>$values['address']];
 }
 private static function normalize(string $s): string {$value=preg_replace('/\s+/u','',trim($s));return $value===null?'':strtoupper($value);}
 private static function supported(string $s): bool {
  if(substr($s,0,2)==='SK') {return (bool)preg_match('/^SK[0-9]{10}$/D',$s);}
  return preg_match('/^[A-Z]{2}[A-Z0-9]{2,12}$/D',$s)&&in_array(substr($s,0,2),['AT','BE','BG','CY','CZ','DE','DK','EE','EL','ES','FI','FR','HR','HU','IE','IT','LT','LU','LV','MT','NL','PL','PT','RO','SE','SI','XI'],true);
 }
 private static function result(string $vat,string $status): array {return ['status'=>$status,'checked_at'=>null,'vat_id'=>$vat,'name'=>'','address'=>'','source_url'=>self::URL];}
}
