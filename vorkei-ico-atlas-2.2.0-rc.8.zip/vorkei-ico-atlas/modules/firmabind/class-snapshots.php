<?php
/** Immutable server-side evidence captured when a company submission is accepted. */
if (!defined('ABSPATH')) { exit; }

final class Vorkei_FirmaBind_Snapshots {
    private const SCHEMA_VERSION = '1.1';
    private const VERSION_OPTION = 'vorkei_firmabind_snapshot_schema';

    /** Additive migration, called by the enabled module, never by public lookup. */
    public static function install(): void {
        if (get_option(self::VERSION_OPTION) === self::SCHEMA_VERSION) { return; }
        global $wpdb;
        $table = self::table();
        $collate = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE {$table} (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            snapshot_uuid CHAR(36) NOT NULL,
            ico VARCHAR(8) NOT NULL,
            kind VARCHAR(16) NOT NULL,
            order_id BIGINT(20) UNSIGNED NULL,
            form_id BIGINT(20) UNSIGNED NULL,
            submission_id VARCHAR(191) NULL,
            idempotency_key CHAR(64) NOT NULL,
            payload_json LONGTEXT NOT NULL,
            payload_hash CHAR(64) NOT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY snapshot_uuid (snapshot_uuid),
            UNIQUE KEY idempotency_key (idempotency_key),
            UNIQUE KEY order_id (order_id),
            KEY ico_created (ico,created_at)
        ) {$collate};";
        if (!function_exists('dbDelta')) { require_once ABSPATH . 'wp-admin/includes/upgrade.php'; }
        dbDelta($sql);
        $columns = (array) $wpdb->get_col("DESCRIBE {$table}");
        $required = ['id','snapshot_uuid','ico','kind','order_id','form_id','submission_id','idempotency_key','payload_json','payload_hash','created_at'];
        if (array_diff($required, $columns)) {
            throw new RuntimeException('FirmaBind: tabuľku snímok sa nepodarilo pripraviť.');
        }
        $unique = [];
        foreach ((array) $wpdb->get_results("SHOW INDEX FROM {$table}", ARRAY_A) as $index) {
            if ((int) ($index['Non_unique'] ?? 1) === 0) {
                $unique[(string) $index['Key_name']][(int) $index['Seq_in_index']] = (string) $index['Column_name'];
            }
        }
        foreach (['PRIMARY'=>'id', 'snapshot_uuid'=>'snapshot_uuid', 'idempotency_key'=>'idempotency_key', 'order_id'=>'order_id'] as $key=>$field) {
            if (($unique[$key] ?? []) !== [1 => $field]) {
                throw new RuntimeException('FirmaBind: chýba ochrana jedinečnosti snímok.');
            }
        }
        update_option(self::VERSION_OPTION, self::SCHEMA_VERSION, false);
    }

    /**
     * Only trusted server code supplies context. Browser snapshot IDs are never accepted.
     * The idempotency key denotes one checkout attempt/submission, not a customer or IČO.
     * @return array{snapshot_id:int,snapshot:array,payload_hash:string,created_at:string}
     */
    public static function insert(array $payload, array $context = []): array {
        global $wpdb;
        $ico = (string) ($payload['ico'] ?? $payload['registry']['ico'] ?? $payload['customer']['ico'] ?? '');
        if (!preg_match('/^[0-9]{8}$/D', $ico)) {
            throw new InvalidArgumentException('FirmaBind: snímka vyžaduje osemmiestne IČO.');
        }
        $kind = (string) ($context['kind'] ?? 'jetform');
        if (!in_array($kind, ['classic','blocks','jetform'], true)) {
            throw new InvalidArgumentException('FirmaBind: neznámy druh podania.');
        }
        $orderId = self::optional_id($context['order_id'] ?? null);
        $formId = self::optional_id($context['form_id'] ?? null);
        $submissionId = isset($context['submission_id']) && $context['submission_id'] !== '' ? (string) $context['submission_id'] : null;
        if ($submissionId !== null && (strlen($submissionId) > 191 || preg_match('/[\x00-\x1F\x7F]/', $submissionId))) {
            throw new InvalidArgumentException('FirmaBind: neplatný identifikátor podania.');
        }
        $key = isset($context['idempotency_key']) && $context['idempotency_key'] !== '' ? (string) $context['idempotency_key'] : self::uuid();
        if (strlen($key) > 1024) { throw new InvalidArgumentException('FirmaBind: príliš dlhý kľúč podania.'); }
        $keyHash = hash('sha256', $kind . "\0" . $key);
        $json = self::encode($payload);
        if (strlen($json) > 262144) { throw new InvalidArgumentException('FirmaBind: snímka prekročila limit veľkosti.'); }
        $hash = hash('sha256', $json);
        $existing = self::by_key($keyHash);
        if ($existing) { return self::repeated($existing, $hash, $kind, $orderId, $formId, $submissionId); }
        $createdAt = gmdate('Y-m-d H:i:s');
        $row = [
            'snapshot_uuid' => self::uuid(), 'ico' => $ico, 'kind' => $kind,
            'order_id' => $orderId, 'form_id' => $formId, 'submission_id' => $submissionId,
            'idempotency_key' => $keyHash, 'payload_json' => $json, 'payload_hash' => $hash,
            'created_at' => $createdAt,
        ];
        $result = $wpdb->insert(self::table(), $row, ['%s','%s','%s','%d','%d','%s','%s','%s','%s','%s']);
        if ($result === false) {
            // Another request may have inserted the same attempt in between SELECT and INSERT.
            $existing = self::by_key($keyHash);
            if ($existing) { return self::repeated($existing, $hash, $kind, $orderId, $formId, $submissionId); }
            throw new RuntimeException('FirmaBind: snímku sa nepodarilo bezpečne uložiť.');
        }
        $row['id'] = (int) $wpdb->insert_id;
        if ($row['id'] < 1) { throw new RuntimeException('FirmaBind: chýba identifikátor uloženej snímky.'); }
        return self::decode($row);
    }

    public static function get(int $id): ?array {
        if ($id < 1) { return null; }
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . self::table() . ' WHERE id = %d', $id), ARRAY_A);
        return is_array($row) ? self::decode($row) : null;
    }

    /** The sole allowed UPDATE: attach a previously unknown order ID exactly once. */
    public static function bind_order(int $snapshotId, int $orderId): bool {
        if ($snapshotId < 1 || $orderId < 1) { return false; }
        $row = self::get($snapshotId);
        if (!$row) { return false; }
        if ($row['order_id'] !== null) { return $row['order_id'] === $orderId; }
        global $wpdb;
        $updated = $wpdb->query($wpdb->prepare(
            'UPDATE ' . self::table() . ' SET order_id = %d WHERE id = %d AND order_id IS NULL',
            $orderId, $snapshotId
        ));
        if ($updated === 1) { return true; }
        // Concurrent repeat of the same binding is idempotent; another order is rejected.
        $after = self::get($snapshotId);
        return $after !== null && $after['order_id'] === $orderId;
    }

    /** Full evidence export; caller must enforce administrator/order access. */
    public static function export(int $id): string {
        $row = self::get($id);
        if (!$row) { throw new OutOfBoundsException('FirmaBind: snímka neexistuje.'); }
        return json_encode($row, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRESERVE_ZERO_FRACTION | JSON_THROW_ON_ERROR);
    }

    private static function table(): string {
        global $wpdb;
        return $wpdb->prefix . 'vorkei_firmabind_snapshots';
    }

    private static function optional_id($value): ?int {
        if ($value === null || $value === '' || $value === 0 || $value === '0') { return null; }
        if (!is_scalar($value) || !preg_match('/^[1-9][0-9]*$/D', (string) $value) || (float) $value > PHP_INT_MAX) {
            throw new InvalidArgumentException('FirmaBind: neplatný serverový identifikátor.');
        }
        return (int) $value;
    }

    private static function by_key(string $key): ?array {
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . self::table() . ' WHERE idempotency_key = %s', $key), ARRAY_A);
        return is_array($row) ? $row : null;
    }

    private static function repeated(array $row, string $hash, string $kind, ?int $orderId, ?int $formId, ?string $submissionId): array {
        if (!hash_equals((string) $row['payload_hash'], $hash)
            || $row['kind'] !== $kind
            || ($row['form_id'] === null ? null : (int) $row['form_id']) !== $formId
            || ($row['submission_id'] ?? null) !== $submissionId
            || ($orderId !== null && $row['order_id'] !== null && (int) $row['order_id'] !== $orderId)) {
            throw new RuntimeException('FirmaBind: rovnaký pokus už má inú nemennú snímku.');
        }
        return self::decode($row);
    }

    private static function decode(array $row): array {
        $json = (string) $row['payload_json'];
        if (!hash_equals((string) $row['payload_hash'], hash('sha256', $json))) {
            throw new RuntimeException('FirmaBind: kontrolný odtlačok snímky nesúhlasí.');
        }
        $payload = json_decode($json, true, 512, JSON_THROW_ON_ERROR);
        if (!is_array($payload)) { throw new RuntimeException('FirmaBind: neplatná uložená snímka.'); }
        return [
            'snapshot_id' => (int) $row['id'], 'snapshot_uuid' => (string) $row['snapshot_uuid'],
            'snapshot' => $payload, 'payload_hash' => (string) $row['payload_hash'],
            'created_at' => str_replace(' ', 'T', (string) $row['created_at']) . 'Z',
            'ico' => (string) $row['ico'], 'kind' => (string) $row['kind'],
            'order_id' => $row['order_id'] === null ? null : (int) $row['order_id'],
            'form_id' => $row['form_id'] === null ? null : (int) $row['form_id'],
            'submission_id' => $row['submission_id'] ?? null,
        ];
    }

    private static function encode(array $payload): string {
        return json_encode(self::canonical($payload), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRESERVE_ZERO_FRACTION | JSON_THROW_ON_ERROR);
    }

    private static function canonical($value) {
        if (is_array($value)) {
            $list = array_is_list($value);
            foreach ($value as $key => $child) { $value[$key] = self::canonical($child); }
            if (!$list) { ksort($value, SORT_STRING); }
        } elseif (is_object($value) || is_resource($value)) {
            throw new InvalidArgumentException('FirmaBind: snímka môže obsahovať iba dátové hodnoty.');
        }
        return $value;
    }

    private static function uuid(): string {
        if (function_exists('wp_generate_uuid4')) { return wp_generate_uuid4(); }
        $bytes = random_bytes(16);
        $bytes[6] = chr((ord($bytes[6]) & 0x0f) | 0x40);
        $bytes[8] = chr((ord($bytes[8]) & 0x3f) | 0x80);
        $hex = bin2hex($bytes);
        return substr($hex, 0, 8) . '-' . substr($hex, 8, 4) . '-' . substr($hex, 12, 4) . '-' . substr($hex, 16, 4) . '-' . substr($hex, 20);
    }
}
