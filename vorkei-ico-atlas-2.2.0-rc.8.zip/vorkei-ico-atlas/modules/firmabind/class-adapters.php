<?php
/** Thin form integrations. All accepted evidence is created by Submission::process(). */
if (!defined('ABSPATH')) { exit; }

final class Vorkei_FirmaBind_Adapters {
    private static bool $registered = false;
    private static ?WeakMap $jetResults = null;
    private static ?WeakMap $blocksPending = null;
    private const BLOCK_FIELDS = ['ico'=>'vorkei-firmabind/ico', 'dic'=>'vorkei-firmabind/dic', 'ic_dph'=>'vorkei-firmabind/ic-dph'];

    public static function register(): void {
        if (self::$registered) { return; }
        self::$registered = true;
        add_action('wp_enqueue_scripts', [self::class,'enqueue']);
        if (class_exists('WooCommerce') || function_exists('WC')) {
            add_filter('woocommerce_checkout_fields', [self::class,'classic_fields']);
            add_action('woocommerce_after_checkout_validation', [self::class,'classic_validate'], 10, 2);
            add_action('woocommerce_checkout_create_order', [self::class,'classic_create'], 20, 2);
            add_action('woocommerce_checkout_order_created', [self::class,'bind_order'], 20);
            // Register against Woo's init lifecycle, with a late-enable fallback.
            if (did_action('woocommerce_init')) { self::blocks_fields(); }
            else { add_action('woocommerce_init', [self::class,'blocks_fields']); }
            add_action('woocommerce_store_api_checkout_update_order_from_request', [self::class,'blocks_update'], 30, 2);
            add_action('woocommerce_store_api_checkout_order_processed', [self::class,'blocks_processed'], 30);
            add_filter('render_block_woocommerce/checkout', [self::class,'blocks_retry_markup']);
        }
        // Opt-in: only a form with the named Call Hook action invokes this callback.
        add_action('jet-form-builder/custom-action/vorkei_firmabind', [self::class,'jetform'], 10, 2);
    }

    public static function declare_hpos_compatibility(): void {
        $features = '\Automattic\WooCommerce\Utilities\FeaturesUtil';
        if (class_exists($features)) {
            $features::declare_compatibility('custom_order_tables', VORKEI_ICO_ATLAS_PATH.'vorkei-ico-atlas.php', true);
        }
    }

    /** Plugin-owned sibling outside Woo's React root; never edit React-managed fields. */
    public static function blocks_retry_markup(string $content): string {
        return $content . '<div data-vorkei-firmabind-block-status hidden><p data-vorkei-firmabind-block-message role="status" aria-live="polite"></p><button type="button" class="button" data-vorkei-firmabind-block-retry>Zopakovať overenie</button></div>';
    }

    public static function classic_fields(array $fields): array {
        foreach (['ico'=>'IČO', 'dic'=>'DIČ', 'ic_dph'=>'IČ DPH'] as $key=>$label) {
            $fields['billing']['billing_vorkei_'.$key] = [
                'type'=>'text', 'label'=>$label, 'required'=>false,
                'class'=>['form-row-wide'], 'priority'=>35 + array_search($key, ['ico','dic','ic_dph'], true),
                'custom_attributes'=>$key === 'ico' ? ['inputmode'=>'numeric','maxlength'=>'8','autocomplete'=>'off'] : [],
            ];
        }
        return $fields;
    }

    public static function classic_validate(array $data, $errors): void {
        $ico = self::ico($data['billing_vorkei_ico'] ?? '');
        if ($ico !== '' && !preg_match('/^[0-9]{8}$/D', $ico)) {
            $errors->add('vorkei_firmabind_ico', 'IČO musí obsahovať presne 8 číslic.');
        }
    }

    public static function classic_create($order, array $data): void {
        if (self::restore_existing($order)) { return; }
        $customer = [
            'ico'=>self::ico($data['billing_vorkei_ico'] ?? ''),
            'dic'=>self::scalar($data['billing_vorkei_dic'] ?? ''),
            'ic_dph'=>self::scalar($data['billing_vorkei_ic_dph'] ?? ''),
            'name'=>self::scalar($data['billing_company'] ?? ''),
            'street'=>self::scalar($data['billing_address_1'] ?? ''),
            'postal_code'=>self::scalar($data['billing_postcode'] ?? ''),
            'city'=>self::scalar($data['billing_city'] ?? ''),
            'country'=>self::scalar($data['billing_country'] ?? ''),
        ];
        self::accept_order($order, $customer, 'classic');
    }

    public static function blocks_fields(): void {
        if (!function_exists('woocommerce_register_additional_checkout_field')) { return; }
        foreach (['ico'=>'IČO', 'dic'=>'DIČ', 'ic_dph'=>'IČ DPH'] as $key=>$label) {
            $args = ['id'=>self::BLOCK_FIELDS[$key], 'label'=>$label, 'location'=>'order', 'type'=>'text', 'required'=>false];
            $args['sanitize_callback'] = static fn($value)=>$key === 'ico' ? self::ico($value) : self::scalar($value);
            if ($key === 'ico') {
                $args['attributes'] = ['maxLength'=>'8','autocomplete'=>'off','pattern'=>'[0-9]{8}'];
                $args['validate_callback'] = static function($value) {
                    $ico = self::ico($value);
                    return $ico === '' || preg_match('/^[0-9]{8}$/D', $ico)
                        ? null : new WP_Error('vorkei_firmabind_ico', 'IČO musí obsahovať presne 8 číslic.');
                };
            }
            woocommerce_register_additional_checkout_field($args);
        }
    }

    /** PUT/PATCH are live field updates, not accepted submissions. Never snapshot those. */
    public static function blocks_update($order, $request): void {
        if (!is_object($request) || !method_exists($request,'get_method') || strtoupper($request->get_method()) !== 'POST') { return; }
        $fields = $request->get_param('additional_fields');
        $fields = is_array($fields) ? $fields : [];
        $customer = self::billing_customer($order);
        foreach (self::BLOCK_FIELDS as $key=>$id) {
            // The current POST is authoritative, including an explicitly blank IČO.
            $customer[$key] = $key === 'ico' ? self::ico($fields[$id] ?? '') : self::scalar($fields[$id] ?? '');
        }
        if ($customer['ico'] !== '' && !preg_match('/^[0-9]{8}$/D', $customer['ico'])) {
            self::blocks_invalid('IČO musí obsahovať presne 8 číslic.');
        }
        // This hook precedes Woo's address/email validation. Capture only, then accept after it passes.
        self::$blocksPending ??= new WeakMap();
        self::$blocksPending[$order] = $customer;
    }

    public static function blocks_processed($order): void {
        if (self::restore_existing($order)) { $order->save(); return; }
        if (!self::$blocksPending || !isset(self::$blocksPending[$order])) { return; }
        $customer = self::$blocksPending[$order];
        unset(self::$blocksPending[$order]);
        try {
            self::accept_order($order, $customer, 'blocks');
            // order_processed fires after Woo's save point and before gateway invocation.
            $order->save();
        }
        catch (InvalidArgumentException $e) {
            self::blocks_invalid($e->getMessage());
        }
    }

    private static function blocks_invalid(string $message): void {
        $exception = '\Automattic\WooCommerce\StoreApi\Exceptions\RouteException';
        if (class_exists($exception)) { throw new $exception('vorkei_firmabind_ico', $message, 400); }
        throw new InvalidArgumentException($message);
    }

    private static function accept_order($order, array $customer, string $kind): void {
        $orderId = (int)$order->get_id();
        $orderKey = method_exists($order,'get_order_key') ? (string)$order->get_order_key() : '';
        // Woo generates order_key on the server. Never accept an idempotency key from POST.
        $key = $orderId > 0 ? 'order:'.$orderId : 'order-key:'.$orderKey;
        if ($orderKey === '' && $orderId < 1) { $key = 'attempt:'.wp_generate_uuid4(); }
        $result = Vorkei_FirmaBind_Submission::process($customer, ['kind'=>$kind,'order_id'=>$orderId ?: null,'idempotency_key'=>$key]);
        if (!empty($result['consumer'])) { return; }
        $snapshotId = (int) ($result['snapshot_id'] ?? 0);
        if ($snapshotId < 1) { throw new RuntimeException('FirmaBind: snímka nie je uložená.'); }
        if ($orderId > 0 && !Vorkei_FirmaBind_Snapshots::bind_order($snapshotId, $orderId)) {
            throw new RuntimeException('FirmaBind: snímku sa nepodarilo priradiť k objednávke.');
        }
        $effective = $result['effective'];
        self::apply_effective($order, $effective, $kind);
        $order->update_meta_data('_vorkei_firmabind_snapshot_id', $snapshotId);
        $order->update_meta_data('_vorkei_firmabind_snapshot_hash', (string)$result['payload_hash']);
        $order->update_meta_data('_vorkei_firmabind_snapshot', $result['snapshot']);
    }

    private static function apply_effective($order, array $effective, string $kind): void {
        // Only billing identity is populated. A registered office is never a shipping address.
        foreach (['name'=>'company','street'=>'address_1','postal_code'=>'postcode','city'=>'city','country'=>'country'] as $key=>$field) {
            if (($effective[$key] ?? '') !== '') { $order->{'set_billing_'.$field}($effective[$key]); }
        }
        foreach (['ico','dic','ic_dph'] as $key) { $order->update_meta_data('_billing_vorkei_'.$key, $effective[$key] ?? ''); }
        if ($kind === 'blocks') {
            $fieldsClass = '\Automattic\WooCommerce\Blocks\Domain\Services\CheckoutFields';
            $prefix = is_callable([$fieldsClass,'get_group_key']) ? $fieldsClass::get_group_key('other') : '_wc_other/';
            foreach (self::BLOCK_FIELDS as $key=>$id) { $order->update_meta_data($prefix.$id, $effective[$key] ?? ''); }
        }
    }

    /** An order's accepted snapshot is immutable, including on payment retries. */
    private static function restore_existing($order): bool {
        $id = (int)$order->get_meta('_vorkei_firmabind_snapshot_id', true);
        if ($id < 1) { return false; }
        $row = Vorkei_FirmaBind_Snapshots::get($id);
        $orderId = (int)$order->get_id();
        if (!$row || (!empty($row['order_id']) && (int)$row['order_id'] !== $orderId)) {
            throw new RuntimeException('FirmaBind: uloženú snímku objednávky sa nepodarilo overiť.');
        }
        if ($orderId > 0 && !Vorkei_FirmaBind_Snapshots::bind_order($id,$orderId)) {
            throw new RuntimeException('FirmaBind: snímka patrí inej objednávke.');
        }
        self::apply_effective($order, (array)($row['snapshot']['effective'] ?? []), (string)($row['kind'] ?? 'classic'));
        return true;
    }

    public static function bind_order($order): void {
        $id = (int)$order->get_meta('_vorkei_firmabind_snapshot_id', true);
        if ($id > 0 && !Vorkei_FirmaBind_Snapshots::bind_order($id, (int)$order->get_id())) {
            throw new RuntimeException('FirmaBind: snímku sa nepodarilo priradiť k objednávke.');
        }
    }

    private static function billing_customer($order): array {
        $out = [];
        foreach (['name'=>'company','street'=>'address_1','postal_code'=>'postcode','city'=>'city','country'=>'country'] as $key=>$field) {
            $out[$key] = self::scalar($order->{'get_billing_'.$field}());
        }
        return $out;
    }

    /** Canonical field => configured JetForm field name; no implicit forms are enabled. */
    public static function jetform_mappings(): array {
        $input = apply_filters('vorkei_firmabind_jetform_mappings', get_option('vorkei_firmabind_jetform_mappings', []));
        if (!is_array($input)) { return []; }
        $output = [];
        foreach ($input as $formId=>$mapping) {
            if (!ctype_digit((string)$formId) || (int)$formId < 1 || !is_array($mapping)) { continue; }
            $valid = [];
            foreach (['ico','name','street','postal_code','city','dic','ic_dph','country'] as $key) {
                $field = $mapping[$key] ?? '';
                if (is_string($field) && preg_match('/^[a-zA-Z][a-zA-Z0-9_-]{0,127}$/D',$field)) { $valid[$key] = $field; }
            }
            if (isset($valid['ico']) && count(array_unique($valid)) === count($valid)) { $output[(int)$formId] = $valid; }
        }
        return $output;
    }

    public static function jetform($request, $handler): void {
        $formId = is_object($handler) && method_exists($handler,'get_form_id') ? (int)$handler->get_form_id() : 0;
        $mapping = self::jetform_mappings()[$formId] ?? null;
        if (!$mapping) { self::jet_error('FirmaBind: formulár nemá povolené mapovanie.'); }
        $jetContext = function_exists('jet_fb_context') ? jet_fb_context() : null;
        if (!is_object($jetContext) || !method_exists($jetContext,'update_request') || !method_exists($jetContext,'update_request_value')) {
            self::jet_error('FirmaBind: táto verzia JetFormBuilder nepodporuje aktualizáciu podania.');
        }
        if (!is_array($request)) { self::jet_error('FirmaBind: neplatné podanie.'); }
        // A submitted hidden reference is never authority, including consumer/error records.
        self::jet_write($jetContext, 'vorkei_firmabind_snapshot_id', 0);
        $customer = [];
        foreach ($mapping as $key=>$field) { $customer[$key] = $key === 'ico' ? self::ico($request[$field] ?? '') : self::scalar($request[$field] ?? ''); }
        self::$jetResults ??= new WeakMap();
        $handlerResults = self::$jetResults[$handler] ?? [];
        if (!isset($handlerResults[$formId])) {
            try {
                $handlerResults[$formId] = Vorkei_FirmaBind_Submission::process($customer, [
                    'kind'=>'jetform','form_id'=>$formId,
                    'submission_id'=>wp_generate_uuid4(), 'idempotency_key'=>'jetform:'.wp_generate_uuid4(),
                ]);
            } catch (Throwable $e) { self::jet_error($e instanceof InvalidArgumentException ? $e->getMessage() : 'FirmaBind: snímku sa nepodarilo uložiť.'); }
            self::$jetResults[$handler] = $handlerResults;
        }
        $result = $handlerResults[$formId];
        if (empty($result['consumer'])) {
            $effective = [];
            foreach ($mapping as $key=>$field) {
                if (array_key_exists($key, $result['effective'])) { $effective[$field] = $result['effective'][$key]; }
            }
            // add_request() suffixes existing names during an action. Write the existing parser and raw value.
            $effective['vorkei_firmabind_snapshot_id'] = (int)$result['snapshot_id'];
            foreach ($effective as $field=>$value) { self::jet_write($jetContext, $field, $value); }
            // Published Action_Handler API; return only the reference, never private evidence.
            if (method_exists($handler,'add_response')) {
                $handler->add_response(['vorkei_firmabind_snapshot_id'=>(int)$result['snapshot_id']]);
            }
            do_action('vorkei_firmabind_jetform_snapshot_created', (int)$result['snapshot_id'], $formId, $handler);
        }
    }

    private static function jet_write($context, string $field, $value): void {
        // Parser_Context public APIs: update_request(value, name), update_request_value(name, value).
        $context->update_request($value, $field);
        $context->update_request_value($field, $value);
    }

    private static function jet_error(string $message): void {
        $class = '\Jet_Form_Builder\Exceptions\Action_Exception';
        if (class_exists($class)) { throw new $class('validation_failed', $message); }
        throw new InvalidArgumentException($message);
    }

    public static function enqueue(): void {
        $mappings = self::jetform_mappings();
        $checkout = function_exists('is_checkout') && is_checkout();
        if (!$checkout && function_exists('has_block') && has_block('woocommerce/checkout')) { $checkout = true; }
        if (!$checkout && function_exists('get_post') && function_exists('has_shortcode')) {
            $post = get_post();
            $checkout = $post && has_shortcode((string)$post->post_content, 'woocommerce_checkout');
        }
        if (!$checkout && (!$mappings || !class_exists('\Jet_Form_Builder\Plugin'))) { return; }
        $dependencies = [];
        if ($checkout && function_exists('wp_script_is') && wp_script_is('wc-blocks-data-store','registered')) {
            $dependencies = ['wp-data','wp-notices','wc-blocks-data-store'];
        }
        wp_enqueue_script('vorkei-firmabind', VORKEI_ICO_ATLAS_URL.'assets/firmabind.js', $dependencies, VORKEI_ICO_ATLAS_VERSION, true);
        wp_localize_script('vorkei-firmabind', 'vorkeiFirmaBind', [
            'url'=>rest_url('vorkei-firmabind/v1/card'), 'nonce'=>wp_create_nonce('vorkei_firmabind_card'),
            'restNonce'=>wp_create_nonce('wp_rest'),
            'jetForms'=>$mappings, 'blockFields'=>self::BLOCK_FIELDS,
            'blocks'=>in_array('wc-blocks-data-store',$dependencies,true),
        ]);
    }

    private static function scalar($value): string { return is_scalar($value) ? trim(sanitize_text_field((string)$value)) : ''; }
    private static function ico($value): string {
        // Invalid types must reach validation as invalid, never as an empty consumer field.
        return $value === null ? '' : (is_string($value) ? trim($value) : '[invalid ICO type]');
    }
}
