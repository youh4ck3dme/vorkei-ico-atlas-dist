<?php
if (!defined('ABSPATH')) {exit;}

/** Small public identity projection; never enters Atlas enrichment or financial jobs. */
class Vorkei_FirmaBind_Identity {
 const CACHE_PREFIX='vorkei_firmabind_card_';
 const LAST_PREFIX='vorkei_firmabind_last_';
 const TTL=900;
 const FIELDS=['ico','name','street','postal_code','city','dic','vat_id'];

 public static function get(string $ico): array {
  $started=hrtime(true);$ico=trim($ico);
  if(preg_match('//u',$ico)!==1) {throw new InvalidArgumentException('IČO má neplatné znaky.');}
  if($ico==='') {return self::empty('','not_found');}
  if(!preg_match('/^[0-9]{8}$/D',$ico)) {throw new InvalidArgumentException('IČO musí obsahovať presne osem číslic.');}
  $cached=self::clean(get_transient(self::CACHE_PREFIX.$ico),$ico);
  $last=self::clean(get_option(self::LAST_PREFIX.$ico,false),$ico);
  // An existing administrator lock is respected even if its timestamp is old.
  // A public card request must not delete it or start competing HTTP work.
  if(get_option('vorkei_ico_lock_'.$ico,false)!==false) {
   $out=($cached&&$cached['availability']==='found')?$cached:($last??$cached??self::empty($ico,'unavailable'));
   $out['stale']=true;return $out;
  }
  if($cached) {return $cached;}
  $stored=self::stored($ico);
  if($stored&&!$stored['stale']) {self::remember($stored);return $stored;}
  if($stored) {$last=$stored;}
  // Reserve time for projection/cache writes as well as the complete HTTP chain.
  $deadline=$started+(int)(3.7*1000000000);$rpo='https://api.statistics.sk/rpo/v1/search?identifier='.rawurlencode($ico);
  $response=self::json($rpo,$deadline);
  if($response===null||!is_array($response['results']??null)) {return self::fallback($ico,$last);}
  $matches=[];
  foreach($response['results'] as $row) {
   if(!is_array($row)||!is_array($row['identifiers']??null)) {return self::fallback($ico,$last);}
   foreach(['fullNames','addresses'] as $list) {if(isset($row[$list])&&!is_array($row[$list])) {return self::fallback($ico,$last);}}
   foreach($row['identifiers'] as $id) {
    if(!is_array($id)||!is_scalar($id['value']??null)) {return self::fallback($ico,$last);}
    if(Vorkei_Ico_Atlas_Profile::same_ico($id['value']??null,$ico)) {$matches[(string)($row['id']??count($matches))]=$row;break;}
   }
  }
  if(!$matches) {$out=self::empty($ico,'not_found');$out['retrieved_at']=gmdate('c');set_transient(self::CACHE_PREFIX.$ico,$out,60);return $out;}
  if(count($matches)!==1) {return self::fallback($ico,$last);}
  $row=reset($matches);$name=self::current($row['fullNames']??[]);$a=self::current($row['addresses']??[]);
  if(!is_string($name['value']??null)||trim($name['value'])==='') {return self::fallback($ico,$last);}
  foreach(['street','buildingNumber'] as $part) {if(isset($a[$part])&&!is_scalar($a[$part])) {return self::fallback($ico,$last);}}
  if(isset($a['postalCodes'])&&(!is_array($a['postalCodes'])||isset($a['postalCodes'][0])&&!is_scalar($a['postalCodes'][0]))) {return self::fallback($ico,$last);}
  if(isset($a['municipality'])&&(!is_array($a['municipality'])||isset($a['municipality']['value'])&&!is_scalar($a['municipality']['value']))) {return self::fallback($ico,$last);}
  $now=gmdate('c');$out=self::empty($ico,'found');$out['retrieved_at']=$now;
  $values=['ico'=>$ico,'name'=>$name['value'],'street'=>trim(($a['street']??'').' '.($a['buildingNumber']??'')),'postal_code'=>$a['postalCodes'][0]??'','city'=>$a['municipality']['value']??''];
  foreach($values as $field=>$value) {
   if(!is_scalar($value)) {continue;}$out[$field]=trim((string)$value);
   if($out[$field]!=='') {$out['sources'][$field]=self::source(['source'=>'RPO','source_url'=>$rpo,'source_record_id'=>(string)($row['id']??$ico),'retrieved_at'=>$now,'source_updated_at'=>$row['dbModificationDate']??null,'availability_status'=>'observed','match_method'=>'exact_ico','kind'=>'reported']);}
  }
  // RÚZ is used only for the entity DIČ. No statement, report, template or job URL.
  $ruz='https://www.registeruz.sk/cruz-public/api/';
  if(hrtime(true)<$deadline-250000000) {
   $ids=self::json($ruz.'uctovne-jednotky?zmenene-od=2000-01-01&ico='.rawurlencode($ico),$deadline);
   if(is_array($ids['id']??null)&&count($ids['id'])===1&&empty($ids['existujeDalsieId'])&&ctype_digit((string)$ids['id'][0])&&hrtime(true)<$deadline-150000000) {
    $id=(string)$ids['id'][0];$url=$ruz.'uctovna-jednotka?id='.$id;$entity=self::json($url,$deadline);
    if(is_array($entity)&&Vorkei_Ico_Atlas_Profile::same_ico($entity['ico']??null,$ico)&&preg_match('/^[0-9]{10}$/D',(string)($entity['dic']??''))) {
     $out['dic']=(string)$entity['dic'];$out['sources']['dic']=self::source(['source'=>'RÚZ','source_url'=>$url,'source_record_id'=>$id,'retrieved_at'=>gmdate('c'),'source_updated_at'=>$entity['datumPoslednejUpravy']??null,'availability_status'=>'observed','match_method'=>'exact_ico','kind'=>'reported']);
    }
   }
  }
  // DIČ is never converted into an invented VAT identifier.
  $out=self::retain_last($out,$last);self::remember($out);return $out;
 }

 /** Hook target for a successfully saved admin profile; only seven fields survive. */
 public static function observe_profile(array $profile): void {
  if(is_array($profile['profile']??null)) {$profile=$profile['profile'];}
  $ico=(string)($profile['ico']??'');if(!preg_match('/^[0-9]{8}$/D',$ico)) {return;}
  $card=self::project($profile,$ico);if($card) {self::remember($card);}
 }

 private static function stored(string $ico): ?array {
  global $wpdb;
  if(!is_object($wpdb)||!isset($wpdb->prefix)||!method_exists($wpdb,'get_var')||!method_exists($wpdb,'prepare')) {return null;}
  $table=$wpdb->prefix.'vorkei_ico_entities';
  // Database-side scalar projection avoids reading/decoding the financial and
  // personal parts of profile_json. Unsupported JSON SQL simply falls back to RPO.
  $scalar=static function(string $path): string {
   return "COALESCE(NULLIF(JSON_UNQUOTE(JSON_EXTRACT(profile_json, '$.profile.".$path."')), 'null'),NULLIF(JSON_UNQUOTE(JSON_EXTRACT(profile_json, '$.".$path."')), 'null'))";
  };
  $parts=[];
  foreach(['name','street','postal_code','city','dic','vat_id'] as $field) {
   $attributes=[];
   foreach(['value','source','source_url','source_record_id','retrieved_at','source_updated_at','valid_as_of','availability_status','match_method','kind'] as $attribute) {$attributes[]="'".$attribute."',".$scalar('fields.'.$field.'.'.$attribute);}
   $parts[]="'".$field."',JSON_OBJECT(".implode(',',$attributes).')';
  }
  $select="JSON_OBJECT('ico',".$scalar('ico').",'fields',JSON_OBJECT(".implode(',',$parts)."),'checks',JSON_OBJECT('fs_vat',JSON_OBJECT('availability_status',".$scalar('checks.fs_vat.availability_status').')))';
  $wasSuppressed=method_exists($wpdb,'suppress_errors')?$wpdb->suppress_errors(true):null;
  try {$raw=$wpdb->get_var($wpdb->prepare("SELECT {$select} FROM {$table} WHERE ico=%s LIMIT 1",$ico));}
  finally {if($wasSuppressed!==null) {$wpdb->suppress_errors($wasSuppressed);}}
  if(!is_string($raw)||$raw===''||strlen($raw)>65536) {return null;}
  $data=json_decode($raw,true);if(!is_array($data)) {return null;}
  return self::project(is_array($data['profile']??null)?$data['profile']:$data,$ico);
 }

 private static function project(array $p,string $ico): ?array {
  if(!Vorkei_Ico_Atlas_Profile::same_ico($p['ico']??null,$ico)||!is_array($p['fields']??null)) {return null;}
  $out=self::empty($ico,'found');$fields=$p['fields'];$name=$fields['name']??null;
  if(!is_array($name)||!is_string($name['value']??null)||trim($name['value'])===''||!self::trusted($name['source_url']??'')||!in_array($name['availability_status']??'',['observed','stale'],true)) {return null;}
  foreach(['name','street','postal_code','city','dic'] as $key) {
   $e=$fields[$key]??null;
   if(!is_array($e)||!is_scalar($e['value']??null)||!self::trusted($e['source_url']??'')||!in_array($e['availability_status']??'',['observed','stale'],true)) {continue;}
   if($key==='dic'&&!preg_match('/^[0-9]{10}$/D',(string)$e['value'])) {continue;}
   $out[$key]=trim((string)$e['value']);$out['sources'][$key]=self::source($e);
   if(($e['availability_status']??'')==='stale') {$out['stale']=true;}
  }
  $out['sources']['ico']=self::source($name);$out['retrieved_at']=is_string($name['retrieved_at']??null)?$name['retrieved_at']:'';
  if($out['retrieved_at']===''||strtotime($out['retrieved_at'])===false||strtotime($out['retrieved_at'])<time()-3600) {$out['stale']=true;}
  $v=$fields['vat_id']??null;$check=$p['checks']['fs_vat']['availability_status']??null;
  if(is_array($v)&&self::fs($v['source_url']??'')&&in_array($v['availability_status']??'',['observed','stale'],true)&&$check!=='not_found'&&is_string($v['value']??null)&&preg_match('/^SK[0-9]{10}$/D',$v['value'])) {
   $out['vat_id']=$v['value'];$out['vat_status']='in_registry';$out['sources']['vat_id']=self::source($v);
   $at=is_string($v['retrieved_at']??null)?strtotime($v['retrieved_at']):false;
   if(($v['availability_status']??'')==='stale'||($check!==null&&$check!=='observed')||$at===false||$at<time()-3600) {$out['sources']['vat_id']['availability_status']='stale';$out['stale']=true;}
  }
  return self::clean($out,$ico);
 }

 private static function current(array $rows): array {
  $today=gmdate('Y-m-d');$good=[];
  foreach($rows as $r) {
   if(!is_array($r)) {continue;}
   if(isset($r['validFrom'])&&!is_string($r['validFrom'])||isset($r['validTo'])&&!is_string($r['validTo'])) {continue;}
   if((empty($r['validTo'])||$r['validTo']>=$today)&&(!isset($r['validFrom'])||$r['validFrom']<=$today)) {$good[]=$r;}
  }
  usort($good,static function($a,$b){return strcmp($b['validFrom']??'',$a['validFrom']??'');});return $good[0]??[];
 }
 private static function json(string $url,int $deadline): ?array {
  $remaining=($deadline-hrtime(true))/1e9;if($remaining<0.15) {return null;}
  $r=wp_safe_remote_get($url,['timeout'=>min(1.2,$remaining),'redirection'=>0,'sslverify'=>true,'limit_response_size'=>262144,'headers'=>['Accept'=>'application/json']]);
  if(is_wp_error($r)||(int)wp_remote_retrieve_response_code($r)!==200||hrtime(true)>$deadline) {return null;}
  $body=wp_remote_retrieve_body($r);if(!is_string($body)||strlen($body)>262144) {return null;}$data=json_decode($body,true);return is_array($data)?$data:null;
 }
 private static function trusted($url): bool {if(!is_string($url)) {return false;}$host=strtolower((string)parse_url($url,PHP_URL_HOST));return parse_url($url,PHP_URL_SCHEME)==='https'&&(in_array($host,['api.statistics.sk','rpo.statistics.sk','www.orsr.sk','orsr.sk','sluzby.orsr.sk','www.registeruz.sk','registeruz.sk'],true)||self::fs($url));}
 private static function fs($url): bool {if(!is_string($url)) {return false;}$host=strtolower((string)parse_url($url,PHP_URL_HOST));return parse_url($url,PHP_URL_SCHEME)==='https'&&($host==='financnasprava.sk'||str_ends_with($host,'.financnasprava.sk'));}
 private static function source(array $e): array {
  $out=[];foreach(['source','source_url','source_record_id','retrieved_at','source_updated_at','valid_as_of','availability_status','match_method','kind'] as $key) {if(is_string($e[$key]??null)||($e[$key]??1)===null) {$out[$key]=$e[$key];}}
  return $out;
 }
 private static function empty(string $ico,string $availability): array {return ['ico'=>$ico,'name'=>'','street'=>'','postal_code'=>'','city'=>'','dic'=>'','vat_id'=>'','vat_status'=>'not_in_registry','availability'=>$availability,'retrieved_at'=>'','sources'=>[],'stale'=>false];}
 private static function clean($card,string $ico): ?array {
  if(!is_array($card)||($card['ico']??null)!==$ico||!in_array($card['availability']??'',['found','not_found','unavailable'],true)||(($card['availability']??'')==='found'&&(!is_string($card['name']??null)||trim($card['name'])===''))) {return null;}
  $out=self::empty($ico,$card['availability']);
  foreach(self::FIELDS as $key) {if(is_string($card[$key]??null)) {$out[$key]=self::clip($card[$key],$key==='name'?500:300);}}
  $out['retrieved_at']=is_string($card['retrieved_at']??null)?$card['retrieved_at']:'';$out['stale']=!empty($card['stale']);
  foreach(self::FIELDS as $key) {if(is_array($card['sources'][$key]??null)&&self::trusted($card['sources'][$key]['source_url']??'')) {$out['sources'][$key]=self::source($card['sources'][$key]);}}
  if($out['availability']==='found') {
   if(empty($out['sources']['name'])) {return null;}
   $now=time();$at=strtotime($out['retrieved_at']);
   if($at===false||$at<$now-3600||$at>$now+60) {$out['stale']=true;}
   foreach($out['sources'] as &$e) {
    $at=is_string($e['retrieved_at']??null)?strtotime($e['retrieved_at']):false;
    if($at===false||$at<$now-3600||$at>$now+60) {$e['availability_status']='stale';$out['stale']=true;}
   }unset($e);
  }
  // Even a malformed old cache cannot smuggle an inferred or stale proxy VAT ID.
  if($out['vat_id']!==''&&preg_match('/^SK[0-9]{10}$/D',$out['vat_id'])&&self::fs($out['sources']['vat_id']['source_url']??'')&&in_array($out['sources']['vat_id']['availability_status']??'',['observed','stale'],true)) {$out['vat_status']='in_registry';if(($out['sources']['vat_id']['availability_status']??'')==='stale') {$out['stale']=true;}}
  else {$out['vat_id']='';unset($out['sources']['vat_id']);}
  return $out;
 }
 private static function clip(string $value,int $max): string {
  if(function_exists('mb_substr')) {return mb_substr($value,0,$max);}
  if(preg_match('/^.{0,'.$max.'}/us',$value,$match)) {return $match[0];}
  return substr($value,0,$max);
 }
 private static function remember(array $card): void {
  $card=self::clean($card,$card['ico']);if(!$card) {return;}set_transient(self::CACHE_PREFIX.$card['ico'],$card,self::TTL);
  if($card['availability']==='found') {update_option(self::LAST_PREFIX.$card['ico'],$card,false);}
 }
 private static function retain_last(array $out,?array $last): array {
  if(!$last||$last['ico']!==$out['ico']) {return $out;}
  foreach(['street','postal_code','city','dic','vat_id'] as $key) {
   if($out[$key]!==''||($last[$key]??'')===''||!is_array($last['sources'][$key]??null)) {continue;}
   $out[$key]=$last[$key];$out['sources'][$key]=$last['sources'][$key];$out['sources'][$key]['availability_status']='stale';$out['stale']=true;
   if($key==='vat_id') {$out['vat_status']='in_registry';}
  }return $out;
 }
 private static function fallback(string $ico,?array $last): array {
  $out=$last??self::empty($ico,'unavailable');$out['stale']=$last!==null;set_transient(self::CACHE_PREFIX.$ico,$out,30);return $out;
 }
}
