<?php
/**
 * Uninstall policy: keep company profiles, FirmaBind snapshots and rate-limit rows.
 * Removing the plugin must not destroy evidence that may belong to orders.
 * Scheduled jobs are cleared. Dropping tables requires an explicit site option
 * set before deletion: vorkei_ico_delete_data_on_uninstall = yes.
 *
 * @package Vorkei_Ico_Atlas
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

wp_clear_scheduled_hook( 'vorkei_ico_refresh' );
wp_clear_scheduled_hook( 'vorkei_ico_continue' );

if ( get_option( 'vorkei_ico_delete_data_on_uninstall' ) !== 'yes' ) {
	return;
}

global $wpdb;
foreach ( [ 'vorkei_ico_entities', 'vorkei_firmabind_snapshots', 'vorkei_firmabind_limits' ] as $suffix ) {
	$wpdb->query( 'DROP TABLE IF EXISTS ' . $wpdb->prefix . $suffix );
}
delete_option( 'vorkei_ico_schema_version' );
delete_option( 'vorkei_firmabind_snapshot_schema' );
delete_option( 'vorkei_firmabind_limits_version' );
delete_option( 'vorkei_ico_delete_data_on_uninstall' );
