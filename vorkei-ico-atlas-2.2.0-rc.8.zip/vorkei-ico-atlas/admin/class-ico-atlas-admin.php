<?php
/**
 * Admin Panel Manager for VORKEI IČO ATLAS.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Vorkei_Ico_Atlas_Admin {

	private static ?Vorkei_Ico_Atlas_Admin $instance = null;

	public static function get_instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'admin_menu', [ $this, 'register_menu' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );
		add_action( 'admin_init', [ $this, 'register_settings' ] );
	}

	public function register_menu(): void {
		add_menu_page(
			__( 'VORKEI IČO ATLAS', 'vorkei-ico-atlas' ),
			__( 'IČO ATLAS', 'vorkei-ico-atlas' ),
			'manage_options',
			'vorkei-ico-atlas',
			[ $this, 'render_dashboard' ],
			'dashicons-building',
			58
		);
	}

	public function register_settings(): void {
        add_option('vorkei_ico_fs_api_key','','','no');
        register_setting('vorkei_ico_settings','vorkei_ico_fs_api_key',['type'=>'string','sanitize_callback'=>[$this,'sanitize_fs_key']]);
        foreach(['dic_slug','vat_slug','ico_column'] as $part) {register_setting('vorkei_ico_settings','vorkei_ico_fs_'.$part,['type'=>'string','sanitize_callback'=>'sanitize_text_field']);}
        register_setting('vorkei_ico_settings','vorkei_ico_ruz_enabled',['type'=>'string','sanitize_callback'=>static fn($v)=>$v==='yes'?'yes':'no','default'=>'yes']);
		register_setting( 'vorkei_ico_settings', 'vorkei_ico_api_url', [
			'type'              => 'string',
			'sanitize_callback' => 'esc_url_raw',
			'default'           => 'https://ico-api.vorkei.com/api/company/proxy-search?ico=',
		] );

		register_setting( 'vorkei_ico_settings', 'vorkei_ico_auto_enrich', [
			'type'              => 'string',
			'sanitize_callback' => 'sanitize_text_field',
			'default'           => 'yes',
		] );
	}

    public function sanitize_fs_key($value): string {
        if(!empty($_POST['vorkei_ico_fs_clear_key'])) {return '';}
        $saved=get_option('vorkei_ico_fs_api_key','');
        $saved=is_string($saved)?$saved:'';
        if(!is_string($value)) {
            add_settings_error('vorkei_ico_fs_api_key','invalid_type','API kľúč musí byť text. Uložená hodnota zostala zachovaná.');
            return $saved;
        }
        $value=trim($value);
        return $value!==''?sanitize_text_field($value):$saved;
    }

	public function enqueue_assets( string $hook ): void {
		if ( 'toplevel_page_vorkei-ico-atlas' !== $hook ) {
			return;
		}

		wp_enqueue_style(
			'vorkei-ico-atlas-admin',
			VORKEI_ICO_ATLAS_URL . 'admin/assets/admin.css',
			[],
			VORKEI_ICO_ATLAS_VERSION
		);

		wp_enqueue_script(
			'vorkei-ico-atlas-admin',
			VORKEI_ICO_ATLAS_URL . 'admin/assets/admin.js',
			[ 'jquery' ],
			VORKEI_ICO_ATLAS_VERSION,
			true
		);

		wp_localize_script(
			'vorkei-ico-atlas-admin',
			'vorkeiIcoAtlas',
			[
				'root'  => esc_url_raw( rest_url() ),
				'nonce' => wp_create_nonce( 'wp_rest' ),
			]
		);
	}

	public function render_dashboard(): void {
		$enricher = new Vorkei_Ico_Atlas_Enricher();
		$stats    = $enricher->get_audit_stats();
		$filter   = sanitize_text_field( wp_unslash( $_GET['filter'] ?? 'all' ) );
		if ( ! in_array( $filter, [ 'all', 'active', 'risky', 'unverified' ], true ) ) {
			$filter = 'all';
		}
		$entities = $enricher->get_entities( $filter, 50, (max(1,(int)($_GET['atlas_page']??1))-1)*50 );

		require_once VORKEI_ICO_ATLAS_PATH . 'admin/views/dashboard.php';
	}
}
