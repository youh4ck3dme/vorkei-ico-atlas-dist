# VORKEI IČO ATLAS 2.2.0-rc.4 — overenie

Lokálne funkčné skúšky a ciele pokrytia: **PASS**. Externé závislosti majú samostatné **BLOCKED**. Pokrytie vykonaním nie je pravdepodobnosť bezchybnosti.

## Pokrytie aktuálneho RC4

| Jazyk | Riadky | Zavolané funkcie/metódy | Vetvy |
|---|---:|---:|---:|
| PHP | 2234/2247 (99.42 %) | 228/228 (100.00 %) | 3211/3342 (96.08 %) |
| JavaScript | 215/215 (100.00 %) | 64/64 (100.00 %) | 367/378 (97.08 %) |

Zahrnutých je všetkých 20 vlastných PHP a 2 JS súborov vrátane administrácie a chýb. Vylúčené sú len testy/podklady a cudzie závislosti. Funkcia sa počíta ako vyvolaná deklarácia; prísnejšia metrika celkom pokrytých metód je 143/206 (69.42 %). Ostáva 13 PHP riadkov, 131 PHP vetiev a 11 JS vetiev bez zásahu. Presné miesta: php-coverage-gaps.json, php-runtime-functions.json a js-coverage-summary.json; HTML v php/ a javascript/.

Nástroje a konfigurácie sú priložené. Xdebug3.5.0 branch-only patch zachováva CFG/riadky/hit počítadlá a vypína enumeráciu úplných ciest; path coverage sa netvrdí. Normalizácia opcode adries sa prijíma iba pri zhode celého CFG aj zdrojových rozpätí, s kontrolou nezmenených počítadiel a odmietnutím kontrolovane zmeneného grafu. Raw údaje zostávajú priložené. Stock engine bol porovnaný s kalibračným podkladom a deterministickými PHP sadami. JS používa Istanbul a SHA-256 vstupných zdrojov; staré mapy sa nezmiešavajú. Kompletné nastavenie a menovatele sú vo výsledkovom JSON a QA-REPRO.md.

## Opravené postrehy z prílohy

Príloha má 1301035 B a SHA-256 `0e1dbb553fea570c634ae71a5687f57386f4de1580ccf8d1c3dbd393ed7a7566`. Toto je **offline prepočet pôvodnej prílohy**, žiadne nové živé získavanie údajov. Pôvodné source_updated_at a retrieved_at sa zachovávajú.

- Finančné záznamy: **38 → 24**, metriky: **56 → 31**. Poradie kľúčov objektu už nevytvára novú verziu výkazu. Poradie zoznamov a rozdiely null/0/false zostávajú zachované.
- Skutočná zmena obsahu zachová obe verzie, ich aliasy a dôkazy. Historické verzie v kompaktnom pohľade sú výslovne na požiadanie; úplný archivný JSON zostáva dostupný.
- Finančná skupina je **partial**. Synchronizácia zostáva **source_unavailable**, pending=true, remaining_tasks=14; nejde o dokončené načítanie. Posledný pokus je `2026-10-31T16:41:56+00:00`, posledné úspešné získanie `2026-10-31T16:39:47+00:00`.
- Obnovenie zdroja nahradí predchádzajúci neúspešný last_attempt_status. Katalóg výkazov a výber najnovšej proveniencie prebiehajú oddelene; vstupy metrík zostávajú pri správnej verzii. Neznáma verzia faktu si nemôže vytvoriť dôveryhodný alias sama. Aj objektová reprezentácia raw výkazu alebo šablóny sa odstráni z kompaktného výstupu.
- RPO potvrdzuje **identitu**, s retrieved_at=`2026-10-31T16:49:13+00:00` a source_updated_at=`2025-07-07`. Nové identity_verified=true je odlíšené od pôvodného právneho verified=false a active=null. Existencia v RPO nepotvrdzuje hospodársku aktivitu ani bezdlžnosť.
- Nový chránený formát **compact_json**, schéma atlas-compact/1.0, používa referencie na report, fakt a provenienciu. Metadáta ani vstupy metrík sa nekopírujú ku každému číslu. Pôvodné format=json/CSV a FirmaBind verejná karta zostávajú samostatné a spätne kompatibilné.

Pri rovnakom minifikovanom serializéri: pôvodný JSON 1223975 B, archív po projekcii 750632 B, kompaktný JSON 334127 B (**−72.70 %** oproti pôvodnému minifikovanému JSON). Reálne súbory: archív 1984884 B, kompakt 334127 B; rozdiel formátovania je priznaný. Súbory EB-EU-ico-atlas-rc4-kompakt.json a EB-EU-ico-atlas-rc4-archiv.json obsahujú opravený pohľad prílohy. Podklad veľkostí: rc4/size-check.json a reports/rc4-offline-projection.json.

## Vykonané kontroly a verdikty

Finálny runner: **77/77 sád/procesov PASS**; 612 izolovaných PHP kontrol na každom základnom PHP runtime, plus varianty rozšírení a natívne testy. Počítajú sa riadky PASS: doplnkový compact-export-edge-test má16 úspešných scenárov a72 sémantických assertions, ktoré sa vykazujú oddelene. Počet nie je percentuálne pokrytie. Matica požiadavka → komponent → scenár → druh testu → očakávaný výsledok → výsledok → dôkaz je v requirements-matrix.csv/json.

Pôvodný nezmenený RC1 ZIP bol osobitne znovu overený: **274/274 kontrol PASS**, čas `2026-10-31T19:51:28.371263+00:00`. Tento historický základ sa nepripočítava k RC4 procesom ani k pokrytiu aktuálneho kódu; dôkaz je rc1-baseline-repeated.json. SHA pôvodných ZIP-ov2.1, RC1, RC2 a RC3 sa kontrolujú pred balením aj po ňom.

| Oblasť | Verdikt | Dôkaz |
|---|---|---|
| Kanonická deduplikácia, skutočné revízie a pôvod | PASS | final-php-profile-export-regression.log a zodpovedajúci PHP8.1 beh |
| Kompaktný kontrakt, referencie, história, null/0 a cudzie meny | PASS | final-php-compact-export-test.log a PHP8.1; všetky referencie sa rozlíšia |
| Chybové a obnovovacie vetvy exportu, verzie, aliasy a objektové raw payloady | PASS | final-php-compact-export-edge-test.log a PHP8.1,16 scenárov /72 assertions |
| RC4 mutačné regresie | PASS | rc4-mutations.json a rc4-rc4-mutations.log; všetky štyri kontrolované chyby vyvolali skutočné zlyhanie assertions |
| Skutočný REST a DB, oprávnenia, chybné history, bez tichého prepisu uloženého JSON | PASS | final-rc4-export.json |
| Regresie Woo classic/Blocks, HPOS a JetForm Save Form Record | PASS | browser.json, browser-variants.json, browser-db.json, jet-variants-db.json |
| OFF/ON, migrácie, cron, Bridge callback, súbeh a nemenné snímky | PASS | final-run.json, toggle.json, cron.json, concurrency.json, mutations.json |
| Ciele pokrytia | PASS | Aktuálne RC4 reporty, SHA kontrola zdrojov, rc4-final-campaign.json |
| Presný inštalačný ZIP a aktualizácia | Následná skúška | installer-smoke-rc4.json a installer-upgrade-rc4.json sa pridajú až po vykonaní |
| Živé FS/VIES, backend mikroslužby, licencovaný JetEngine | BLOCKED | Chýbajú príslušné prístupy/balík; lokálne dvojníky ich nenahrádzajú |
| Produkčné presmerovanie a celý cudzí web | BLOCKED | Prístup produkčného prehliadača bol odmietnutý; produkcia sa nemenila |

Presné verzie a izolácia sú v environment.json. Použitý je skutočný WordPress, MariaDB, Woo a JetFormBuilder. Minimálna WP6.2/PHP8.1 kombinácia sa skúša osobitne bez nepodporovanej verzie Woo. HPOS používa OrdersTableDataStore/wc_orders/wc_orders_meta. SQLite sa v RC4 netestoval. Všetky servery sú loopback; platby aj emaily sú zablokované a poruchové/záťažové testy používajú lokálneho poskytovateľa. Výkon p50/p95/max a vzorky sú v performance.json, osobitne služba po bootstrapovaní a celé HTTP; nejde o všeobecnú záruku4s webu.

Externé podmienky vrátane známeho vlastného problému Bridge audit_log/audit_logs zostávajú v matici. Pripravené polia ani neimplementované konektory sa neoznačujú za živé integrácie. FirmaBind zostáva predvolene vypnutý. RC3 distribuované súbory sú zachované byte-identical.
