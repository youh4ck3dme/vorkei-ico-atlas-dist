# Obnova a odinštalovanie — 2.2.0-rc.5

Toto nie je overený návod na živý web. V tomto prostredí nebežal WordPress ani MariaDB.

## Čo stačí vrátiť súbormi

Ak sa po nahratí ZIP-u pokazí iba PHP a databáza sa nestiha zmeniť, vráťte predchádzajúci inštalačný ZIP a nechajte tabuľky tak. Migrácia 2.1.1 a snímky 1.1 sú aditívne. Samotný návrat súborov staršieho RC4 nespustí downgrade schémy.

## Kedy treba obnoviť databázu

Obnovte zálohu databázy, ak sa medzitým zmenili riadky `vorkei_ico_entities`, `vorkei_firmabind_snapshots` alebo `vorkei_firmabind_limits`, prípadne prázdne stĺpce CCT. Snímka po uložení nemení JSON ani hash; jediný bežný zápis navyše je jednorazové doplnenie `order_id`. Obnoviť treba aj objednávku, ak sa jej meta snímky nemá zhodovať s tabuľkou.

Bez vyskúšanej obnovy na kópii webu nepokladajte downgrade za bezpečný.

## Odinštalovanie

Zmazanie pluginu v administrácii spustí `uninstall.php`. Predvolene zmaže iba naplánované úlohy `vorkei_ico_refresh` a `vorkei_ico_continue`. Profily, snímky a limity zostanú.

Tabuľky zmaže iba vtedy, ak pred odinštalovaním nastavíte možnosť `vorkei_ico_delete_data_on_uninstall` na `yes`. JetEngine tabuľky sa nemažú.

## Čo táto verzia neoverila

Čistá inštalácia, aktualizácia z 2.1 a z RC4, prerušená migrácia, multisite, WooCommerce, HPOS, JetFormBuilder a obnova zálohy na skutočnej databáze. Pozri rozhodnutie o vydaní v `outputs`.
