# VORKEI IČO ATLAS 2.2.0-rc.8

**Verdikt: BLOCKED pre stabilný predaj.** RC.8 je ďalší kandidát, nie komerčné vydanie.

## Čo je v tomto balíku opravené

- Expirovaný vlastník zámku nemaže token novšieho behu a po strate zámku nezapíše profil.
- Rozpočet identity, registrov a FS používa `hrtime`, nie `microtime`.
- CSV alebo JSON export nad 8 MiB končí chybou. Súbor sa neposiela ako úspech.
- Neúplná odpoveď so stavom `source_unavailable` alebo `invalid_response` neoznačí firmu znova ako overene aktívnu.
- Keď sa snímka nepriradí k objednávke, objednávka nedostane ID snímky.

Izolovaný stub: 92/92. To nie je WordPress, MariaDB, WooCommerce, HPOS, JetForm ani namerané pokrytie.

## Čo predaj stále blokuje

- WordPress 6.2 a aktuálny, MariaDB, čistá inštalácia, aktualizácia, multisite.
- Woo classic, Blocks, HPOS a JetForm Save Form Record na ozajstnom obchode.
- Pokrytie PHP a JS: Xdebug alebo PCOV tu nie je, prahy 99/99/95 sú NOT RUN.
- WPCS a PHPStan sa v tomto prostredí nespustili. Starý počet 879/143 sa na tieto bajty neprenáša a nie je uzavretý.
- Živé RPO, ORSR, RÚZ, FS a VIES sa nevolali. Podmienky redistribúcie dát nie sú doložené z primárnych licencií.
- Snímka nie je kvalifikovaný podpis ani časová pečiatka.

FirmaBind ostáva predvolene vypnutý. Odinštalovanie nemaže dáta, kým nie je `vorkei_ico_delete_data_on_uninstall=yes`.
