# Atlas 2.2.0-rc.3 / FirmaBind

Toto je skúšobná verzia jedného ZIP balíka Atlasu. Registračná časť používa kontrakt 2.1 a jej `/vorkei-ico/v1/lookup` zostáva iba pre administrátora. Distribuovaný ZIP 2.1 sa nemení. FirmaBind sa zapína samostatne v IČO ATLAS → FirmaBind 2.2; predvolená hodnota je `no`. Vypnutý modul nenačíta identitnú službu, verejnú cestu, formulárové skripty ani migrácie FirmaBind.

## Tok a hranice údajov

`formulár → verejná identitná karta → serverové vyhodnotenie podania → vlastná nemenná snímka → Woo CRUD / JetForm referencia → administrátorský JSON export`

Karta číta iba IČO, názov, ulicu, PSČ, mesto, DIČ a skutočne doložené IČ DPH. Existujúci profil sa v databáze číta pomocou výslovnej JSON projekcie povolených polí. Nová služba nevolá `lookup_and_save`, `Client::lookup`, ORSR úplný výpis, výkazy ani účtovnú frontu. Štruktúrovanú adresu neskladá parsovaním formátovaného sídla.

| Údaj/služba | Zdroj a prístup | Identifikátor a obmedzenie |
|---|---|---|
| IČO, názov, ulica, PSČ, mesto | Uložené doložené polia Atlasu; pri cache miss verejné [RPO JSON](https://api.statistics.sk/rpo/v1/search?identifier=51226511) | Presné IČO; aktuálne štruktúrované polia, žiadne osoby do prehliadača |
| DIČ | Uložená evidencia; verejné [RÚZ API](https://www.registeruz.sk/cruz-public/api/) iba zoznam jednotiek a detail jednej jednotky | Presná zhoda IČO; bez závierok, výkazov a príloh |
| Registrové IČ DPH | Už získané doložené pole FS v Atlase | Žiadny nový FS dotaz z checkoutu. Vlastný kľúč a nastavené zoznamy v administrácii Atlasu; `SK + DIČ` sa nikdy nevyrába |
| Platnosť zadaného IČ DPH | Oficiálna služba [VIES](https://ec.europa.eu/taxation_customs/vies/checkVatService.wsdl), SOAP `checkVat` cez HTTPS | Skutočne zadané zákaznícke číslo alebo doložené registrové číslo; presná kontrola countryCode/vatNumber v odpovedi |
| Väzba IČO ↔ IČ DPH | Presný aktuálny záznam FS + samostatný výsledok VIES | Podobnosť názvu ani meno `---` väzbu nepotvrdzujú |

Podmienky a obmedzenia registrových konektorov sú opísané v ZDROJE.md. FirmaBind nezavádza hromadné preberanie nových zoznamov ani bankových údajov. VIES overuje registráciu čísla podľa svojej služby; [význam výsledkov vysvetľuje EÚ](https://europa.eu/youreurope/business/finance-and-tax/vat/check-vat-number-vies/index_en.htm). Výsledok nie je posudok firmy ani automatické rozhodnutie o daňovej sadzbe. Modul nemení dane objednávky.

## Cache, dostupnosť a limity

Karta má samostatnú cache s dobou 15 minút a poslednú známu identitu mimo cache celého profilu. Existujúci administrátorský zámok sa nepreberá ani nemaže: vráti sa posledná identita ako staršia kópia alebo nedostupnosť, bez HTTP. Chýbajúci záznam sa odlišuje od chyby služby. Výpadok RÚZ nevymaže známe DIČ; zachová pôvodný čas a označí staršie údaje.

Identitné HTTP požiadavky majú spoločný rozpočet do 3,7 s, najviac 1,2 s na jednu požiadavku, bez presmerovania a s obmedzenou veľkosťou odpovede. Zvyšok do cieľových 4 s je rezerva na miestne spracovanie. Limit nepredstavuje garanciu času nefunkčnej lokálnej databázy či zablokovaného PHP procesu. Samostatné VIES pri odoslaní má timeout 3 s. Platný výsledok sa ukladá najviac na hodinu, neplatný na 5 minút, výpadok na 30 s; vždy najneskôr do konca UTC dňa.

Verejný POST potrebuje nonce a má predvolene limit 12 požiadaviek na IP/min a 1 000 kontrol webu/deň. Rovnaký rozpočet používa serverové podanie, aby sa formulárom nedal obísť. Po jeho dosiahnutí sa externé služby nevolajú; zákazník pokračuje ručne a snímka uvádza `rate_limited` / `not_checked`. Podmienené databázové zvýšenie počítadla je atómové. Ukladá sa solený odtlačok IP, nie surová IP. Hlavičky X-Forwarded-For sa nepovažujú za dôveryhodné; za reverzným proxy preto môžu návštevníci zdieľať limit. Vypršané počítadlá sa priebežne odstraňujú.

## Význam výsledkov

- `registry.vat_id` je iba zdrojové pole. Ak zdroj nie je doložený, hodnota je `""` a `vat_status=not_in_registry`.
- `customer.ic_dph` uchová to, čo odoslal zákazník. Nikdy sa nekopíruje do registračného poľa.
- `checks.vies.status`: `valid`, `invalid`, `unavailable`, `not_checked`. Neplatné číslo sa nezamieňa s výpadkom. Výpadok nie je dôkaz podvodu; `invalid` nie je právny záver o firme.
- `checks.binding.status`: `matched`, `mismatch`, `withheld`. Meno `---` samo osebe väzbu nepotvrdzuje. Bez presného aktuálneho dôkazu FS zostáva `withheld`; aktuálny presný dôkaz FS spolu s VIES-valid môže vytvoriť `matched` aj pri skrytom mene. Ani withheld, invalid či unavailable predvolene nezastavia nákup.
- Názov, sídlo a DIČ sa dopĺňajú nezávisle od VIES. Sídlo nepredstavuje doloženú prevádzku alebo dodaciu adresu.
- Prázdne IČO umožní spotrebiteľský nákup. Vyplnené IČO musí mať presne osem číslic, vrátane prípadnej úvodnej nuly. Krajina SK sama nevytvorí firemný nákup.

## Formuláre a snímka

Klasický Woo checkout používa vlastné voliteľné polia `billing_vorkei_ico`, `billing_vorkei_dic`, `billing_vorkei_ic_dph`. Blokový checkout používa Additional Checkout Fields `vorkei-firmabind/ico`, `/dic`, `/ic-dph`. Bloková integrácia vyžaduje dostupné API Additional Checkout Fields a podporované Woo dátové rozhrania. Overená bola verzia uvedená v testovacom protokole. Ide o samostatné adaptéry; oba volajú `Vorkei_FirmaBind_Submission::process()`. Pri zapnutom module sa deklaruje HPOS kompatibilita cez Woo FeaturesUtil. Woo snapshot a jeho ID/odtlačok sa kopírujú cez `$order->update_meta_data()`. Zmena profilu alebo adresy neskôr neprepisuje pôvodný databázový riadok.

JetFormBuilder sa zapája výslovne. V administrácii nastavte JSON mapovanie `ID formulára → kanonické pole → názov poľa` a pridajte akciu Call Hook `vorkei_firmabind` **pred** Save Form Record, email, CRM a ďalšie akcie. Podanie používa ID formulára zo serverového Action_Handler. Serverom vybrané údaje sa cez API kontextu prepisujú v parseri aj pôvodnom requeste a odovzdajú ďalším akciám; uloží sa aj referencia `vorkei_firmabind_snapshot_id`. Interné UUID podania FirmaBind nie je ID záznamu JetFormBuilder. Úplná snímka sa do odpovede prehliadača neposiela.

Pred odoslaním sa na serveri znovu vyhodnotí IČO a skutočné formulárové polia. Skryté snapshoty a výsledky kontrol z prehliadača sa ignorujú. Snímka uchová registrovú kartu, zákaznícke údaje, vybrané efektívne údaje, VIES, väzbu a rozdiely (`comparison.status=diverged`). Aktuálne doložené serverové identitné polia majú prednosť pri ďalšom spracovaní; staršia evidencia neprepisuje ručne zadané hodnoty a výber označuje `selection`. Ak nebolo čo porovnať, stav je `not_compared`; ručne zadané IČ DPH zostáva tvrdením zákazníka. Nedostupné overenie zachová ručné údaje. Chyba uloženia povinnej snímky je chyba podania, aby objednávka nepredstierala uložený dôkaz.

## API a export

`POST /wp-json/vorkei-firmabind/v1/card`, telo `{"ico":"51226511"}`, hlavičky `X-Vorkei-Nonce` (akcia `vorkei_firmabind_card`) a `X-WP-Nonce` pre prihlásené WordPress relácie. Odpoveď obsahuje presne 12 kľúčov podľa FIRMABIND-CARD.schema.json. Obmedzené `sources` obsahuje iba pôvod povolených polí. Osoby, financie, kľúče a ľubovoľné vnorené dáta nemôžu prejsť zoznamom povolených atribútov. Odpoveď má `Cache-Control: no-store, private`.

`GET /wp-json/vorkei-firmabind/v1/snapshots/ID` vyžaduje `manage_options` a pri cookie autentifikácii REST nonce. Vráti úplnú snímku, dátum, väzbu objednávky/formulára, SHA-256 a UUID. Export osobných polí nie je verejný. JSON zachová celý obsah; CSV snímok sa v tejto verzii nepridáva. SHA-256 odhaľuje zmenu uložených bytov, nie je kvalifikovaným podpisom ani dôveryhodnou časovou pečiatkou.

## Migrácie a spätná kompatibilita

Pri zapnutí sa verziovane vytvoria `{$wpdb->prefix}vorkei_firmabind_snapshots` (schéma1.1) a `...firmabind_limits` (schéma1.1). Migrácia nevymaže existujúce záznamy, overí stĺpce a ochranné unikátne indexy snímok. Úspech sa zapíše až po kontrole. Vypnutý modul tieto migrácie nespúšťa. Údaje pri jeho vypnutí zostávajú uchované; retenciu a prípadné riadené mazanie treba nastaviť podľa účelu konkrétneho webu.

Snapshot: povolený je INSERT a jednorazové doplnenie NULL `order_id`. Nie je k dispozícii API na úpravu obsahu. Opakovanie serverového pokusu s iným obsahom pod rovnakým kľúčom sa odmietne. Už prijatá objednávka používa pôvodnú snímku aj pri opakovaní platby. Neskoršia úprava objednávky v administrácii nie je úpravou pôvodného dôkazu.

JetEngine CCT a Vorkei Bridge zostávajú v registrovej vrstve. FirmaBind do nich neposiela checkout ani nerobí ich audit. Registrové schémy a administrátorské oprávnenia sa nemenia. Modul nemá licenčný server, agentúrny cenník, Doklad Core ani tvorbu e-faktúr.

## Overenie a hranice vydania

Konkrétne výsledky, verzie skúšobného prostredia a neoverené časti sú v OVERENIE-2.2.md. Testy s dvojníkmi nie sú testom každej funkcie a nenahrádzajú skutočný WordPress. Skúšky RC3 používajú skutočný WordPress a MariaDB; ich presný rozsah je v protokole. Nenahrádzajú overenie používateľovej témy, konkrétnej platobnej brány a licencovaného JetEngine na cieľovom skúšobnom webe. Pred predajom treba dokončiť príslušné skúšky na cieľovom skúšobnom webe.

## Zmeny RC2 a migrácie

Jadro databázy používa verziu `2.1.1`; API profil zostáva `2.1`. Pri aktualizácii sa overia všetky povinné stĺpce, primárny index a jedinečnosť IČO. Zlyhanie sa neoznačí za hotovú migráciu; pri bežnom načítaní zostáva opakovateľné a správca dostane oznámenie. Existujúce JSON sa neprepisuje.

FirmaBind schémy `1.1` overujú aj primárne indexy a index expirácie kvót. Z `1.0` sa kontrola spustí pri ďalšom zapnutí/načítaní zapnutého modulu. Nejde o zmenu API kontraktu snímky `firmabind/1.0`. Vypnutý modul tieto dve migrácie nevykonáva.

Z cache sa pri každom čítaní znova vyhodnotí vek dôkazu. Poškodený dátový typ z RPO spôsobí nedostupnosť alebo staršiu doloženú identitu. Slovenské IČ DPH má podporovaný formát `SK` a desať ASCII číslic; číslo sa nikdy nevyrába z DIČ.

Bridge1.0 sa dopĺňa o spätnú väzbu po úspešnom `POST /vorkei/v1/sync`: iba zaradenie jednej pokračovacej cron úlohy. Žiadne účtovné získavanie nebeží priamo vo verejnej karte ani v tomto REST callbacku. Chyba auditnej tabuľky v samotnom dostupnom Bridge nie je opravená v tomto ZIP-e.

Aktuálne výsledky a obmedzenia: `OVERENIE-2.2.md`; pôvodný protokol RC1 je v `history/`.


### Opakovanie po výpadku v RC3

V blokovom checkoute môžete pri neúspešnom overení použiť tlačidlo „Zopakovať overenie“ alebo pokračovať ručným vyplnením. Súbežné opakované kliknutie nezačne ďalšie získavanie údajov. Po zmene alebo vymazaní IČO sa staré upozornenie odstráni. Automatické dopĺňanie zachová ručne zmenené polia.
