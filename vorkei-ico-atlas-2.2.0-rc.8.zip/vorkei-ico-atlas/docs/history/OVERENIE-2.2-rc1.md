# Overenie Atlas 2.2.0-rc.1

Pracovná verzia k 31. 10. 2026, priebehy s časmi UTC 30. 10. 2026. Distribuovaný ZIP 2.1.0 zostal nezmenený: SHA-256 `c50a1414c308cd7d1ea2bae0408bcfd89b3da390b74ddcfc86f660ac1bc2c472`.

## Izolované regresie

Výsledky používajú dvojníky WordPressu/databázy a zaznamenané alebo výslovne syntetické odpovede. Ide o kontroly konkrétnych scenárov, nie meranie pokrytia každej funkcie.

| Sada | Počet kontrol | Výsledok |
|---|---:|---|
| Pôvodné jadro Atlas 2.1 | 29 | PASS |
| Financie RÚZ | 55 | PASS |
| RPO/ORSR | 18 | PASS |
| FS adaptér | 21 | PASS |
| FirmaBind predvolene vypnutý | 5 | PASS |
| Verejné rozhranie a serverové podanie | 27 | PASS |
| Append-only snímky a migrácia | 20 | PASS |
| Ľahká identita a VIES | 30 | PASS |
| Woo/JetForm adaptéry | 38 | PASS |
| JavaScript formulárov a Woo dátových rozhraní | 31 | PASS |
| **Spolu** | **274** | **PASS** |

Štyri požadované brány sú samostatne pokryté: karta bez profilu nesmie vytvoriť ťažký Client/Enricher; DIČ sa nesmie zmeniť na SK+DIČ; VIES meno `---` bez presného FS dôkazu zostáva withheld; zmena údajov ani opakovaný pokus nesmie aktualizovať payload pôvodnej snímky. Navyše sa kontroluje oddelenie výpadku/invalid, krátka denná VIES cache, SQL projekcia, administrátorský zámok, zachovanie staršieho DIČ, utajenie zdrojových dát a kľúča, limity, leading-zero IČO, prehliadačový podvrh, neporovnané údaje a serverový výber.

Sady spustite v koreňovom priečinku pluginu:

```sh
php tests/run.php
php tests/financials-test.php
php tests/fixtures/registers-check.php
php tests/fixtures/tax-regression.php
php tests/firmabind/off-test.php
php tests/firmabind/submission-rest-test.php
php tests/firmabind/snapshots-test.php
php tests/firmabind/identity-test.php
php tests/firmabind/adapters-test.php
node tests/firmabind/adapters-frontend-test.js
```

PHP harness: PHP8.5.10/WASM. Produkčné súbory prešli kontrolou syntaxe:19 súborov PHP a2 súbory JavaScriptu. Pôvodných123 kontrol zostalo zachovaných; nie je pravda, že boli regresne otestované všetky funkcie vo všetkých kombináciách.

## Skutočný skúšobný WordPress

Lokálna inštalácia cez oficiálny WordPress Playground CLI3.1.61: WordPress7.1.4, PHP8.3.33, WooCommerce11.2.1, JetFormBuilder3.6.8. Oficiálna SQLite integrácia; HPOS skutočne používa `OrdersTableDataStore`, tabuľky `wp_wc_orders` a `wp_wc_orders_meta`. Testovací produkt10EUR, virtuálny, BACS. Reálna platba ani email sa neposielali.

Registračné údaje EB-EU boli do testu prevzaté zo zaznamenaných úradných odpovedí s pôvodnými časmi. Sieťové odpovede prehliadača sa nenahrádzali. Odchádzajúce poskytovateľské HTTP bolo na skúšobnom WordPresse zablokované; táto integračná skúška overuje cache → verejné rozhranie → formulár → server → skutočnú databázu → export, nie živú autorizovanú FS alebo VIES komunikáciu.

| Skúška | Výsledok a konkrétny dôkaz |
|---|---|
| Predvolené OFF | Verejná karta pred zapnutím neexistovala, tabuľka snímok neexistovala. Zapnutie vykonalo migrácie vrátane unikátnych indexov; uložený profil ostal zachovaný. |
| Skutočné REST overenie | 15 kontrol PASS: hosť aj admin so správnymi nonce; presne+1 kvóta na kartu aj pri opakovanom permission callbacku; 12 povolených kľúčov; no-store; chybné IČO400 bez HTTP; anonymný plný lookup/export401; admin export zachoval hash a všetky zákaznícke polia. |
| Klasický checkout | Objednávka17, snímka1. Prehliadač doplnil kartu, IČ DPH zostalo prázdne. Skutočný Woo handler uložil HPOS objednávku on-hold. Snímka zachovala zákaznícky názov „Manual company before submit“, registrový názov a `diverged`; objednávka používa doložený serverový názov. |
| Blokový checkout | Objednávka18, snímka2. Skutočné Additional Checkout Fields a Woo dátové rozhranie doplnili údaje; BACS objednávka10EUR prijatá. Overená natívna metadátová hodnota IČO/DIČ, prázdne VAT, kópia payloadu, SHA-256 pôvodných JSON bytov, HPOS tabuľky a jediná snímka objednávky. |
| JetFormBuilder | Úspešný celý tok karta200 → autofill → podanie200. Formulár13, záznam2, snímka4; následných13 databázových kontrol PASS. Zákaznícky názov je zachovaný v snímke ako pôvodný vstup, záznam používa serverom vybranú hodnotu. Podvrhnuté ID99999999 sa nahradilo serverovým4; nevznikli vedľajšie polia `_1`. |
| Neskoršie zmeny a úplnosť snímky | PASS: úprava billing adresy/mesta objednávok17/18 zachovala pôvodný JSON, hash a HPOS kópiu. Opätovné uloženie profilu Atlas cez Enricher zachovalo všetky4 testovacie snímky. Zachytených0 UPDATE požiadaviek na tabuľku snímok; úplný administrátorský JSON export zachoval obsah. |

Prvé skúšobné pokusy zachovali aj chyby testovacieho prostredia: nesprávne ID akcie v pripravenom JetForm formulári, chýbajúci povinný telefón v blokovom testovacom vstupe a chyba Playwright záznamníka pri čítaní response body po navigácii. Po ich identifikácii sa nezamieňali za chybu získavania údajov. Skutočná JetForm skúška navyše odhalila chybu adaptéra: `Action_Handler::add_request()` pri akčnom cykle pridávalo príponu `_1`. Oprava používa API kontextu na prepis parsera aj pôvodného requestu; nová regresia modeluje obe vrstvy a finálne podanie overilo skutočný uložený záznam. Snímky/objednávky sa overovali aj nezávislým čítaním skutočnej databázy; klasický tok mal13 a blokový18 dodatočných kontrol PASS.

Pri súbežných prehliadačoch a šiestich WP workeroch sa lokálne prostredie dostalo pod tlak pamäte a formulár dosiahol8s klientsky timeout; správne ponúkol ručné pokračovanie. Finálne UI skúšky sa preto vykonávali postupne; záverečný úspešný JetForm autofill aj podanie bežali s dvoma workermi. Samostatná identitná služba po načítaní WordPressu namerala3ms a0 odchádzajúcich HTTP pokusov pri teplej cache. HTTP časy samostatnej karty6259ms/4598ms zahŕňajú štart WordPressu vo WASM: nepreukazujú štvorsekundovú odozvu celého webu. Kód obmedzuje získavanie identity spoločným sieťovým rozpočtom3,7s a VIES samostatným timeoutom3s. Výkon pri cache miss na cieľovom hostingu treba samostatne zmerať.

## Neoverené časti a hranice

- Natívny PHP8.1 a skutočný MySQL/MariaDB upgrade existujúcej produkčnej databázy. Lokálne skúšky používali SQLite; pôvodná migrácia je navyše pokrytá izolovanou regresiou.
- Reálna autorizovaná FS komunikácia s kľúčom konkrétneho zákazníka a živé VIES odpovede pre jeho skutočne vydané číslo. Pozitívne/negatívne/withheld/failure scenáre v regresiách sú označené ako syntetické; pre EB-EU sa žiadne IČ DPH nevymyslelo.
- Cieľová téma, ostatné checkout úpravy, platené brány, nastavovanie daní podľa miesta a všetky varianty kupónov/vrátení/opakovaných platieb. Modul sám nepriznáva oslobodenie DPH ani netvorí faktúru. Serverová zmena billing identity vyžaduje osobitné overenie pri pravidlách závislých od PSČ či mesta.
- Reálny JetEngine CCT, Vorkei Bridge a externá registračná mikroslužba používateľa nie sú súčasťou lokálnej inštalácie; ich existujúci kód zostal zachovaný. Verejný checkout ich nespúšťa.
- Zaťaženie a garantovaný celkový čas na cieľovom serveri; obnova po páde procesu medzi INSERT snímky a uložením objednávky; automatické riadenie retencie a mazanie historických snímok.

Balík ostáva `2.2.0-rc.1`. Na predajnú verziu treba uzavrieť relevantné skúšky na cieľovej skúšobnej kópii webu. Zoznam funkcií ani pripravený adaptér sa nevydáva za overenie všetkých poskytovateľov a všetkých používateľských konfigurácií.

Verejná karta zo skutočnej záverečnej snímky JetForm prešla aj validáciou priloženou JSON schémou s odmietnutím nepovolených polí.

Záverečná drobná oprava deduplikuje rovnaké IČO pri input/blur/change a zachová vyriešený stav. Samostatná regresia overuje jeden naplánovaný/bežiaci/dokončený dotaz a možnosť opakovať neúspešný dotaz.
