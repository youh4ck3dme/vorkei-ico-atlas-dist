# VORKEI IČO ATLAS2.2.0-rc.2 – overenie a opravy

Stav k 2026-10-31T01:31:04.630405+00:00. **Verdikt vydania: FAIL.** Funkčné finálne sady prešli, ale požadované pokrytie riadkov/vetiev a externé závislosti nie sú uzavreté. Tento balík sa neoznačuje za „99 % otestovaný“. Pokrytie nie je pravdepodobnosť bezchybnosti.

## Podklady a prostredie

Pracovná kópia: `/home/vorkei/Documents/Codex/2026-10-30/vyt/work/atlas22/vorkei-ico-atlas`. Všetky štyri dodané podklady boli prítomné. Táto2.2 kópia nemá vlastný Git repozitár. Súvisiaci `/home/vorkei/Documents/pdf-t3-vorkei` obsahuje starší Atlas1.0; nebol prepísaný. Projektové a osobné AGENTS.md boli prečítané. Inventár je v [inventory.json](/home/vorkei/Documents/Codex/2026-10-30/vyt/outputs/atlas22-rc2-qa/reports/inventory.json). Zdroj registračnej mikroslužby sa nenašiel.

Natívny test: **WordPress7.1.4, PHP8.5.4, MariaDB11.8.6, WooCommerce11.2.1, JetFormBuilder3.6.8, Bridge1.0.0**. Skutočný HPOS `OrdersTableDataStore`, `wc_orders`, `wc_orders_meta`, synchronizácia do posts vypnutá. Najnižšie deklarované PHP8.1 a WordPress6.2 boli overené samostatne; Woo11.2.1 vyžaduje WP7.0, preto nebol násilne spustený na WP6.2. Izolované PHP sady prešli na oboch PHP verziách.

Všetky skúšobné servery počúvali iba na loopback. Email a externé požiadavky boli na skúšobnom webe blokované; výnimkou bol samostatný čisto čítací živý smoke s presným zoznamom troch oficiálnych hostov. Objednávky používali virtuálny produkt a offline BACS. Poruchové a záťažové scenáre smerovali iba na lokálnych dvojníkov. Žiadna produkcia sa nemenila. RC2 SQLite sa nespúšťal; staršie RC1 SQLite výsledky sú iba archív.

## Skutočné pokrytie

| Jazyk | Riadky (cieľ99 %) | Volané funkcie/metódy vrátane anonymných (cieľ99 %) | Vetvy (cieľ95 %) | Verdikt |
|---|---:|---:|---:|---|
| PHP | 1859/1918 = 96.9239 % | 198/199 = 99.4975 % | 2367/2818 = 83.9957 % | FAIL |
| JavaScript | 204/204 = 100.0000 % | 62/62 = 100.0000 % | 264/332 = 79.5100 % | FAIL |

PHP zahŕňa všetkých19 vlastných produkčných súborov a JS oba vlastné súbory. Administrácia, chybové vetvy ani ťažké triedy sa nevylúčili. Vylúčené sú iba cudzie závislosti, testy a dátové podklady; CSS nemá vykonateľné PHP/JS riadky a overoval sa v prehliadači. Riadkový menovateľ sa inicializuje úplnou statickou analýzou pred čiastkovými behmi. Aktuálny SHA-256 každého zdrojového súboru je podmienkou zlúčenia raw dát.

PHP: Xdebug3.5.0, `phpunit/php-code-coverage12.5.8`. Stock engine pri enumerácii všetkých ciest explodoval. Použitý lokálny voliteľný patch vypína iba enumeráciu/sledovanie úplných ciest, zachováva CFG a čítače riadkov/vetiev. Patch aj oficiálny zdroj sú priložené. Pri porovnaní stock a upraveného engine sa zhodovali branch/edge/line čítače kalibračného podkladu; **stock line-only engine sa navyše zhodoval na všetkých11 deterministických PHP sadách**. Toto nie je dôkaz ekvivalencie pre ľubovoľný program. Pokrytie úplných ciest sa nevykazuje.

Všetkých178 pomenovaných jednotiek v štandardnom reporte bolo zavolaných. „Methods“ v štandardnom HTML reporte znamená plne pokrytú metódu: 82/178 = 46.0674 %. Tento prísnejší údaj sa nezamieňa s jednoduchým zavolaním funkcie. Menovateľ199 pre funkcie zahŕňa aj anonymné/arrow deklarácie a bol porovnaný s tokenovým inventárom.

JavaScript: Istanbul instrumentácia6.0.3, coverage map3.2.2, skutočný Chromium plus izolované hodiny/DOM/Woo stores. Výkazy uvádzajú aj samostatné statement coverage.

Presne zostáva **59 PHP riadkov, 451 PHP vetiev a 68 JS vetiev** bez zásahu. Funkčné medzery a zdrojové riadky sú v [PHP gaps](/home/vorkei/Documents/Codex/2026-10-30/vyt/outputs/atlas22-rc2-qa/reports/php-coverage-gaps.json), [PHP runtime funkcie/vetvy](/home/vorkei/Documents/Codex/2026-10-30/vyt/outputs/atlas22-rc2-qa/reports/php-runtime-functions.json) a [JS gaps](/home/vorkei/Documents/Codex/2026-10-30/vyt/outputs/atlas22-rc2-qa/reports/js-coverage-summary.json). HTML: [PHP](/home/vorkei/Documents/Codex/2026-10-30/vyt/outputs/atlas22-rc2-qa/php/index.html), [JavaScript](/home/vorkei/Documents/Codex/2026-10-30/vyt/outputs/atlas22-rc2-qa/javascript/index.html). Konfigurácia a raw záznamy sú v QA balíku.

## Vykonané skúšky

Pôvodný RC1 ZIP bol osobitne rozbalený a znovu vykonal **274/274 pôvodných kontrol**. Aktuálna verzia má **285 izolovaných PHP kontrol na každej z dvoch PHP verzií** a **38 JS assertions**. Finálny runner: 46/46 úspešných procesov vrátane integrácií a priamych vstupných guardov. Počet kontrol neurčuje percento pokrytia.

- Reálna čistá inštalácia OFF, zapnutie, vypnutie/opätovné zapnutie, aktualizácia už aktívneho pôvodného2.1 bez reaktivácie a opakované migrácie. JSON bajty, nulové prefixy a pôvodné manuálne CCT hodnoty zachované.
- Reálna MariaDB: zamietnuté vytvorenie tabuľky/stĺpcov/indexov, duplicita pri pridávaní UNIQUE, neoznačenie chyby za dokončenú migráciu a bezpečné oznámenie bez pádu frontendového načítania.
- Skutočné klasické a blokové objednávky s HPOS; skutočný JetForm Save Form Record. B2B, spotrebiteľ, ručné údaje pri výpadku a zmeny po autofille. Overili sa riadky, CRUD meta, pôvodné a efektívne údaje, serverové ID, žiadne `_1` polia a export.
- Blocks PUT a neúspešná serverová validácia nevytvorili prijatú snímku. JetForm neplatný vstup pri obídení kontroly v prehliadači nevytvoril úspešný Record ani dôkaz.
- Hosť aj prihlásená relácia, oba nonce, chýbajúci/neplatný/skutočne expirovaný nonce, chybný JSON, nepovolené metódy a zákaz administrátorského lookup/exportu pre návštevníka/zákazníka.
- Falošné browserové ID/payload/hash/VIES ignorované, plný profil nikdy nie je verejnou kartou. Názov, adresa a DIČ nezávisia od VIES. SK+DIČ sa nevyrába.
- Cron pokračovanie bolo vykonané v samostatných DOING_CRON WordPress procesoch bez prihláseného správcu: rovnaký job ID, rastúci offset, dokončené fázy a správne preplánovanie/spotrebovanie udalostí. Dispečing bol ručný, bez čakania na nástenné hodiny.
- Skutočné4 súbežné INSERT, konkurenčná väzba na dve objednávky, UNIQUE a zachovanie hash; zámerný pád po INSERT a obnova rovnakého pokusu. Skutočný SQL zápis sleduje jediný povolený UPDATE na NULL order_id. Neskoršia zmena billing/profilu a opakovaný offline Woo payment lifecycle nemenia JSON bajty.
- Skutočné kvóty:3 z12 požiadaviek prejdú,9 dostane429, pre IP aj webový deň; podvrhnutý X-Forwarded-For nepomôže. Expirácia SQL počítadiel a čistý permission callback sa overili.
- VIES valid/invalid/unavailable/not_checked; prázdne HTTP200, HTML, nesprávne echo/namespace, zlé XML a DTD/XXE; skryté meno, presný dôkaz FS, samostatná väzba, čerstvosť a UTC deň.
- Atlas RPO/ORSR/FS/RÚZ a finančné regresie nad kontrolovanými podkladmi vrátane histórie/presunutého spisu, neporovnateľných období a meny, riadkov šablóny, null/0, nulového menovateľa a deduplikácie. Reálne HTTP JSON, evidence CSV a financial CSV nad dodaným historickým profilom.
- Mobil390px, klávesnica Enter, načítavacie stavy, odpovede v opačnom poradí, opakovaný blur/change, manuálna zmena počas požiadavky a obnovenie po chybe.
- Päť dočasných mutácií bolo zabitých významovými assertions: vymyslené VAT, únik profilu, unavailable→invalid, vedľajší účinok permission kvóty a UPDATE payloadu. Pôvodné zdroje zostali po mutáciách zhodné.

Pred dopĺňaním testov bola uložená matica153 lokálnych scenárov. Tie sú teraz153/153 PASS podľa pripojeného druhu dôkazu; časť sú unit testy, časť skutočná integrácia. Ďalšie pokrytie a závislosti sú explicitné samostatné brány. Kompletná [matica požiadavka→test→výsledok→dôkaz](/home/vorkei/Documents/Codex/2026-10-30/vyt/outputs/atlas22-rc2-qa/reports/requirements-matrix.csv) sa neskracuje na zelený počet.

## Opravy a regresie

| Oprava | Dôkaz regresie |
|---|---|
| Nereťazcové IČO už nespadne do spotrebiteľa; adaptéry zachovajú neplatný typ ako neplatný vstup | hardening-before/after; final-php-hardening-test; skutočné REST typy |
| Vek identity a jednotlivých dôkazov sa posudzuje pri čítaní cache; staršie údaje neprepisujú novší ručný vstup | hardening-before/after; identity/submission; reálne snímky pri výpadku |
| Poškodené RPO štruktúry/typy nespôsobia výnimku checkoutu | hardening-before/after; malformed provider cases |
| SQL UNION používa spoločnú ASCII koláciu a zachová IČO s nulami | collation-before-after.json: pôvodný SQL zlyhá, RC2 deduplikuje |
| Migrácie overujú stĺpce, PRIMARY, UNIQUE a index expirácie; core zlyhanie nepadá na frontende a zostáva opakovateľné | migrations-before, core-migration-before, primary-before-after, final-migrations |
| Bridge1.0 má kompatibilné zaradenie úlohy po úspešnom REST sync bez chýbajúceho hooku | bridge-before/after; skutočný Bridge callback a neduplikovaná úloha |
| Nepodporovaný slovenský formát IČ DPH nevolá VIES | vies-faults-before/after a finálna sada |
| Neplatný typ API kľúča FS už neprepíše uložený serverový kľúč na text Array | admin-key-before.json; final-extra invalid FS key type |
| Hlavička/tlačidlá sa zmestia do mobilu; WordPress oznámenia majú vlastný wp-header-end mimo značkovej hlavičky | mobile-before.json/png; browser-jet-mobile a aktuálny screenshot |

## Migrácie a kontrakty

Core DB `2.1→2.1.1`: overenie všetkých povinných stĺpcov, PRIMARY(id), UNIQUE uq_ico(ico); bez prepisovania pôvodných profilov. Konfliktné staré duplicity sa nemažú automaticky a verzia sa nezvýši. FirmaBind `1.0→1.1`: kontrola PRIMARY(id) a existujúcich troch UNIQUE snímok; limity kontrolujú stĺpce, PRIMARY(bucket), expires_at index. Tieto dve migrácie bežia iba pri zapnutom module. API profil ostáva `2.1`, verejná karta `1.0`, payload snímky `firmabind/1.0`. Kontrakty sú v docs; opakované záznamy sa exportom nezahadzujú. CSV je typovo jednoduchý formát: IČO pri importe do tabuľkového procesora zvoľte ako text, autoritatívne typy zachová JSON.

## Výkon

PHP8.5 bez Xdebug, natívny WordPress/Woo/JFB/Bridge, MariaDB, sekvenčný loopback. „Služba“ meria REST callback po načítaní WordPressu, vrátane kvóty a projekcie; nie samotný čas celého webu. Teplá cache bola najprv naplnená mimo vzorky. Studená sa mazala pred každou vzorkou. P95 je nearest rank ceil(0.95*n); malé počty sú priznané.

| Podmienka | n | Služba p50/p95/max ms | Celé HTTP p50/p95/max ms | Požiadavky dvojníku |
|---|---:|---:|---:|---:|
| cold | 8 | 54.068/72.165/72.165 | 240.532/1789.718/1789.718 | 24 |
| warm | 12 | 12.823/18.657/18.657 | 148.691/169.254/169.254 | 0 |
| lock | 8 | 15.064/22.392/22.392 | 160.31/217.048/217.048 | 0 |
| 429 | 6 | 36.621/42.24/42.24 | 225.531/250.555/250.555 | 6 |
| slow | 5 | 1241.581/1242.939/1242.939 | 1424.881/1448.053/1448.053 | 5 |
| slowchain | 5 | 3363.607/3374.586/3374.586 | 3567.335/3649.669/3649.669 | 15 |
| limit | 6 | 1.032/1.2/1.2 | 138.79/149.672/149.672 | 0 |

Súbeh:6 klientov/4 pracovníci s coverage zapnutým,24 požiadaviek; celé HTTP p50 1419.4055ms, p95 2551.417ms, max 2736.991ms. Tieto časy nemožno porovnávať s vypnutou instrumentáciou ako totožné podmienky. Pomalá trojica zdrojových volaní ostala v meranom3.7s rozpočte služby; z toho sa nerobí všeobecná garancia štvorsekundovej odozvy každého webu.

## Zostávajúce závislosti a obmedzenia

- Požadované percentá PHP riadkov/vetiev a JS vetiev neprešli. Konkrétne medzery sú priložené; ťažké miesta neboli odstránené z menovateľa.
- FS nemá dodaný skutočný API kľúč a potvrdené datasety. Platnosť VIES a väzba na firmu sú overené kontrolovanými podkladmi, nie novým živým dôkazom FS.
- Pri živom pokuse prešiel RPO a objavenie účtovnej jednotky RÚZ. ORSR hlásil TLS EOF a detail RÚZ reset spojenia. To je výsledok konkrétneho pokusu v tomto prostredí; nepovažuje sa za nenájdenú firmu ani za trvalý stav registra. Podrobnosti: live-public.json.
- Licencovaný JetEngine nebol dostupný. Fyzické CCT SQL, mapovací filter a zachovanie ručných hodnôt prešli; skutočnú registráciu polí a UI/metadáta JetEngine nemožno vyhlásiť za overené.
- Zdroj a prístup registračnej mikroslužby nie sú dostupné. Plný proxy kontrakt má lokálne regresie, backendový end-to-end zostáva otvorený.
- Dostupný Bridge1.0 vytvára `vorkei_audit_log`, ale pri sync číta/zapisuje `vorkei_audit_logs`. Atlas vlastnú pokračovaciu úlohu neduplikuje; chybu Bridge samotného tento balík neopravuje.
- Chýba cieľový existujúci staging web a jeho baseline. Kompletnú regresiu jeho konkrétnych rozšírení/stránok nemožno nahradiť lokálnym testovacím webom.
- Rozšírený katalóg zdrojov A–N, prázdne skupiny profilu, Doklad Core a licenčný server sa nevydávajú za hotové konektory alebo funkcie tejto verzie.
- PHP8.5 vypísal deprecation upozornenia pochádzajúce z JetFormBuilder migrácií; vlastný plugin prešiel. Riešenie týchto cudzích upozornení sa nepripisuje Atlasu.

## Verdikty kritických oblastí

| Oblasť | Verdikt | Presný rozsah |
|---|---|---|
| Inštalácia / aktívna aktualizácia / OFF / migrácie | PASS | Skutočné WordPress6.2/PHP8.1 + MariaDB; pôvodný2.1 aktívny plugin, hodnoty a JSON zachované. |
| Malá identita / typy / cache / verejný kontrakt | PASS | Izolované regresie, skutočný WP REST a explicitná SQL projekcia; žiadny plný lookup v podaniach. |
| VIES význam a XML odolnosť | PASS | Kontrolované SOAP podklady; všetky4 stavy a matched/mismatch/withheld. Živá autorizovaná väzba FS nie je doložená. |
| Snímky / SQL / súbeh / pád / opakovaný životný cyklus platby | PASS | Reálna MariaDB, HPOS CRUD, nemenné bajty/hash a jednorazová väzba. Platba bola iba lokálny Woo lifecycle, bez bankovej transakcie. |
| Klasický checkout / Blocks / JetForm Record | PASS | B2B aj spotrebiteľ a výpadok; skutočné objednávky a Records; neplatné podanie odmietnuté, PUT a zlá validácia bez prijatej snímky. |
| Atlas regresie / súbory a HTTP export | PASS | Účtovné roky, proveniencia, zdrojové riadky, null/0, meny a neporovnateľné obdobia v kontrolovaných podkladoch; skutočné HTTP exporty. |
| Riadené bezpečnostné scenáre / kvóty | PASS | XSS, SQL vstup, pevné HTTP ciele, DTD/XXE, nonce/role, úniky a súbeh podľa matice. Nejde o všeobecnú certifikáciu bezpečnosti. |
| Mobilná administrácia / klávesnica | PASS | Nájdený presah a presunuté oznámenia opravené;390px viewport a Enter overené. |
| Výkon | PASS | Merania nižšie; oddelený čas služby a celého HTTP, lokálni dvojníci, žiadny záťažový test verejných registrov. |
| Požadované percentá pokrytia | FAIL | PHP riadky a vetvy a JavaScript vetvy nedosiahli cieľ. |
| Licencovaný JetEngine / živá FS / registračná mikroslužba | BLOCKED | Balík/prístup/zdroj backendu nebol dodaný. Fyzické CCT SQL nie je náhrada za registráciu polí JetEngine. |
| Úplná živá registrácia ORSR a detail RÚZ | BLOCKED | Pri samostatnom živom smoke pokuse spojenie skončilo TLS EOF / connection reset; RPO a objavenie RÚZ jednotky prešli. |
| Bridge1.0 vlastná idempotencia | BLOCKED | Nesúlad audit_log vs audit_logs v dostupnom Bridge. Atlas kompatibilný callback a neduplikovanie vlastnej cron úlohy prešli. |
| Existujúci zákaznícky web – kompletná regresia | BLOCKED | Chýba cieľová staging kópia a jej východiskový stav. Lokálny pripravený web a OFF scenáre sú overené. |

## Reprodukcia a artefakty

[Reprodukčné kroky](/home/vorkei/Documents/Codex/2026-10-30/vyt/outputs/atlas22-rc2-qa/QA-REPRO.md), [strojové výsledky](/home/vorkei/Documents/Codex/2026-10-30/vyt/outputs/FirmaBind-2.2-rc2-vysledky.json), [matica JSON](/home/vorkei/Documents/Codex/2026-10-30/vyt/outputs/atlas22-rc2-qa/reports/requirements-matrix.json). QA ZIP obsahuje testy, raw coverage, HTML reporty, screenshoty, konfiguráciu, lock súbory a patch engine; neobsahuje prihlasovacie údaje, databázu, WordPress konfigurácie ani globálne runtime inštalácie. Pôvodný distribuovaný2.1 a pôvodný RC1 ZIP sú zachované. Výsledný inštalačný ZIP a SHA-256 sú v `SHA256SUMS-2.2-rc2.txt`.
