# VORKEI IČO ATLAS 2.2.0-rc.7

**Verdikt: BLOCKED pre stabilný predaj.** RC.7 opravuje tri dokázané chyby. Nie je to vydanie na predaj.

Tento beh nenašiel všetky chyby. Pokrytie riadkov, funkcií a vetiev sa nemeralo. WordPress, MariaDB, WooCommerce, HPOS za behu, JetForm a živé registre sa nespúšťali.

## Čo sa zmenilo oproti 2.2.0-rc.6

- FirmaBind pri verejnej karte porovnáva identifikátor RPO cez `same_ico`. Celé číslo z JSON s chýbajúcou úvodnou nulou sa zhoduje s osemmiestnym IČO. Reťazec kratší ako 8 číslic sa nedopĺňa.
- Uložený profil s číselným IČO sa dá premietnuť na kartu. Výstupné IČO ostáva osemmiestny text.
- Dávka nepočíta rozpracované získavanie ako zlyhanie. Počítadlo sa zvýši až keď beh skončí, alebo keď pokus prekročí strop opakovania.
- Nástenka už nehovorí, že súčet sú len Customers, Contractors a Clients, ani že prázdny zoznam znamená chýbajúce tabuľky JetEngine.

FirmaBind ostáva predvolene vypnutý.

## Čo predaj stále blokuje

WordPress 6.2 aj aktuálny, MariaDB, čistá inštalácia, update z 2.1 a z tohto ZIP, multisite, Woo classic, Blocks, HPOS za behu, JetForm Call Hook, Xdebug alebo PCOV, živé FS/VIES/RPO/ORSR/RÚZ, obnova databázy podľa `docs/OBNOVA.md`.
