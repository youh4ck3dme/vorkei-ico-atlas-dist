# Reprodukcia Atlas RC2 QA

Pracovná kópia je `work/atlas22/vorkei-ico-atlas`, izolované prostredie `work/atlas22/qa`. Skripty pracujú výhradne s vlastnými databázami `atlas_qa_current`, `atlas_qa_min`, `atlas_qa_upgrade`. Nespúšťajte ich s produkčným `ATLAS_WP_ROOT`. Testy úmyselne menia svoje objednávky, nastavenia a vlastné dočasné tabuľky.

Existujúca pracovná kópia obsahuje extrahované runtime balíky a závislosti. Globálny PHP ani databázová služba sa nemenili. Po odovzdaní sú skúšobné servery zastavené. Obnovenie v tej istej pracovnej kópii:

```bash
cd /home/vorkei/Documents/Codex/2026-10-30/vyt
python3 work/atlas22/qa/restart-database.py
python3 work/atlas22/qa/start-native.py
python3 work/atlas22/qa/run-final.py
node work/atlas22/qa/coverage/js-baseline.cjs
node work/atlas22/qa/coverage/run-frontend-baseline.cjs
node work/atlas22/qa/browser-qa.cjs
ATLAS_WP_ROOT="$PWD/work/atlas22/qa/site-current" ATLAS_QA_ROOT="$PWD/work/atlas22/qa" work/atlas22/qa/bin/php work/atlas22/vorkei-ico-atlas/tests/integration/browser-db.php
node work/atlas22/qa/browser-variants.cjs
ATLAS_WP_ROOT="$PWD/work/atlas22/qa/site-current" ATLAS_QA_ROOT="$PWD/work/atlas22/qa" work/atlas22/qa/bin/php work/atlas22/vorkei-ico-atlas/tests/integration/variants-db.php
node work/atlas22/qa/admin-browser.cjs
node work/atlas22/qa/browser-jet-mobile.cjs
ATLAS_WP_ROOT="$PWD/work/atlas22/qa/site-current" ATLAS_QA_ROOT="$PWD/work/atlas22/qa" work/atlas22/qa/bin/php work/atlas22/vorkei-ico-atlas/tests/integration/jet-variants-db.php
python3 work/atlas22/qa/toggle.py
python3 work/atlas22/qa/cron.py
python3 work/atlas22/qa/concurrency.py
python3 work/atlas22/qa/mutations.py
python3 work/atlas22/qa/performance.py
ATLAS_XDEBUG_BRANCH_ONLY=1 work/atlas22/qa/bin/php work/atlas22/qa/coverage/report.php
python3 work/atlas22/qa/coverage/runtime-gaps.py
work/atlas22/qa/bin/php work/atlas22/qa/coverage/function-inventory.php
node work/atlas22/qa/coverage/js-report.cjs
python3 work/atlas22/qa/matrix.py
```

Databázové, kvótové, prepínacie, výkonnostné a prehliadačové sady spúšťajte postupne. Menia spoločné nastavenia vlastného skúšobného webu. `run-final.py` počíta neúspech aj podľa návratového kódu; preskočený scenár sa nenahrádza PASS. Po opakovanom spustení vzniknú ďalšie vlastné QA objednávky.

`browser-qa.cjs` musí predchádzať `browser-db.php`: druhý krok overuje aktuálne uložené ID z prvého. `variants-db.php` zasa číta aktuálny výsledok `browser-variants.cjs`. Testovací účet je iba v lokálnom `.credentials.json` s právami0600. Tento súbor nie je v odovzdávaných ZIP-och.

Výkon používa ďalší server127.0.0.1:9426 bez Xdebug a lokálneho dvojníka127.0.0.1:9425. Oba sa zatvoria vo `finally`. Primárny web je127.0.0.1:9424, MariaDB127.0.0.1:9436. Žiadne testovacie služby nepočúvajú na0.0.0.0. MU plugin `atlas-qa.php` blokuje emaily a externé HTTP; súbory poskytovateľov sú riadené podklady. Woo používa virtuálny produkt a offline BACS. Test `payment_complete` overuje lokálny životný cyklus Woo, neposiela platbu do banky.

## Nové čisté prostredie

QA balík obsahuje testy, skripty, lock súbory, manifest runtime balíkov a pokrytie. Neobsahuje WordPress konfiguráciu, prístupové údaje, databázové dáta ani runtime binárky. Pre nové zariadenie pripravte oficiálny WordPress7.1.4/Woo11.2.1/JetFormBuilder3.6.8, PHP8.5.4 s rozšíreniami podľa php.ini a MariaDB11.8.6. Nastavte výhradne skúšobný web a lokálny administrátorský účet; pripojte pracovný plugin. Pluginy a HPOS pripraví `setup-current.php`; testovacie stránky, produkt a formulár vytvára `make-sites.php`; permalink a tému nastaví `fix-test-site.php`. Už pripravený web používa ID z `reports/site-ids.json`; na novom webe treba tieto ID obnoviť setup skriptom. Absolútne cesty v php.ini upravte podľa nového QA adresára. Playwright je pripnutý v QA/js lock súbore; jeho prehliadač možno pripraviť cez `pnpm --dir QA/js exec playwright install chromium`. Pri vlastnom umiestnení binárky nastavte `ATLAS_CHROMIUM`; použitá presná verzia je v environment.json.

Závislosti coverage: `composer install` v QA adresári podľa composer.lock; `pnpm install --frozen-lockfile` v QA/js podľa pnpm-lock.yaml. Tieto príkazy obnovujú iba QA závislosti. Natívne prostredie tohto behu vzniklo extrakciou oficiálnych Ubuntu `.deb` balíkov pomocou `dpkg-deb -x` do runtime a runtime81. Manifest verzií a SHA je `reports/runtime-lock.json`; oficiálny zdroj Xdebug3.5.0 a patch sú priložené.

Štandardný Xdebug pri zapnutom počítaní všetkých ciest na tomto kóde explodoval pri enumerácii. Voliteľný lokálny patch vypína iba enumeráciu a sledovanie úplných ciest, zachováva CFG, branch/edge a line hit čítače. Režim sa zapína `ATLAS_XDEBUG_BRANCH_ONLY=1`; nevykazuje pokrytie ciest. Porovnanie so stock engine na oboch vetvách kalibračného podkladu je v `reports/engine-validation.json`. Patch a zdrojový archív umožňujú audit; vlastné zmeny engine sú výslovne priznané. Coverage pôvodného engine možno zopakovať pre riadky bez `XDEBUG_CC_BRANCH_CHECK`.

Agregátor najprv inicializuje všetky vlastné produkčné PHP súbory cez statickú analýzu php-code-coverage. Tým neúplný beh s priamym vstupným guardom nezmenší menovateľ. Anotácie ignorovania sú vypnuté. Z raw záznamov sa pre každý súbor prijíma len zhodný SHA-256 aktuálneho zdroja. Chýbajúce funkcie/riadky zostávajú v menovateli. Administrácia, chyby a ťažké triedy sa nevylučujú. Započítané sú všetky19 vlastných PHP a oba vlastné JS súbory; vylúčené sú iba testy, závislosti a dátové podklady. CSS nie je vykonateľný programový kód tohto coverage nástroja.

Jednorazový živý smoke sa úmyselne nespúšťa v záťažovej sade. Samostatný `tests/integration/live-public.php` uvoľní v jedinom CLI procese iba presný whitelist RPO/ORSR/RÚZ pre niekoľko čítacích požiadaviek; jeho výsledok je v live-public.json. FS ani neschválený backend nevolá.

Použitý prehliadač: Google Chrome for Testing156.0.8078.4, build1248, ovládač Playwright1.64.0-alpha-1790635538000. QA závislosť je pripnutá a lokálna; `browser-runtime.cjs` zvolí tento už existujúci cache build, alebo explicitný ATLAS_CHROMIUM. Na novom stroji možno použiť pripnutým Playwrightom nainštalovaný predvolený Chromium; ide však už o odlišnú kombináciu, ktorej výsledky treba vykonať znovu.

Kalibrácia proti stock engine: `python3 work/atlas22/qa/coverage/stock-calibrate.py`. Tento doplnkový krok overil zhodu pozitívnych line hit množín všetkých11 deterministických PHP sád.
