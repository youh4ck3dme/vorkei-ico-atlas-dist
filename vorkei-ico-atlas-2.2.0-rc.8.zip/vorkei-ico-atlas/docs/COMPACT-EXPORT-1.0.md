# Kompaktný export IČO ATLAS – atlas-compact/1.0

Táto dokumentácia opisuje implementovaný formát `compact_json` v RC4. Vychádza z `Vorkei_Ico_Atlas_Export`, exportnej REST route, načítania uloženého profilu a jeho spoločného súhrnu. Je to dokumentácia dátového kontraktu, nie protokol testov.

## Prístup a parametre

```text
GET /wp-json/vorkei-ico/v1/export?format=compact_json&ico=51226511
GET /wp-json/vorkei-ico/v1/export?format=compact_json&ico=51226511&history=true
GET /wp-json/vorkei-ico/v1/export?format=json&ico=51226511
```

Route je chránená rovnakou kontrolou ako úplný export: používateľ musí mať WordPress capability `manage_options`. Bez prihlásenia vracia kontrola oprávnení chybu `rest_forbidden` so stavom 401; prihlásenému používateľovi bez tejto capability so stavom 403. Samotný parameter `format`, `history` ani odkaz v exporte oprávnenie neudeľuje. Pri prihlasovaní WordPress cookie sa používa aj štandardná REST autentifikácia s nonce; administrátorské odkazy v plugine odovzdávajú `_wpnonce`.

| Parameter | Implementované správanie |
| --- | --- |
| `format=compact_json` | Vráti DTO s `schema_version: "atlas-compact/1.0"`. |
| `history` | WordPress boolean parameter s validáciou `rest_is_boolean` a sanitizáciou `rest_sanitize_boolean`; predvolene `false`. Príklad rozšíreného pohľadu je `history=true`. |
| `ico` | Ak má presne osem číslic, export vyberie toto IČO. Ak chýba alebo nemá presne osem číslic, aktuálny handler vyberie všetky uložené IČO; nejde o parameter s chybovou odpoveďou 400 pri nesprávnom formáte. |
| `format=json` alebo vynechaný `format` | Zachovaný úplný JSON export so schémou `2.1`, `count` a `items`. |

Handler načíta uložené súhrny cez `Enricher::load()`. Toto načítanie premietne uložené dôkazy cez migráciu, finančnú normalizáciu a `Profile::summarize()`. Exportná route pritom nezačína nové vyhľadávanie v externých registroch. Samotné `Export::compact()` nepočíta nové finančné ukazovatele ani nepreveruje ich ekonomickú správnosť: mení reprezentáciu existujúcich výkazov, faktov a metrík.

## Obálka odpovede

```json
{
  "schema_version": "atlas-compact/1.0",
  "view": "normalized_financial_evidence",
  "history_included": false,
  "full_json_archive": {
    "format": "json",
    "available": true,
    "description": "Úplný pôvodný JSON export obsahuje aj zdrojové finančné výkazy a šablóny."
  },
  "count": 0,
  "items": []
}
```

`count` je počet exportovaných súhrnov firiem. Nie je to počet výkazov, faktov ani úspešných overení.

`full_json_archive` oznamuje dostupnosť úplného formátu na tej istej chránenej route s `format=json`. Neobsahuje URL samostatne vytvoreného súboru, nesľubuje verejné zdieľanie a neobchádza oprávnenia. Kompaktný pohľad sa nepovažuje za náhradu úplného zdrojového archívu.

Každý `items[i]` zachováva pôvodné súhrnné polia, napríklad `ico`, `name`, `dic`, stavy a `profile`, ak boli prítomné. Exportér chýbajúcu identitu alebo chýbajúci profil nedopĺňa vymyslenými hodnotami. Vždy pridá:

```json
{
  "financials": {
    "reports": {},
    "facts": {},
    "metrics": {}
  }
}
```

Tieto tri položky sú slovníky JSON objektov, aj keď sú prázdne. Identifikátory sa vyhodnocujú v rámci rovnakého `items[i].financials`; klient nemá odkaz hľadať v inej firme.

## Zachovaný profil

`profile.fields`, `profile.observations`, `profile.checks`, `profile.conflicts` a nefinančné skupiny zostávajú súčasťou exportu. Mapové kľúče môžu byť usporiadané inak; hodnoty a poradie zoznamov sa tým nemenia.

Zmeny reprezentácie finančnej časti sú tieto:

- `profile.groups.financials.records` sa nahradí zoznamom `report_refs`.
- `profile.groups.financials` zachová svoje stavové a ostatné metadáta a pridá `omitted_superseded_count` a `omitted_template_count`.
- `profile.groups.metrics.records` sa nahradí zoznamom `metric_refs`; stavové a ostatné metadáta skupiny sa zachovajú.
- Finančný fakt vložený napríklad do konfliktu sa nahradí objektom `{"fact_ref": "f_…"}`. Samotný fakt je v slovníku `facts`.
- Rozpoznaný raw finančný výkaz vložený do ďalších dôkazov sa nahradí `report_ref`. Rozpoznané šablóny zostávajú iba ako identifikačné metadáta s označením vynechaného payloadu. Celé `decoded_tables` sa v kompaktnom pohľade neposielajú.

Ak príslušná skupina v pôvodnom profile nebola prítomná, exportér ju iba kvôli pohľadu nevytvára. Prítomnosť položky v slovníku nemení stav zdroja: napríklad uložené výkazy pri stave `stale` alebo `source_unavailable` nie sú novým úspešným overením.

## Reports: zdieľaná proveniencia a verzia

Kľúč výkazu má tvar `r_` a 64 malých hexadecimálnych znakov SHA-256. Je to interný obsahový identifikátor pohľadu; nie je to IČO ani identifikátor pridelený RÚZ.

Slovník `reports` môže obsahovať tieto druhy záznamov:

| `record_type` | Význam |
| --- | --- |
| `financial_report` | Metadáta finančného výkazu rozpoznaného podľa zdrojového záznamu. |
| `statement` | Metadáta účtovnej závierky so zoznamom výkazov v zdrojovom zázname; celý raw obsah sa neposiela. |
| `financial_evidence` | Iný finančný dôkaz, ktorý sa nedá zaradiť do predchádzajúcich dvoch druhov. |
| `evidence_stub` | Obmedzený podklad pre fakt, konflikt, vstup metriky alebo provenienciu. Nie je to celý importovaný výkaz. |

`view_role` upresňuje úlohu záznamu:

| Hodnota | Význam |
| --- | --- |
| `report` | Bežný výkaz alebo finančný záznam vybraný do pohľadu; jeho ref je aj v `profile.groups.financials.report_refs`. |
| `conflict_evidence` | Podklad zachovaný pre konflikt alebo iný vložený dôkaz; môže sa týkať vynechanej nahradenej verzie. |
| `metric_input_evidence` | Podklad pre existujúci vstup metriky, keď nie je k dispozícii jednoznačne priradený celý výkaz. |
| `provenance_evidence` | Podklad vnoreného upstream dôkazu alebo histórie získania údajov. |

Podľa dostupnosti sa v reporte uchovávajú najmä `report_id`, `statement_id`, `entity_id`, historické `entity_name` a `ico`, ďalej `source`, `source_url`, `source_record_id`, `retrieved_at`, `source_updated_at`, platnostné polia, `match_method`, `kind`, `availability_status`, identita šablóny, mena, jednotka a konsolidácia. Bežný report môže mať aj `filing`, `attachments`, `financial_issues`, `current_period` a `comparative_period`.

`retrieved_at` označuje čas získania dôkazu, nie čas vytvorenia exportu. `source_updated_at` je údaj o aktualizácii zdroja; nie je náhradou za právnu účinnosť alebo za účtovné obdobie. Chýbajúce časové údaje sa nedopočítavajú podľa aktuálneho času exportu.

Katalogizácia a vytvorenie výstupu prebiehajú oddelene: najprv sa zaevidujú všetky finančné verzie a ich známe aliasy, až potom sa emitujú vybrané reporty a spracujú fakty a metriky. Ak viaceré záznamy predstavujú rovnaký reportový ref, katalóg zlúči známe aliasy a uprednostní metadáta s novším `retrieved_at`. Časy pritom porovnáva ako časové okamihy, nie iba ako textové reťazce. Staršia kópia preto nemá nahradiť novšie metadáta iba preto, že sa v zozname nachádza neskôr. Vlastná odlišná proveniencia konkrétneho faktu sa naďalej zachováva pri tomto fakte.

`report_version` používa kanonický hash raw záznamu, ak raw záznam existuje. V opačnom prípade je založený na metadátach dôkazu. `version_basis` rozlišuje `canonical_raw_record` a `canonical_evidence_metadata`; metadata-only provenienčný list môže mať toto pole vynechané. Dve skutočne odlišné verzie s rovnakým `report_id` preto nesmú byť zlúčené iba podľa čísla výkazu.

`source_report_versions` je zoradený zoznam známych tokenov verzie vrátane kanonickej verzie exportéra. Alias môže pochádzať z `report_identity.report_version`, z vlastného `report_version` záznamu alebo z explicitného `report_version_aliases`. Pri legacy zázname, ktorý nemá vlastný neprázdny token v identite ani v metadátach, sa môže použiť aj jeden jednomyseľný token z faktov: všetky dostupné neprázdne reťazcové `report_version` v týchto faktoch musia uvádzať ten istý token. Viac rozdielnych faktových tokenov túto výnimku nespĺňa.

Neznámy token jedného faktu sa teda sám nestane aliasom známej verzie výkazu. Ak sa jeho verzia nepodarí priradiť, zostáva samostatným dôkazom so stubom; exportér ho potichu nepripojí k inej verzii len podľa rovnakého `report_id`. Známe aliasy umožňujú priradiť staršie vstupy metrík aj vtedy, keď pôvodný RC3 hash závisel od poradia kľúčov JSON. `source_superseded_by`, ak existuje, zachováva pôvodný zdrojový token nahrádzajúcej verzie.

Hash z `Profile::canonical_hash()` a exportérov `report_version` sa nemusia textovo zhodovať ani pri rovnakom obsahu. Obe implementácie triedia mapové kľúče, ale exportér pri JSON hashovaní používa aj neescapované Unicode a lomky; profilové hashovanie používa vlastné nastavenie `wp_json_encode`. Známy profilový token sa preto používa ako alias, nie ako požiadavka na rovnaký bajtový zápis JSON v oboch vrstvách. Toto nemení význam `version_basis` ani nevytvára nový dôkaz o pôvode dát.

Tieto hashové aliasy a zdrojové ID nie sú odkazy do slovníka. Klient má na spojenie tabuliek používať `report_ref`, nie samostatné `report_id`, `report_version`, `source_record_id` alebo `source_superseded_by`.

## Facts: hodnota, súradnice a dimenzie

Kľúč faktu má tvar `f_` a 64 hexadecimálnych znakov. Fakt vždy obsahuje `report_ref` smerujúci do `reports`. Pri normalizovaných údajoch z výkazu zachováva najmä:

| Položka | Význam |
| --- | --- |
| `fieldcode` | Význam údaja, napríklad `assets` alebo `profit_after_tax`. |
| `value` | Už normalizovaná hodnota; exportér ju neprepočítava. |
| `raw_value` | Pôvodná hodnota bunky, napríklad `"0"`, `""` alebo `null`. |
| `table`, `row` | Konkrétna tabuľka a riadok výkazu, ak ich vstup poskytuje. |
| `column` | Pri normálnom 687 výkaze `current` alebo `comparative`; pôvodná hodnota sa zachováva. |
| `column_index`, `source_column` | Ďalšia súradnica stĺpca, ak bola vo fakte prítomná. |
| `period` | Pôvodné účtovné obdobie faktu; bežný a porovnávací stĺpec sa nezlučujú. |
| `label`, `source_label` | Názov normalizovaného údaja a pôvodný názov riadku, ak sú dostupné. |
| `availability_status` | Dostupnosť konkrétnej hodnoty, napríklad `observed` alebo `not_disclosed`, ak ju vstup poskytuje. |

Hodnoty `0`, `"0"`, `null` a `""` sa nesmú zlúčiť. Typický explicitný nulový údaj je `value: 0, raw_value: "0"`. Typická nevyplnená bunka je `value: null, raw_value: ""`; neznamená vykázanú nulu.

Ak vo vstupnom fakte chýba `value`, `raw_value`, `row` alebo `period`, exportér vloží `null` a názov chýbajúcej položky uvedie v `not_provided`. Chýbajúce `fieldcode` a `column` doplní z dostupného kontextu alebo hodnotou `null`. Neúplný legacy vstup preto nemusí mať konkrétnu súradnicu riadku. Exportér sám riadok, obdobie ani menu neháda.

Spoločné metadáta sa presunú do reportu, len keď sa ich hodnoty vo fakte a reporte presne zhodujú. Ak sa napríklad meny faktov jedného reportu líšia, report môže mať `currency: null` a jednotlivé fakty si ponechajú vlastnú menu. Rovnaké pravidlo platí pre jednotky, konsolidáciu a ďalšiu zdieľanú provenienciu.

Pri čítaní efektívnej hodnoty má **existujúci kľúč faktu prednosť aj vtedy, keď je jeho hodnota `null`**. Až keď kľúč vo fakte chýba, použije sa report:

```text
report = item.financials.reports[fact.report_ref]
currency = fact má vlastný kľúč "currency" ? fact.currency : report.currency
```

Nepoužívajte iba náhradu `null` hodnotou z reportu. Mohla by zmeniť význam výslovne neznámej dimenzie. `period` zostáva pri fakte; reportové `current_period` a `comparative_period` neslúžia na doplnenie vymysleného chýbajúceho obdobia.

Report nemá povinný zoznam všetkých svojich `fact_refs`. Fakty konkrétneho reportu sa vyberajú zo slovníka `facts` podľa `report_ref` a ďalej podľa `fieldcode`, stĺpca a obdobia.

## Metrics: existujúci výsledok s referencovanými vstupmi

Kľúč metriky má tvar `m_` a 64 hexadecimálnych znakov. Export zachováva jej existujúci výsledok, vzorec, jednotku, obdobie a ostatné metadáta. Každý exportovaný prvok `inputs` obsahuje namiesto celého faktu iba:

```json
{
  "fact_ref": "f_…"
}
```

Postup čítania vstupu je `metrics[metricRef].inputs[inputName].fact_ref` → `facts[factRef]` → `reports[fact.report_ref]`. Pri jednoznačnom priradení má metrika aj vlastný `report_ref`. Toto pole nemusí existovať pri staršom alebo neúplnom dôkaze; jej jednotlivé exportované vstupy sú napriek tomu uložené ako referencované fakty.

Exportér vie rozbaliť aj starší obal s mapou metrík vo `value`; názov položky zachová ako `legacy_metric_key`. Ak vstup metriky tvorí iba skalár, uloží ho do faktu s `input_shape: "scalar"`, ponechá tento skalár ako `value` aj `raw_value` a nedopočíta chýbajúce súradnice či obdobie.

Kompaktný export nekontroluje, či výsledok skutočne zodpovedá vzorcu, ani nevytvára ďalší ukazovateľ z prázdnych hodnôt. Pravidlá finančnej normalizácie patria do normalizéra pred exportom. Obsahové ID metriky normalizuje známe hashové aliasy v odvodenom identifikátore `financial-metric:…`; pôvodný `source_record_id` sa pritom vo výstupe zachováva.

## History, konflikty a vnorené dôkazy

Pri `history=false` sa neexportujú celé finančné záznamy označené `superseded`. Vynechajú sa tiež metriky, ktoré sú označené ako nahradené alebo ktorých vlastný report či vstup odkazuje na rozpoznanú nahradenú verziu. Stará metrika sama nesmie obnoviť celý vynechaný výkaz.

`history=true` zahrnie aj tieto verzie a ich existujúce metriky. Ani v tomto režime sa neposielajú raw finančné `value`, celé `decoded_tables` či celé šablóny. Predchádzajúce účtovné roky a porovnávacie stĺpce bežných nenahradených výkazov zostávajú dostupné aj pri `history=false`; parameter neznamená „iba posledný rok“.

Počítadlo `omitted_superseded_count` označuje preskočené záznamy z `financials.records`; `omitted_template_count` označuje vynechané záznamy šablón z tejto skupiny. Nejde o všeobecné počítadlá všetkých historických dôkazov v profile.

Konflikt sa kvôli predvolenému pohľadu nemaže. Ak jeho fakt patrí vynechanej verzii, export ponechá daný fakt a reportový stub s `record_type: "evidence_stub"` a príslušným `view_role`. Takýto podklad môže byť v slovníku `reports`, aj keď nie je v zozname bežných `report_refs`. Počet položiek slovníka preto nie je počet úplných účtovných výkazov.

`upstream_evidence` a `evidence_history` sa prechádzajú aj vo finančných metadátach. Vložené raw finančné kópie sa nahrádzajú odkazmi alebo metadata-only podkladom. Ak upstream kópia opisuje práve spracúvaný report, vytvorí sa samostatný provenienčný list bez spätného odkazu na tento report. Zdrojové údaje, časy, poznámky a ostatné nefinančné metadáta sa zachovávajú; v stuboch sa môžu nachádzať pod `evidence_metadata`. Pre vynechaný raw payload sa môže použiť `payload_metadata` alebo `omitted_payload`.

Rozpoznané raw finančné výkazy a šablóny sa spracujú aj vtedy, keď sú vnorené ako PHP `stdClass`, nielen ako asociatívne polia. Pre túto rozpoznanú raw vetvu sa normalizuje reprezentácia a odstráni celý payload rovnakým postupom. Bežné nefinančné provenienčné objekty zostávajú objektmi a ich hodnoty sa týmto rozpoznaním nepreklasifikujú na výkaz.

Na spracovanie treba nasledovať explicitné `report_ref`, `fact_ref`, `metric_ref` a príslušné zoznamy referencií, nie hľadať duplicitu celého pôvodného objektu. Provenienčný stub nie je nová priama kontrola registra a nemení dostupnosť ani dôveryhodnosť pôvodného zdroja.

## Identita, právny stav a aktivita

Kompaktný export zachováva súhrn vytvorený `Profile::summarize()`. Význam dôležitých polí je oddelený:

- `found` hovorí o dostupnosti názvu v profile; sám osebe nepotvrdzuje identitu v priamom registri.
- `identity_verified` a `identity_verification` opisujú overenie identity. `identity_verification.scope` je `identity_only`; potvrdenie vyžaduje zodpovedajúci priamy dôkaz RPO alebo ORSR a jeho kontrolu v profile.
- `legal_status_verified` opisuje potvrdenie podporovaného právneho registračného stavu. Nie je odvodené iba z úspešného overenia názvu alebo zo závierky RÚZ.
- `active` vyjadruje projekciu podporovaného registračného stavu alebo je `null`. Nepotvrdzuje skutočnú ekonomickú činnosť firmy.
- `economic_activity_status` má v aktuálnom súhrne hodnotu `not_assessed`.
- Staršie polia `verified` a `verification_status` zostávajú kompatibilnou projekciou právneho stavu. `verified` sa nesmie zamieňať za nové `identity_verified`; identita môže byť overená aj pri aktuálne nepotvrdenom právnom stave.

Exportér tieto rozhodnutia neprepočítava podľa toho, koľko záznamov alebo faktov našiel. Finančné čísla, absencia záznamu alebo samotný stav `found` neposkytujú dodatočnú certifikáciu bezpečnosti firmy.

## Stabilita a kompatibilita

Hashovanie triedi kľúče objektov a máp rekurzívne. Poradie zoznamov a typy skalárov sa zachovávajú; preto môže zmena poradia zoznamu zmeniť obsahové ID, zatiaľ čo samotná permutácia mapových kľúčov ho nezmení. Kanonické poradie kľúčov platí aj pre výsledný DTO. Klient má identifikátory považovať za nepriehľadné hodnoty a používať ich na spojenie slovníkov, nie si z `report_id` konštruovať vlastné referencie.

DTO ponecháva dodatočné položky dôkazov podľa vstupu; nejde o uzavretú schému so zákazom neznámych polí. Zmenené hodnoty, dimenzie alebo relevantná proveniencia môžu viesť k novému ID. Chýbajúce dôkazy sa tým nenahrádzajú nulou alebo odhadom.

Úplný formát `json` ostáva oddelený. Handler preň naďalej vracia obálku `schema_version: "2.1"`, `count`, `items` s úplnými načítanými profilmi, raw finančnými výkazmi a šablónami. Parameter `history` filtruje kompaktný finančný pohľad; v úplnej JSON vetve sa nepoužíva. Pridanie `compact_json` nemení názov ani štruktúru doterajšieho úplného exportu.

Pri migrácii klienta používajte `compact_json` pre referencované finančné čítanie a `json` pre úplný zdrojový archív. Tieto formáty nemajú rovnakú schému a nemajú sa spracúvať tým istým parserom len podľa prítomnosti `items`.

## Implementačné zdroje

- [`includes/class-ico-atlas-export.php`](../includes/class-ico-atlas-export.php): DTO, kanonické referencie, aliasy, história a prepis proveniencie.
- [`includes/class-ico-atlas-rest-controller.php`](../includes/class-ico-atlas-rest-controller.php): route, parametre, oprávnenia a zachovaná úplná JSON vetva.
- [`includes/class-ico-atlas-enricher.php`](../includes/class-ico-atlas-enricher.php): načítanie uloženého profilu pred exportom.
- [`includes/class-ico-atlas-profile.php`](../includes/class-ico-atlas-profile.php): súhrn identity, právneho stavu a dostupnosti dôkazov.
- [`includes/class-ico-atlas-financials.php`](../includes/class-ico-atlas-financials.php): finančná normalizácia pred vytvorením kompaktného pohľadu.

Samostatná normatívna JSON Schema nie je súčasťou tohto dokumentu. Dôkazové obálky a dodatočné polia sú rozšíriteľné a táto dokumentácia ich nezužuje nepresnou statickou schémou.
