# VORKEI IČO ATLAS 2.2.0-rc.6

**Verdikt: BLOCKED pre stabilný predaj.** RC.6 je ďalší kandidát na skúšobnú kópiu, nie vydanie na predaj.

Tento beh nenašiel všetky chyby. Pokrytie riadkov, funkcií a vetiev sa nemeralo. WordPress, MariaDB, WooCommerce, HPOS za behu, JetForm a živé registre sa nespúšťali. Čísla z `docs/OVERENIE-2.2.md` sa na tieto bajty nevzťahujú.

## Čo sa zmenilo oproti 2.2.0-rc.5

- Proxy berie číselné IČO z JSON cez `same_ico`. Reťazec kratší ako 8 číslic sa nedopĺňa.
- Neúspešný pokus proxy nahradí hotovú kontrolu len záznamom `last_attempt_*`. Skutočný `not_found` kontrolu nahradí.
- `continue` bez uloženého rozpracovaného behu je výpadok `source_unavailable`. Nezačne prázdny beh a výsledok sa neukladá do cache lookupu.
- Aktivácia nemení `jet_cct_*`. Doplnenie stĺpcov len pri `vorkei_ico_alter_cct=yes`. Predvolene `no`.
- CSV export vracia `WP_REST_Response` a telo pošle `rest_pre_serve_request`. Už nevolá `exit`. Oprávnenie `manage_options` ostáva na route.
- `Profile::metrics()` je preč. V pluginne nemala volanie a počítala z kľúča `revenue`. Pomery ostávajú vo `Financials::ratios`.
- Detail v `admin.js` už nehovorí „neaktivita alebo zánik“.

FirmaBind ostáva predvolene vypnutý. Dáta sa pri odinštalovaní nemažú, kým nie je `vorkei_ico_delete_data_on_uninstall=yes`.

## Čo tu prešlo

Izolovaný stub, PHP 8.4.14, bez WordPressu: 78/78. PHP lint súborov pluginu a `node --check` oboch skriptov. To nie je 99 % pokrytia.

## Čo predaj stále blokuje

WordPress 6.2 aj aktuálny, MariaDB, čistá inštalácia, update z 2.1 a z tohto ZIP, multisite, Woo classic, Blocks, HPOS za behu, JetForm Call Hook, Xdebug alebo PCOV, živé FS/VIES/RPO/ORSR/RÚZ, obnova databázy podľa `docs/OBNOVA.md`.
