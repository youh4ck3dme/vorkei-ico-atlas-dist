# VORKEI IČO ATLAS

`2.2.0-rc.8` nie je stabilné vydanie. Je to kandidát na skúšobnú kópiu.

Rozhodnutie a hranice sú v [docs/VYDANIE-2.2.0-rc.8.md](docs/VYDANIE-2.2.0-rc.8.md). Predaj je blokovaný, kým tie isté bajty neprejdú WordPressom, MariaDB, WooCommerce, nameraným pokrytím a podmienkami zdrojov.

Inštalačný ZIP nemá testovací vstup. SHA-256 ZIP-u je v správe k vydaniu mimo tohto stromu, aby sa hash nezmenil tým, že je zapísaný vnútri balíka.
