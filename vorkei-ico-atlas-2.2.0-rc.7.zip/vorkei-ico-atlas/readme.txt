=== VORKEI IČO ATLAS ===
Contributors: vorkei
Requires at least: 6.2
Requires PHP: 8.1
Stable tag: 2.2.0-rc.7
License: GPLv2 or later

Preukázateľné profily firiem s priamym konektorom RÚZ a existujúcim registračným API.

Skúšobná verzia 2.2: voliteľný FirmaBind je predvolene vypnutý. Dokumentácia a hranice: docs/FIRMABIND-2.2.md, docs/OVERENIE-2.2.md.

== Inštalácia ==
Najprv záloha a skúšobná kópia WordPressu. Nahrať ZIP a nahradiť pôvodný plugin.
Verziovaná migrácia zachová existujúcu tabuľku. Rozšírený lookup teraz vyžaduje administrátora.

== Rozsah ==
RÚZ: jednotky, závierky, výkazy, šablóny, správy a odkazy na prílohy.
Čitateľné finančné tabuľky: overená šablóna 687; ostatné dáta zachované v pôvodnej podobe.
Priame RPO a ORSR dopĺňajú osoby a vlastníctvo. Oficiálne FS API vyžaduje vlastný kľúč a konfiguráciu zoznamov. Ostatné nepripojené skupiny zostávajú Neoverené.
Zdroj, čas, dostupnosť a konflikty pri údajoch. Ukladanie profilu, dávky, cron, JSON a CSV.

Podrobnosti: docs/IMPLEMENTACIA.md, docs/ZDROJE.md, docs/CONTRACT.schema.json.
Testy sú v samostatnom QA balíku. V testovacej pracovnej kópii: php tests/run.php (izolovaný harness); úplný beh a natívne prostredie opisuje QA-REPRO.md. Inštalačný ZIP neobsahuje testovacie skripty.

== Changelog ==
= 2.2.0-rc.7 =
* Verejná karta FirmaBind berie číselné IČO z JSON rovnako ako atlas. Text kratší ako 8 číslic naďalej nie je IČO.
* Rozpracované získavanie v dávke nie je chyba. Počítadlo zlyhaní sa zvýši až po dokončení behu.
* Súčet na nástenke už netvrdí, že ide len o zákazníkov, dodávateľov a klientov, ani že prázdny zoznam znamená chýbajúce tabuľky JetEngine.

= 2.2.0-rc.6 =
* Proxy akceptuje číselné IČO z JSON. Text kratší ako 8 číslic naďalej nie je IČO.
* Neúspešný pokus proxy nahradí hotovú kontrolu registra len záznamom o poslednom pokuse.
* Pokračovanie získavania bez uloženého rozpracovaného behu je výpadok, nie nový prázdny beh a nie „nenájdené“.
* Aktivácia už nemení tabuľky JetEngine. Doplnenie stĺpcov vyžaduje voľbu vorkei_ico_alter_cct=yes.
* CSV export sa vracia ako REST odpoveď a neukončuje PHP cez exit.
* Odstránená nepoužívaná Profile::metrics() s nesprávnym kľúčom revenue. Pomery ráta Financials.
* Detail profilu v administrácii už nezamieňa zánik s neaktivitou.
* V koreni pluginu je súbor VERSION. Obsahuje to isté číslo ako hlavička pluginu.

= 2.2.0-rc.5 =
* Výpadok zdroja už neprepíše známy právny stav na neoverený. Posledný pokus je samostatný.
* Číselné IČO z JSON (bez úvodných núl) sa zhoduje s osemmiestnym IČO. Text kratší ako 8 číslic sa nedopĺňa.
* FirmaBind nezapíše registerové IČ DPH do zákazníckeho poľa a nepotvrdí väzbu, ak ho zákazník nezadal.
* HPOS kompatibilita sa deklaruje pred štartom WooCommerce, a len keď je FirmaBind zapnutý.
* ORSR a identitná karta fungujú aj bez rozšírenia mbstring.
* Obrazovka nerozoznáva zánik firmy od konkurzu a zápis v registri od hospodárskej aktivity.
* Odinštalovanie nemaže uložené profily ani snímky. Podrobnosti: docs/OBNOVA.md.

= 2.2.0-rc.4 =
* Rovnaké finančné podklady s iným poradím JSON kľúčov netvoria falošné historické verzie; pôvodné dôkazy a aliasy sa zachovajú.
* Samostatný kompaktný JSON s referenciami na výkazy a fakty; skutočné nahradené verzie cez history=true. Úplný archív JSON ostáva dostupný.
* Dostupnosť financií je oddelená od stavu synchronizácie RÚZ a zostávajúcich úloh.
* Potvrdenie identity v RPO/ORSR je samostatné od overenia právneho stavu a hospodárskej aktivity.
* Dokumentácia kompaktného kontraktu: docs/COMPACT-EXPORT-1.0.md; vykonané skúšky a externé obmedzenia: docs/OVERENIE-2.2.md.

= 2.2.0-rc.3 =
* Opravené poradie registrácie menu: Atlas otvára vlastný dashboard a FirmaBind svoju stránku.
* Bezpečné opakovanie neúspešného Blocks overenia, chýbajúce Woo rozhrania a ukončenie načítavania po zrušení požiadavky.
* Súbežné vyhľadávanie v administrácii neprijme staršiu odpoveď za aktuálnu firmu.
* Rozporné riadky FS zachovajú pôvodné dôkazy ako konflikt; neprenesú sa ako potvrdená hodnota do CCT.
* Rozšírené skupiny a metadáta backendu zostávajú v profile s označením pôvodu.
* Spracovanie profilu funguje aj bez mbstring; porovnávanie vtedy zachová ne-ASCII rozdiely.
* Rozšírené regresie a meranie PHP/JavaScript; výsledky, presné medzery a externé závislosti v docs/OVERENIE-2.2.md.

= 2.2.0-rc.2 =
* Opravy typov IČO, čerstvosti identity, poškodených odpovedí, migrácií/indexov, zmiešaných SQL kolácií a napojenia Bridge1.0.
* Reálne testy WordPress/Woo/JetForm/HPOS nad MariaDB; coverage a zostávajúce blokéry v docs/OVERENIE-2.2.md.
* Skúšobná verzia: požadované pokrytie vetiev a živé autorizované integrácie nie sú uzavreté.

= 2.2.0-rc.1 =
* Predvolene vypnutý FirmaBind, oddelená identitná karta, VIES a append-only snímky.
* Samostatné adaptéry klasického/blokového Woo checkoutu a výslovný JetForm Call Hook.
* Registračná schéma 2.1 a chránený plný lookup zostávajú zachované.

= 2.1.0 =
* Priame RPO/ORSR, aktuálne osoby a vlastníctvo, história a jednoznačný primárny spis.
* Oficiálny FS adaptér s vlastným kľúčom, discovery metadát a bezpečnými chybovými stavmi.
* Normalizované financie 687, pôvod a história hodnôt, čitateľný finančný CSV.
* Jednotná projekcia, oprava pokračovania bez resetu a zachovanie metadát pri exporte.

= 2.0.0 =
* Verziovaný dôkazový profil, priamy RÚZ a pokračujúce získavanie podkladov.
* Zachovanie vnorených polí, dát pri výpadku, transparentné stavy a zdroje.
* Oprava potvrdenia aktivity, duplicít, stránkovania a hromadného spracovania.
* Chránený lookup, HTTPS, bezpečné vykreslenie a úplný JSON export.
