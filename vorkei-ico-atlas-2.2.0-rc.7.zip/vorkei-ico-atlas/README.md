# VORKEI IČO ATLAS

`2.2.0-rc.7` nie je stabilné vydanie. Je to kandidát na skúšobnú kópiu.

Rozhodnutie a hranice sú v [docs/VYDANIE-2.2.0-rc.7.md](docs/VYDANIE-2.2.0-rc.7.md). Predaj je blokovaný, kým tie isté bajty neprejdú WordPressom, MariaDB, WooCommerce a nameraným pokrytím.

Inštalačný ZIP nemá testovací vstup. SHA-256 ZIP-u je v správe k vydaniu mimo tohto stromu, aby sa hash nezmenil tým, že je zapísaný vnútri balíka.
